import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix,ConfusionMatrixDisplay
conf_matrix = np.array([[64, 6],[7, 63]])
classes = ["Positive", "Negative"]
disp = ConfusionMatrixDisplay(confusion_matrix=conf_matrix, display_labels=classes)
disp.plot(
    include_values=True,  # 混淆矩阵每个单元格上显示具体数值
    cmap="viridis",  # 使用的sklearn中的默认值
    ax=None,  # 同上
    xticks_rotation="horizontal",  # 同上
    values_format="d"  # 显示的数值格式
)
plt.title('Confusion Matrix') # 标题名
plt.show()
import matplotlib.pyplot as plt
import os
from pandas import DataFrame
import numpy as np
from sklearn.metrics import roc_auc_score
import torch.nn as nn
import torch

def load_paraments_partial(model, path):
    model_pretrained = torch.load(path)
    for i, key1, key2 in zip(range(20), model.state_dict().keys(), model_pretrained.keys()):
        if model.state_dict()[key1].size() == model_pretrained[key2].size():
            # print(key1, key2)
            model.state_dict()[key1].copy_(model_pretrained[key2])
        else:
            print('维度不匹配')
            break
    print('模型已经预加载')
    return model

def weight_init(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_normal_(m.weight)
        nn.init.constant_(m.bias, 0)
    elif isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.constant_(m.weight, 1)
        nn.init.constant_(m.bias, 0)

def get_para_weight_bias(model):
    weight_p, bias_p = [], []
    for name, p in model.named_parameters():
        if 'bias' in name:
            bias_p += [p]
        else:
            weight_p += [p]
    return weight_p, bias_p


class ParaUpdate():
    def __init__(self):
        self.running_loss = 0.0  # 保存每个mini_batches的loss之和，用于打印，打印后清空
        self.train_total = 0  # 保存每个epoch的总的个数
        self.train_correct = 0  # 保存每个epoch的正确的个数
        self.train_loss = 0.0
        self.train_i = 0#训练过程batchsize循环计数
        self.train_acc = 0

        # Validation loss
        self.val_loss = 0.0
        self.val_steps = 0
        self.val_total = 0
        self.val_correct = 0
        self.val_i = 0
        self.val_acc = 0

        #OGM
        self.loss_l = 0.0
        self.loss_v = 0.0
        self.loss_a = 0.0

        self.label ={
        'train': {'real': [], 'predict': []},
        'val': {'real': [], 'predict': []},
        'test': {'real': [], 'predict': []}
    }
        self.result = {  # 用于存放最后的各种指标结果
        'train': {'acc': 0.0, 'auc': 0.0},
        'val': {'acc': 0.0},
        'test': {'acc': 0.0, 'auc': 0.0},
    }
        self.plot = {
        'train': {'loss': [], 'acc': []},
        'val': {'loss': [], 'acc': []}
    }

        self.loss = {
        'l': [],
        'v': [],
        'a': [],
    }
    def getLabel(self):
        return self.label

    def getLabel_p1(self, stage):
        return self.label[stage]['real'], self.label[stage]['predict']

    def getLabel_p2(self, stage, metric):
        return self.label[stage][metric]

    def getResult(self):
        return self.result

    def getResult_p2(self, stage, metric):
        return self.result[stage][metric]

    def getPlot(self):
        return self.plot

    def getPlot_p1(self, metric):
        if metric == 'loss' or metric == 'acc':
            return self.plot['train'][metric], self.plot['val'][metric]
        else:
            print("指标输入错误")

    def getPlot_p2(self, stage, metric):
        if (stage == 'train' or stage == 'val') and (metric == 'loss' or metric == 'acc'):
            return self.plot[stage][metric]
        else:
            print("参数输入错误")

    def addLabel(self, stage, real, predict):
        if stage == 'train' or stage == 'val' or stage == 'test':
            self.label[stage]['real'].extend(real)
            self.label[stage]['predict'].extend(predict)
        else:
            print('阶段输入错误')

    def setResult_p1(self, metric, metric_t, metric_v):
        if metric == 'acc' or metric == 'auc':
            self.result['train'][metric] = metric_t
            self.result['val'][metric] = metric_v
        else:
            print('setResult_p1 输入错误')


    def setResult_p2(self, stage, acc, auc=None):
        if stage == 'train' or stage == 'val' or stage == 'test':
            self.result[stage]['acc'] = acc
            self.result[stage]['auc'] = auc
        else:
            print('setResult_p2 阶段输入错误')

    def setResult_p3(self, stage, metirc, metric_value):
        if stage == 'train' or stage == 'val' or stage == 'test':
            self.result[stage][metirc] = metric_value
        else:
            print('setResult_p3 阶段输入错误')

    def addPlot(self, stage, loss, acc):
        if stage == 'train' or stage == 'val':
            self.plot[stage]['loss'].append(loss)
            self.plot[stage]['acc'].append(acc)

    def plot_savefig(self, path_plot, seed, epoch_num):
        if not os.path.exists(path_plot):
            os.makedirs(path_plot)
        x = range(epoch_num)
        plt.plot(x, self.plot['train']['loss'], label='train')
        plt.plot(x, self.plot['val']['loss'], label='val')
        plt.legend()
        plt.savefig(os.path.join(path_plot, str(seed) + 'loss.png'))
        plt.close()
        plt.plot(x, self.plot['train']['acc'], label='train')
        plt.plot(x, self.plot['val']['acc'], label='val')
        plt.legend()
        plt.savefig(os.path.join(path_plot, str(seed) + 'acc.png'))
        plt.close()

    def addOGMLoss(self, loss_v, loss_a):
        self.loss['v'].append(loss_v)
        self.loss['a'].append(loss_a)

    def plot_OGM(self, path_plot, seed, epoch_num):
        x = range(epoch_num)
        plt.plot(x, self.plot['train']['loss'], label='trainloss')
        plt.plot(x, self.loss['v'], label='img')
        plt.plot(x, self.loss['a'], label='cli')
        plt.legend()
        plt.savefig(os.path.join(path_plot, str(seed) + 'OGMloss.png'))
        plt.close()

    def metric_compute(self, result: DataFrame,
                    seed: int, i: int, n_class: int = 2):
        '''
        计算AUC指标并写入dataframe
        :param result: 最后的指标结果总表
        :param seed:
        :param i: 第几行，从seed的for循环中获取
        :param n_class: 几分类
        :return:
        '''
        if n_class == 2:
            multi_class = 'raise'
        elif n_class >= 3:
            multi_class = 'ovo'  # 'ovo'
        label_train_predict = np.array(self.label['train']['predict'])
        label_test_predict = np.array(self.label['test']['predict'])
        label_train_real = np.array(self.label['train']['real'])
        label_test_real = np.array(self.label['test']['real'])
        if multi_class == 'raise':
            print('二分类AUC')
            label_train_predict = label_train_predict[:, 1]
            label_test_predict = label_test_predict[:, 1]
        elif multi_class == 'ovo' or multi_class == 'ovr':
            print('多分类AUC')
        # print('label_train_predict:\n', label_train_predict.sum(axis=1))
        # try:
        self.result['train']['auc'] = roc_auc_score(label_train_real, label_train_predict,
                                                    multi_class=multi_class)
        self.result['test']['auc'] = roc_auc_score(label_test_real, label_test_predict, multi_class=multi_class)

        # except:
        #     self.result['train']['auc'] = 0
        #     self.result['test']['auc'] = 0
        # 'accuracy_train', 'accuracy_val', 'accuracy_test'
        result.loc[i]['seed'] = seed
        result.loc[i]['accuracy_train'] = self.result['train']['acc']
        result.loc[i]['accuracy_val'] = self.result['val']['acc']
        result.loc[i]['accuracy_test'] = self.result['test']['acc']
        result.loc[i]['auc_train'] = self.result['train']['auc']
        result.loc[i]['auc_test'] = self.result['test']['auc']
        return result

    def epoch_init(self):
        self.running_loss = 0.0  # 保存每个mini_batches的loss之和，用于打印，打印后清空
        self.train_total = 0  # 保存每个epoch的总的个数
        self.train_correct = 0  # 保存每个epoch的正确的个数
        self.train_loss = 0.0
        self.train_i = 0  # 训练过程batchsize循环计数

        # Validation loss
        self.val_loss = 0.0
        self.val_steps = 0
        self.val_total = 0
        self.val_correct = 0
        self.val_i = 0

        # OGM
        self.loss_v = 0.0
        self.loss_a = 0.0

    def epoch_update(self, stage, loss, labels, predicted):
        if stage == 'train':
            self.running_loss += loss
            self.train_loss += loss
            self.train_i += 1
            self.train_total += labels.size(0)
            self.train_correct += ((predicted == labels).sum().item())
        elif stage == 'val':
            self.val_loss += loss
            self.val_steps += 1
            self.val_i += 1
            self.running_loss += loss
            self.val_total += labels.size(0)
            self.val_correct += ((predicted == labels).sum().item())

    def OGMLoss_update(self, loss_v, loss_a):
        self.loss_v += loss_v
        self.loss_a += loss_a

    def update(self, savefig):
        self.train_loss = self.train_loss / self.train_i
        self.train_acc = self.train_correct / self.train_total
        self.val_loss = self.val_loss / self.val_i
        self.val_acc = self.val_correct / self.val_total
        if savefig:
            self.addPlot('train', self.train_loss, self.train_acc)
            self.addPlot('val', self.val_loss, self.val_acc)
        if self.loss_v != 0.0 and self.loss_a != 0.0:
            self.loss_v = self.loss_v / self.train_i
            self.loss_a = self.loss_a / self.train_i
            self.addOGMLoss(self.loss_v, self.loss_a)
    def acc_getbetter(self):
        self.result['train']['acc'] = self.train_acc
        self.result['val']['acc'] = self.val_acc






if __name__ == '__main__':
    a = ParaUpdate()
    a.addPlot('train', [1, 2], [2, 4])
    print(a.getPlot())
    print(a.getPlot_p1('loss'))
    print(a.getPlot_p2('train', 'loss'))

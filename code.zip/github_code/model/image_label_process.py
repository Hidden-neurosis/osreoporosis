'''
在分割任务中，网络模型最后的输出shape为[N, C, H, W] (以pytorch为例, 其中N为batch_size, C为预测的类别数)，而我们给的的gt（ground truth）的shape一般为[H, W, 3]（彩色图或rgb图）或[H, W]（灰度图）。
假设我们现在的分割任务里面有5个目标需要分割，给定的gt是彩色的。则网络模型最后的输出shape为 [N, 5, H, W]，这和gt的shape不匹配，在训练的时候它们两者之间不能进行损失值计算。因此，就需要使用One-hot编码对gt进行编码，将其编码为[H, W, 5]，最后再对维度进行transpose即可

作者：zelda2333
链接：https://www.jianshu.com/p/baeff8289833
来源：简书
著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
'''
import cv2
import torch
import numpy as np
import torchvision.transforms as transforms
import matplotlib.pyplot as plt

def imshow_tensor(img):
    '''将数字标签转换成彩色图像显示'''
    # colors = [[0, 0, 0], [255, 255, 0], [255, 0, 0], [0, 255, 0], [0, 0, 255], [255, 255, 255], [0, 255, 255]]
    colors = [[0, 0, 0], [128, 0, 0], [0, 128, 0], [128, 128, 0], [0, 0, 128]]
    # img = torch.permute(img, (1, 2, 0))
    # print('permute_img_size:', img.size())
    # print(img)
    img = img.cpu().numpy()
    # mask = cv2.fillPoly(mask, [points_array], category_types.index(category))
    img_rgb = np.zeros((np.shape(img)[0], np.shape(img)[1], 3))
    for i, rgb in zip(range(5), colors):
        # print(i,rgb) # 数字对应颜色
        img_rgb[img == i] = rgb
    plt.imshow(img_rgb)
    plt.show()

def mask_to_onehot(mask, palette):
    """
    Converts a segmentation mask (H, W, C) to (H, W, K) where the last dim is a one
    hot encoding vector, C is usually 1 or 3, and K is the number of class.
    """
    semantic_map = []
    for colour in palette:
        equality = np.equal(mask, colour)
        class_map = np.all(equality, axis=-1)
        semantic_map.append(class_map)
    semantic_map = np.stack(semantic_map, axis=-1).astype(np.float32)
    return semantic_map

def onehot_to_mask(mask, palette):
    """
    Converts a mask (H, W, K) to (H, W, C)
    """
    x = np.argmax(mask, axis=-1)
    colour_codes = np.array(palette)
    x = np.uint8(colour_codes[x.astype(np.uint8)])
    return x

if __name__ == '__main__':
    '''在此处import防止被dataset.py调用时导入而出现错误'''
    from dataset import imshow
    from dataset import OsteosegmentDataset

    label_train = '../data/train/labelme/json_to_dataset'
    label_test = '../data/test/labelme/json_to_dataset'
    root_dir_train = '../data/train/labelme'
    root_dir_test = '../data/test/labelme'
    transform = {'image': transforms.Compose([
        # transforms.ToPILImage(),
        transforms.ToTensor(),
        transforms.Resize((572, 572)),
    ]),
        'labels': transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((388, 388)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])}
    dataset = OsteosegmentDataset(label_train, root_dir_train, transform=None)
    image, labels = dataset[1]
    print(labels)
    # imshow(labels)
    # imshow(labels[:, :, 0])
    # imshow(labels[:, :, 1])
    # imshow(labels[:, :, 2])

    palette = [[0, 0, 0], [128, 0, 0], [0, 128, 0], [128, 128, 0], [0, 0, 128]]
    labels_onehot = mask_to_onehot(labels, palette)

    # np.set_printoptions(threshold=np.inf)#完全打印数组
    print('label_onehot', labels_onehot[:, :, 1])
    imshow(labels_onehot[:, :, 0])
    imshow(labels_onehot[:, :, 1])
    imshow(labels_onehot[:, :, 2])
    imshow(labels_onehot[:, :, 3])
    imshow(labels_onehot[:, :, 4])

import torch
import torch.nn as nn
from torch import Tensor
from torch.nn import functional as F

class Loss_Distill_Target(nn.Module):
    def __init__(self, alpha, beta, T):
        super(Loss_Distill_Target, self).__init__()
        self.alpha = alpha
        self.beta = beta
        self.T = T
        self.criterion1 = nn.CrossEntropyLoss()
        self.criterion2 = nn.KLDivLoss(reduction='batchmean')
        self.criterion3 = nn.KLDivLoss(reduction='batchmean')

    def forward(self, soft_label_outputs, soft_label1, soft_label2,  labels, outputs):
        loss1 = self.criterion1(outputs, labels)
        loss2 = self.criterion2(soft_label_outputs, soft_label1) * (self.T * self.T * self.alpha)
        loss3 = self.criterion3(soft_label_outputs, soft_label2) * (self.T * self.T * self.beta)
        loss = loss1 + loss2 + loss3
        return loss

if __name__ == '__main__':
    batch_size = 16
    classes = 3
    criterion = Loss_Distill_Target(alpha=0.5, beta=0.5, T=1)
    a = torch.randn(batch_size, classes)
    b = torch.randn(batch_size, classes)

    d = torch.randn(batch_size, classes)
    print(criterion(a, b, c, d))
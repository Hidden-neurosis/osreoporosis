'''
多模态融合时的数据获取类，调用单独模态的数据类
'''
import os
import cv2
import torch, torchvision
import numpy as np
import pandas as pd
import torchvision.transforms as transforms
from torch.utils.data import Dataset
import matplotlib.pyplot as plt

def imshow(img, color=1):
    # img = img / 2 + 0.5  # unnormalize
    # npimg = img.numpy()
    # print("img_shape:", np.shape(img))
    if color == 0:
        plt.imshow(img, cmap='gray')
    else:
        plt.imshow(img)
    plt.show()

class Dataset_clinical(Dataset):
    def __init__(self, feature, label, root_dir=None, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.feature = feature
        self.label = label

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        label = self.label.iloc[idx]
        feature = self.feature.iloc[idx, :]
        # feature = np.array(feature, dtype=float).reshape(1, 1, len(feature))
        feature = np.array(feature, dtype=float).reshape(len(feature))
        feature = torch.tensor(feature, dtype=torch.float)
        label = torch.tensor(label, dtype=torch.long)
        return feature, label

'''将分割后的图像输入分类器'''
class Dataset_image(Dataset):
    def __init__(self, image_path, label_path):
        self.image_name = os.listdir(image_path)
        self.label = pd.read_excel(label_path, header=0, index_col=0, usecols=[0, 1])
        self.image_path = image_path
        self.transform = transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((388, 388)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_name)

    def __getitem__(self, idx):
        image_name = self.image_name[idx]
        image_name, _ = os.path.splitext(image_name)#去除名称后缀
        label = self.label.loc[int(image_name), :]
        image = cv2.imdecode(np.fromfile(self.image_path + '/' + image_name + '.png', dtype=np.uint8), 0)
        _, image = cv2.threshold(image, 5, 255, cv2.THRESH_BINARY)
        # imshow(image, 0)
        image = self.transform(image)
        label = torch.tensor(label)
        return image, label

class Dataset_multimodal(Dataset):
    def __init__(self, feature, label, image_path='/home/user/suteng/osteo/data/image/segment_label'):
        self.label = label
        self.feature = feature
        self.index = feature.index
        self.image_path = image_path
        self.transform = transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),#转换到0-1范围
            transforms.Resize((64, 64)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.index)

    def __getitem__(self, idx):#通过病人id查询获得图像和结构化数据信息
        index = self.index[idx]
        # print('index:', index)
        label = self.label.loc[index]
        feature = self.feature.loc[index, :]
        image = cv2.imdecode(np.fromfile(self.image_path + '/' + str(index) + '.png', dtype=np.uint8), 0)
        # imshow(image)
        _, image = cv2.threshold(image, 5, 255, cv2.THRESH_BINARY)#0-255

        image = self.transform(image)
        label = torch.tensor(label)
        feature = torch.tensor(feature)
        feature = feature.to(torch.float32)
        return image, feature, label

def index_get_multimodal():
    image_path = '/home/user/suteng/osteo/data/image/segment_label'
    data_path = '/home/user/suteng/osteo/data/2_onehot.xlsx'
    # dataset = Dataset_multimodal(image_path=image_path, data_path=data_path)
    # print(dataset[1])
    image_name = os.listdir(image_path)
    data = pd.read_excel(data_path, header=0, index_col=0, sheet_name='Sheet1')
    data_index = data.index
    index = pd.DataFrame(index=data_index, columns=['complete'])
    index_complete = []
    print(index)
    # image_name, _ = os.path.splitext(image_name)

    for name in image_name:
        name, _ = os.path.splitext(name)
        name = int(name)
        print(name)
        if name in data_index:
            index.loc[name, ['complete']] = 1
            index_complete.append(name)
        else:
            index.loc[name, ['complete']] = 0

    print('index_complete:', index_complete)
    print(len(index_complete))
    # index.to_excel('/home/user/suteng/osteo/data/不缺失多模态数据.xlsx')

    '''筛选出模态不缺失的结构化数据'''
    data = pd.read_excel(r'//home/user/suteng/data/clinical/2_onehot.xlsx', index_col=0, header=0,
                         sheet_name='Sheet1')
    data = data.loc[index_complete]
    data.to_excel(r'/home/user/suteng/data/clinical/3_modalconplete_onehot.xlsx')
    print(data.shape)
    return

if __name__ == '__main__':
    # image_path = '/home/user/suteng/osteo/data/image/segment_label'
    data_path = '/home/user/suteng/osteo/data/2_onehot.xlsx'
    index_path = '/home/user/suteng/osteo/data/不缺失多模态数据.xlsx'
    data = pd.read_excel(r'//home/user/suteng/data/clinical/3_modalconplete_onehot.xlsx', index_col=0, header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 4:]
    labels = data.iloc[:, 0]
    dataset = Dataset_multimodal(feature=features, label=labels)
    # for i in range(3):
    print(dataset[0][0])
    # imshow(dataset[0][0], 0)
    # index_get_multimodal()





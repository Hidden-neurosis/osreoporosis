import os.path

import torch
import torch.nn as nn
import torch.nn.functional as F
from osteoV2.model.clinical.mlp_V2 import *
from osteoV2.model.clinical.resmlp import *
from osteoV2.model.image.cnn import Net_multimodel_CNN
from osteoV2.model.model_fusion.resnet18_V2 import ResNet18
import copy
from osteoV2.utils.base_utils import load_paraments_partial

def freeze_paraments(model):
    '''
    冻结部分层参数
    '''
    for child in model.children():
        # print(child)
        for param in child.parameters():
            param.requires_grad = False
            # print(param)
    return model

def save_model():
    '''
    用于测试模型部分迁移功能
    '''
    model_save_dir = '/home/user/suteng/osteo/osteoV2/model_save/multimodal/test_load.pth'
    model = Net_multimodel_clinical()
    torch.save(model.state_dict(), model_save_dir)
    return

def get_statedict_model(model, model_loaded):
    '''
    模型的部分迁移,
    '''
    state_dict = copy.deepcopy(model.state_dict())
    loaded_paras = torch.load(model_loaded)
    # print(state_dict)
    length = min(len(state_dict), len(loaded_paras))
    for i, key_state, key_loaded in zip(range(length), state_dict, loaded_paras):
        if state_dict[key_state].size() == loaded_paras[key_loaded].size():
            state_dict[key_state] = loaded_paras[key_loaded]
            # print('成功初始化参数', key_loaded, '>>', key_state)
        else:
            break
            # print('参数尺寸不匹配')
        if i >= length-1: break
    return state_dict


'''以图像特征与结构化数据特征拼接后的特征为输入的全连接层分类器部分， 输出为分类结果'''
class Net_fusion_classifier(nn.Module):
    def __init__(self, input_size=51, output_size=2, layer_size=[]):
        super(Net_fusion_classifier, self).__init__()
        self.n_classes = output_size
        self.len_layer = len(layer_size)
        self.activate_function = nn.ReLU()
        self.sequence = nn.Sequential()

        for i in range(len(layer_size)):
            if i == 0:
                self.sequence.append(nn.Linear(input_size, layer_size[0]))
            else:
                self.sequence.append(nn.Linear(layer_size[i - 1], layer_size[i]))
            self.sequence.append(nn.BatchNorm1d(layer_size[i]))
            self.sequence.append(self.activate_function)
        self.sequence.append(nn.Linear(layer_size[-1], self.n_classes))
    def forward(self, x):
        out = self.sequence(x)
        return out

'''整个模型的框架整合'''
class Net(nn.Module):
    def __init__(self, config, n_classes=2):
        super(Net, self).__init__()
        self.image_marginal_representation = ResNet18(image_size=config['image_size'], channels=config["resnet18_channels"])
        self.outsize_image = self.image_marginal_representation.get_output_size()[1]#获取CNN提取图像之后的特征尺寸，用于确定最后分类网络的输入
        self.clinical_marginal_representation = Net_multimodel_clinical(layer=config['mlp'])

        # self.clinical_marginal_representation = Net_fc_V2(layer_size=config['mlp'])
        #加载预训练模型
        path ='/home/user/PycharmProjects/osteo/pretrained/model_save/fashionmnist/[16, 32, 64, 128].pth'
        self.image_marginal_representation = load_paraments_partial(self.image_marginal_representation, path)

        path_cli = '/home/user/PycharmProjects/osteo/pretrained/model_save/clinical'
        dict_path = {
            "{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}": "10.17val0.634375_{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}.pth",
            "{'b1': [8, 8], 'b2': [8, 8], 'b3': [8]}": "10.17val0.653125_{'b1': [8, 8], 'b2': [8, 8], 'b3': [8]}.pth",
            "{'b1': [16, 16], 'b2': [16, 16], 'b3': [16]}":
                "10.17val0.640625_{'b1': [16, 16], 'b2': [16, 16], 'b3': [16]}.pth"
        }

        if config['transfer'] == 'cli':
            if str(config['mlp']) in dict_path.keys():
                path_cli = os.path.join(path_cli, dict_path[str(config['mlp'])])
                self.clinical_marginal_representation = \
                    load_paraments_partial(self.clinical_marginal_representation, path_cli)
            else:
                print('clinical part not pretrained')


        if config['freeze'] == 'cli' or config['freeze'] == 'both':
            self.clinical_marginal_representation = freeze_paraments(self.clinical_marginal_representation)
        if config['freeze'] == 'img' or config['freeze'] == 'both':
            self.image_marginal_representation = freeze_paraments(self.image_marginal_representation)

        # 获取特征提取之后的特征尺寸，用于确定最后分类网络的输入
        self.outsize_clinical = self.clinical_marginal_representation.get_output_size()[1]
        # self.fusion_classifier = Net_fusion_classifier(input_size=outsize_clinical + outsize_image,
        #                                                output_size=n_classes, layer_size=config['classifier'])
        self.fusion_classifier = nn.Linear(self.outsize_clinical + self.outsize_image, n_classes)


    def forward(self, data_image, data_clinical):
        image = self.image_marginal_representation(data_image)#图像的边际表示
        clinical = self.clinical_marginal_representation(data_clinical)#结构化数据的边际表示
        #拉成一维拼接后输入分类器
        image = image.view(len(image), -1)
        clinical = clinical.view(len(clinical), -1)
        marginal_representation = torch.concat((image, clinical), 1)
        out = self.fusion_classifier(marginal_representation)
        return image, clinical, out

class Net_V2(nn.Module):
    def __init__(self, config, n_classes=2):
        super(Net_V2, self).__init__()
        self.image_marginal_representation, self.outsize_image = self.imgmodel(config)
        self.clinical_marginal_representation, self.outsize_clinical = self.climodel(config)

        path_cli = '/home/user/PycharmProjects/osteo/pretrained/model_save/clinical'
        dict_path = {
            "{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}": "10.17val0.634375_{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}.pth",
            "{'b1': [8, 8], 'b2': [8, 8], 'b3': [8]}": "10.17val0.653125_{'b1': [8, 8], 'b2': [8, 8], 'b3': [8]}.pth",
            "{'b1': [16, 16], 'b2': [16, 16], 'b3': [16]}":
                "10.17val0.640625_{'b1': [16, 16], 'b2': [16, 16], 'b3': [16]}.pth"
        }

        if config['transfer'] == 'cli':
            if str(config['mlp']) in dict_path.keys():
                path_cli = os.path.join(path_cli, dict_path[str(config['mlp'])])
                self.clinical_marginal_representation = \
                    load_paraments_partial(self.clinical_marginal_representation, path_cli)
            else:
                print('clinical part not pretrained')


        if config['freeze'] == 'cli' or config['freeze'] == 'both':
            self.clinical_marginal_representation = freeze_paraments(self.clinical_marginal_representation)
        if config['freeze'] == 'img' or config['freeze'] == 'both':
            self.image_marginal_representation = freeze_paraments(self.image_marginal_representation)

        # 获取特征提取之后的特征尺寸，用于确定最后分类网络的输入

        # self.fusion_classifier = Net_fusion_classifier(input_size=outsize_clinical + outsize_image,
        #                                                output_size=n_classes, layer_size=config['classifier'])
        self.fusion_classifier = nn.Linear(self.outsize_clinical + self.outsize_image, n_classes)

    def imgmodel(self, config):
        model = ResNet18(image_size=config['image_size'], channels=config["resnet18_channels"])
        outsize = model.get_output_size()[1]
        # 加载预训练模型
        path = '/home/user/PycharmProjects/osteo/pretrained/model_save/fashionmnist/[16, 32, 64, 128].pth'
        model = load_paraments_partial(model, path)
        return model, outsize

    def climodel(self, config):
        model = Net_multimodel_clinical(layer=config['mlp'])
        outsize = model.get_output_size()[1]
        return model, outsize

    def forward(self, data_image, data_clinical):
        image = self.image_marginal_representation(data_image)#图像的边际表示
        clinical = self.clinical_marginal_representation(data_clinical)#结构化数据的边际表示
        #拉成一维拼接后输入分类器
        image = image.view(len(image), -1)
        clinical = clinical.view(len(clinical), -1)
        marginal_representation = torch.concat((image, clinical), 1)
        out = self.fusion_classifier(marginal_representation)
        return image, clinical, out

class Net_resmlp(Net):
    def __init__(self, config, n_classes=2):
        super(Net_resmlp, self).__init__(config, n_classes)
        self.clinical_marginal_representation = Net_multimodal_cli_res(layer=config['mlp'])

class Net_resmlp_V2(Net_V2):
    def __init__(self, config, n_classes=2):
        super(Net_resmlp_V2, self).__init__(config, n_classes)

    def climodel(self, config):
        model = Net_multimodal_cli_res(layer=config['mlp'])
        outsize = model.get_output_size()[1]
        return model, outsize

# class Net_no_cli(Net_V2):
#     def __init__(self, config, n_classes):
#         super(Net_no_cli, self).__init__(config, n_classes)
#
#     def climodel(self):
#         model =

if __name__ == '__main__':
    # print(range(0))
    # for i in range(0):
    #     print(i)

    config = {
        "epoch_num": 5,
        "step_size": 30,
        "lr": 0.001,
        "batch_size": 5,
        "image_flag": 'segment',  # 'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": [16, 32, 64, 128],
        'mlp': {'b1': [8, 8], 'b2': [8, 8], 'b3': [8]},
        'classifier': [512],  # 分类器的网络结构
        'freeze': 'not',  # 'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'not',  # 'cli', 'not' 蒸馏标志位
        'transfer': 'cli',  # 'cli', 'not'迁移标志位
    }
    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }
    a = torch.randn(4, 1, 384, 384)
    b = torch.randn(4, 40)
    model = Net_resmlp(config)
    # print(model)
    outputs = model(a, b)

    # print(outputs)
    print(outputs[0].size())
    # freeze_paraments(model)
    # for child in model.children():
    #     for param in child.parameters():
    #         param.require_grad = False
    # print(list(model.children()))

    #输出模型参数
    # print("Model's state_dict:")
    # for param_tensor in model.state_dict():
    #     print(param_tensor, "\t", model.state_dict()[param_tensor].size())
    # save_model()
    # load_model(model, model)
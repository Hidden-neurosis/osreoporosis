'''
model_fusion包主要包含多模态的数据类，针对多模态网络的图像特征提取网络

fusion_dataset.py:多模态网络的数据类，以及获得同时具备两种模态的病人id
resnet18.py:多模态网络的特征提取部分
'''
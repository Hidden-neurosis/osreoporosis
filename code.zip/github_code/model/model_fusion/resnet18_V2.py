'''
此文件为多模态融合时的resnet18特征提取部分模型
'''
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from osteoV2.model.model_fusion.fusion_dataset import Dataset_multimodal
# from osteoV2.model.train import features, labels

class ResidualBlock(nn.Module):
    def __init__(self, inchannel, outchannel, stride=1):
        super(ResidualBlock, self).__init__()
        self.left = nn.Sequential(
            nn.Conv2d(inchannel, outchannel, kernel_size=3, stride=stride, padding=1, bias=False),
            nn.BatchNorm2d(outchannel),
            nn.ReLU(inplace=True),
            nn.Conv2d(outchannel, outchannel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(outchannel)
        )
        self.shortcut = nn.Sequential()
        if stride != 1 or inchannel != outchannel:
            self.shortcut = nn.Sequential(
                nn.Conv2d(inchannel, outchannel, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(outchannel)
            )

    def forward(self, x):
        out = self.left(x)
        out += self.shortcut(x)
        out = F.relu(out)
        return out

class ResNet(nn.Module):
    def __init__(self, ResidualBlock, image_size, channels, num_classes=2):  # [64, 128, 256, 512]
        super(ResNet, self).__init__()
        self.image_size = image_size
        self.inchannel = channels[0]
        self.conv1_img = nn.Sequential(
            nn.Conv2d(1, self.inchannel, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(self.inchannel),
            nn.ReLU(),
        )
        self.layer1_img = self.make_layer(ResidualBlock, channels[0], 2, stride=1)
        self.layer2_img = self.make_layer(ResidualBlock, channels[1], 2, stride=2)
        self.layer3_img = self.make_layer(ResidualBlock, channels[2], 2, stride=2)
        self.layer4_img = self.make_layer(ResidualBlock, channels[3], 2, stride=2)

    def make_layer(self, block, channels, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)   #strides=[1,1]
        layers = []
        for stride in strides:
            layers.append(block(self.inchannel, channels, stride))
            self.inchannel = channels
        return nn.Sequential(*layers)

    def forward(self, x):
        out = self.conv1_img(x)
        out = self.layer1_img(out)
        out = self.layer2_img(out)
        out = self.layer3_img(out)
        out = self.layer4_img(out)
        out = F.avg_pool2d(out, 4)
        out = out.view(out.size(0), -1)
        # out = self.fc(out)
        return out

    def get_output_size(self):
        # data = pd.read_excel(r'//home/user/suteng/data/clinical/3_modalconplete_onehot.xlsx', index_col=0, header=0,
        #                      sheet_name='Sheet1')  # 直接读取预处理后的数据
        # features = data.iloc[:, 4:]
        # labels = data.iloc[:, 3]
        # dataset = Dataset_multimodal(feature=features, label=labels)#此处变量从多模态的train引入
        # size = dataset[0][0].size()
        # print('size:',size)
        # a = torch.randn(5, size[0], size[1], size[2])#需要根据数据尺寸修改
        a = torch.randn(5, 1, self.image_size[0], self.image_size[1])
        out = self.forward(a)
        # out = out.view(len(a), -1)
        return out.size()



def ResNet18(channels=[4, 8, 16, 32], image_size=(384, 384)):

    return ResNet(ResidualBlock, image_size=image_size, channels=channels,  num_classes=2)

def ResNet18_class(n_classes, channels=[4, 8, 16, 32], image_size=(384, 384)):

    return ResNet(ResidualBlock, image_size=image_size, channels=channels,  num_classes=n_classes)
if __name__ == '__main__':
    a = torch.randn(4, 1, 384, 384)
    b = torch.randn(4, 30)
    model = ResNet18()
    outputs = model(a)
    # # print(outputs)
    print(outputs.size())
    print(model.get_output_size())
    # print(list(model.children()))
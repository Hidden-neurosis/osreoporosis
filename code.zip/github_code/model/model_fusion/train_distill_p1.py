import os
import time
import cv2
import copy
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import pandas as pd
import torch.backends.cudnn
import matplotlib.pyplot as plt
from torch.utils.tensorboard import SummaryWriter
from osteoV2.model.image.image_dataset import Dataset_image
from osteoV2.model.model_fusion.resnet18_V2 import ResNet18
from sklearn.metrics import roc_auc_score
from osteoV2.model.image.excel_name import get_excel_name
from osteoV2.model.model_fusion.net_fusion import Net
from osteoV2.model.model_fusion.train_distill_p2 import get_loader, setup_seed, test, auc_compute, get_teacher_label
from ray import tune
global writer_train, writer_val
from osteoV2.model.model_fusion.loss_multimodal import Loss_Distill_Target

def train(config, model, device, model_save_dir, trainloader, valloader, checkpoint_dir=None, data_dir=None):
    global writer_train, writer_val
    epoch_num = config["epoch_num"]
    lr = config["lr"]
    step_size = config["step_size"]
    label = {#存放真实标签和预测标签
        'train': {'real': [], 'predict': []},
        'val': {'real': [], 'predict': []}
    }
    result = {#用于存放最后的各种指标结果
        'train': {'accuracy': 0.0, 'auc': 0.0},
        'val': {'accuracy': 0.0},
        'test': {'accuracy': 0.0, 'auc': 0.0},
    }

    criterion = Loss_Distill_Target(alpha=0.5, beta=0.5, T=1)

    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    # optimizer = optim.Adam(model.parameters(), lr=lr)
    #step_size为几个epoch进行衰减，gamma为衰减系数
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)

    '''checkpoint可以进行断点继续训练，保存模型时要将很多必要的状态都保存，此处是进行断点数据的读取'''
    if checkpoint_dir:
        model_state, optimizer_state = torch.load(
            os.path.join(checkpoint_dir, "checkpoint"))
        # model_state, optimizer_state = torch.load(checkpoint_dir)
        model.load_state_dict(model_state)
        optimizer.load_state_dict(optimizer_state)


    best_acc = 0.0#保存当前最好的准确率
    best_model = model
    best_model_wts = copy.deepcopy(model.state_dict())
    mini_batches_num = 5#训练时每过mini_batches_num个batchsize打印loss
    for epoch in range(epoch_num):  # loop over the dataset multiple times
        running_loss = 0.0# 保存每个mini_batches的loss之和，用于打印，打印后清空
        train_total = 0# 保存每个epoch的总的个数
        train_correct = 0# 保存每个epoch的正确的个数
        train_loss = 0.0
        train_i = 0
        for i, data in enumerate(trainloader, 0):
            # get the inputs; data is a list of [inputs, labels]
            inputs_image, features, labels = data
            inputs_image, features, labels = inputs_image.to(device), features.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs_image, features)#[N, C, H, W]
            softlable_outputs, softlable_img, softlable_cli = get_teacher_label(outputs, inputs_image, features, device)
            loss = criterion(softlable_outputs, softlable_img, softlable_cli, labels, outputs)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            train_loss += loss.item()
            train_i += 1
            _, predicted = torch.max(outputs.data, 1)#将多分类的onehot编码转换成单个类别数字编码
            # _, labels = torch.max(labels, 1)
            # 每个epoch准确率
            train_total += labels.size(0)
            train_correct += ((predicted == labels).sum().item())

            # 结果保存，用于计算各种指标
            labels = labels.cpu()
            outputs = F.softmax(outputs, dim=1)
            outputs = outputs.cpu()
            labels = labels.detach().numpy()
            outputs = outputs.detach().numpy()
            label['train']['real'].extend(labels)
            label['train']['predict'].extend(outputs)

            if i % mini_batches_num == (mini_batches_num - 1):  # print every mini-batches-num
                # print("Train mini-batches [%d, %5d] loss: %.3f" % (epoch + 1, i + 1,
                #                                 running_loss / mini_batches_num))
                running_loss = 0.0
        train_loss = train_loss / train_i
        train_acc = train_correct / train_total
        if flag_print:
            print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" % (epoch + 1, epoch_num, train_loss, train_acc))
        scheduler.step()




        # Validation loss
        val_loss = 0.0
        val_steps = 0
        val_total = 0
        val_correct = 0
        val_i = 0
        for i, data in enumerate(valloader, 0):
            with torch.no_grad():
                inputs_image, features, labels = data
                inputs_image, features, labels = inputs_image.to(device), features.to(device), labels.to(device)
                outputs = model(inputs_image, features)
                softlable_outputs, softlable_img, softlable_cli = get_teacher_label(outputs, inputs_image, features, device)
                loss = criterion(softlable_outputs, softlable_img, softlable_cli, labels, outputs)
                #loss
                # print('val outputs:\n', outputs)
                # print('val labels:\n', labels)
                val_loss += loss.cpu().numpy()
                val_steps += 1
                val_i += 1
                running_loss += loss.item()

                # 输出最大概率的类，predicted为max对应的index
                _, predicted = torch.max(outputs.data, 1)
                val_total += labels.size(0)
                val_correct += ((predicted == labels).sum().item())

                # 结果保存，用于计算各种指标
                labels = labels.cpu()
                outputs = F.softmax(outputs, dim=1)
                outputs = outputs.cpu()
                labels = labels.detach().numpy()
                outputs = outputs.detach().numpy()
                label['val']['real'].extend(labels)
                label['val']['predict'].extend(outputs)


        val_loss = val_loss / val_i
        val_acc = val_correct / val_total
        if flag_print:
            print('Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' % (epoch + 1, epoch_num, val_loss, val_acc))
            print('\n')

        # 利用验证集找出最好模型
        if val_acc > best_acc:
            best_acc = val_acc
            best_model_wts = copy.deepcopy(model.state_dict())
            best_model = copy.deepcopy(model)
            if flag_print:
                print('better model getted')
            result['train']['accuracy'] = train_acc
            result['val']['accuracy'] = val_acc

        #将数据传入tensorboard
        if flag_tensorboard:
            writer_train.add_scalar('loss', train_loss, epoch)
            writer_train.add_scalar('accuracy', train_acc, epoch)
            writer_val.add_scalar('loss', val_loss, epoch)
            writer_val.add_scalar('accuracy', val_acc, epoch)
    if flag_tensorboard:
        writer_train.flush()
        writer_val.flush()
    model.load_state_dict(best_model_wts)
    if flag_model_save:
        torch.save(best_model.state_dict(), model_save_dir)  # 只保存模型参数
    if flag_print:
        print('The Best Valdition |  accuracy: %.3f |' % best_acc)
    return model, result, label



def main(config):
    global writer_train, writer_val
    image_size = config['image_size']
    seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546]  # ,
    # 8345, 28934, 209345, 599484, 30994, 9394, 92389, 39494, 394903, 1349]


    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        device = torch.device('cuda')
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    if flag_print:
        print('device:', device)
    '''================================================'''
    excel_name = get_excel_name(config, transform_config)

    data = pd.read_excel(r'//home/user/suteng/data/CT-sagittal/segment_crop/二分类_齐鲁省立汇总不缺失_image.xlsx', index_col=0, header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 2:]
    labels = data.iloc[:, 0]
    # print('features:\n', features)
    # print('labels:\n', labels)

    accuracy_test_average = 0#
    result = pd.DataFrame(index=range(len(seeds)),
                          columns=['seed', 'accuracy_train', 'accuracy_val', 'accuracy_test', 'auc_train', 'auc_test'])
    for i, seed in zip(range(len(seeds)), seeds):
        setup_seed(seed)
        if flag_print:
            print('-----seed=%d-----' % seed)
        trainloader, valloader, testloader = get_loader(config, transform_config, features, labels, seed)

        '''==================训练======================='''
        if flag_tensorboard:
            writer_train = SummaryWriter('/home/user/suteng/osteo/runs/multimodal/'
                                         + excel_name + '/seed' + str(seed) + '/train/')
            writer_val = SummaryWriter('/home/user/suteng/osteo/runs/multimodal/'
                                       + excel_name + '/seed' + str(seed) + '/val/')

        model = Net(config, n_classes=2)
        if flag_model_load:
            model.load_state_dict(torch.load(model_load))
        model.to(device)
        model, result_metric, label_train = train(config, model, device, model_save_dir=model_save,
                                                  trainloader=trainloader, valloader=valloader)
        result_metric['test']['accuracy'], label_test = test(model, device, testloader)
        accuracy_test_average += result_metric['test']['accuracy']
        if flag_tensorboard:
            writer_train.close()
            writer_val.close()

        #AUC指标计算
        result = auc_compute(result, result_metric, label_train, label_test, seed, i, n_class=2)
        if flag_print:
            print('---------------' + ('-'*len(str(seed))))
    result.loc['mean'] = result.mean()
    if flag_print:
        print(result)
    result.to_excel(r'/home/user/suteng/osteo_results/multimodal/' + excel_name + '.xlsx')
    if flag_print:
        print('The Test Average Accuracy:', accuracy_test_average / len(seeds))
    tune.report(
        acc_train=result.loc['mean', 'accuracy_train'],
        acc_val=result.loc['mean', 'accuracy_val'],
        acc_test=result.loc['mean', 'accuracy_test'],
                )
    return

if __name__ == '__main__':

    '''==================参数设置======================='''
    flag_print = True
    flag_tensorboard = True
    flag_model_load = False
    model_load = '/home/user/suteng/osteo/osteoV2/model_save/multimodal/'
    flag_model_save = False
    model_save = '/home/user/suteng/osteo/osteoV2/model_save/multimodal/'
    config = {
        "epoch_num": 90,
        "step_size": 30,
        "lr": 0.001,
        "batch_size": tune.grid_search([8, 16]),
        "image_flag": 'segment',#'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": [8, 8, 8, 8],
        #          tune.grid_search([
        #     [4, 4, 4, 4], [8, 8, 8, 8], [16, 16, 16, 16], [32, 32, 32, 32]
        # ]),
        'mlp': {'b1': [2], 'b2': [4], 'b3': [4]},
        #          tune.grid_search([
        #     {'b1': [2], 'b2': [4], 'b3': [4]},
        #     {'b1': [2], 'b2': [8], 'b3': [8]},
        #     {'b1': [4], 'b2': [8], 'b3': [8]},
        #     {'b1': [4], 'b2': [16], 'b3': [16]},
        #     {'b1': [8], 'b2': [16], 'b3': [16]},
        #     {'b1': [2, 2], 'b2': [4, 4], 'b3': [4]},
        #     {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]},
        #     {'b1': [4, 4], 'b2': [8, 8], 'b3': [8]},
        #     {'b1': [8, 4], 'b2': [16, 8], 'b3': [8]},
        #     {'b1': [2, 2], 'b2': [4, 4], 'b3': [4, 4]},
        #     {'b1': [4, 4], 'b2': [4, 4], 'b3': [4, 4]},
        #     {'b1': [4, 4], 'b2': [8, 8], 'b3': [8, 8]},
        #     {'b1': [8, 4], 'b2': [16, 8], 'b3': [8, 8]},
        # ]),
        'classifier': [512],#分类器的网络结构
        'freeze': 'not',#'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'not',#'cli', 'not' 蒸馏标志位
        'transfer': 'not',#'cli', 'not'迁移标志位
    }
    transform_config = {
        'rot': (-25, 25),#旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }

    #输入为四节椎骨还是一节椎骨
    # torch.backends.cudnn.enabled = False
    os.environ[
        "CUDA_VISIBLE_DEVICES"] = '0'  # CUDA_VISIBLE_DEVICES限制一下使用的GPU。比如有0,1,2,3号GPU，CUDA_VISIBLE_DEVICES=2,3，则当前进程的可见GPU只有物理上的2、3号GPU，此时它们的编号也对应变成了0、1，即cuda:0对应2号GPU，cuda:1对应3号GPU

    '''================================================'''
    absolute_path = '/home/user/suteng/osteo'
    # result = tune.run(
    #     main,
    #     resources_per_trial={"cpu": 28, "gpu": 1},  # 运行时的资源限制
    #     config=config,
    #     local_dir=absolute_path + '/ray_results/multimodal',  # 运行以及保存结果的位置
    #     # num_samples=3,  # random search时的采样次数
    # )

    config = {
        "epoch_num": 90,
        "step_size": 30,
        "lr": 0.001,
        "batch_size": 8,
        "image_flag": 'segment',#'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": [8, 8, 8, 8],
        'mlp': {'b1': [2], 'b2': [4], 'b3': [4]},
        'classifier': [512],#分类器的网络结构
        'freeze': 'not',#'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'not',#'cli', 'not' 蒸馏标志位
        'transfer': 'not',#'cli', 'not'迁移标志位
    }
    main(config)






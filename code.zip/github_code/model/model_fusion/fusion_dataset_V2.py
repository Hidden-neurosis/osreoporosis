import os
import random

import cv2
import torch, torchvision
import numpy as np
import pandas as pd
from pandas import DataFrame
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split

flag_test_main = 0#用于区分是否单独运行该py文件的标志位

'''计算训练集图像的均值与方差'''
def image_mean_std(id :DataFrame.index, flag: str, dim: int = 1):
    '''
    :param id: 划分好的训练集病人id, list
    :param dim: 图像通道数
    :return:
    '''
    image_path = '/home/user/suteng/data/CT-sagittal/segment_crop'
    image_path += '/' + flag
    dir = os.walk(image_path)
    mean = torch.zeros(dim)
    std = torch.zeros(dim)
    for root, dirs, files in dir:
        # print('root:', root)
        # print('dirs:', dirs)
        if files != [] and dirs == []:
            # print('files:', files)
            name, endings = os.path.splitext(files[0])
            # print(name, type(name))
            if flag == 'crop':
                name, Ln = name.split('_', 2)
            elif flag == 'segment':
                Ln = 'L1-4'

            if (name in id or int(name) in id) and \
                    (Ln == 'L1-4' or Ln == 'L1' or Ln == 'L2' or Ln == 'L3' or Ln == 'L4'):
                image_name = root + '/' + files[0]
                X = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
                if dim == 1:
                    mean += X[:, :].mean()
                    std += X[:, :].std()
                elif dim > 1:
                    for d in range(dim):
                        mean[d] += X[d, :, :].mean()
                        std[d] += X[d, :, :].std()

    mean.div_(len(id) * 255)
    std.div_(len(id) * 255)
    return list(mean.numpy()), list(std.numpy())

'''读取多模态形式的数据，包括png格式的分割完的矢状位的CT图像和实验室指标'''
class Dataset_multimodal_segment_png(Dataset):
    def __init__(self, feature: DataFrame, label: DataFrame, means, stds, image_size, stage, transform_config=None):#输入为dataframe形式的label，index为住院号
        '''

        :param label: 输入为dataframe形式的label，index为住院号
        :param means: 训练集图像均值
        :param stds: 训练集图像方差
        :param stage: 设定是否为训练阶段，'train' 'not_train'
        '''
        self.feature = feature
        self.label = label
        # self.image_path = '/home/user/suteng/data/CT-sagittal/segment_crop/segment/label'
        self.image_path = '/home/user/suteng/osteo_data/Dataset/segment/label'
        if flag_test_main:
            print('means, stds:', means, stds)
        self.stage = stage
        self.transform = {
            'train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.RandomVerticalFlip(p=0.5),
                    transforms.RandomRotation(degrees=transform_config['rot']),
                    transforms.ColorJitter(brightness=transform_config['col'][0], contrast=transform_config['col'][1]),
                    transforms.Normalize(means, stds)
                ]),
            'not_train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.Normalize(means, stds)
                ]),
        }

    def __len__(self):
        return len(self.label)

    def feature_aug(self, feature):
        return feature

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        label = self.label.loc[image_name]
        feature = self.feature.loc[image_name]
        feature = self.feature_aug(feature)
        # label = float(label)
        image_name = os.path.join(self.image_path + str(label), str(image_name), str(image_name) + '.png')
        image = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
        image = self.transform[self.stage](image)
        label = torch.tensor(int(label))
        feature = torch.tensor(feature)
        feature = feature.to(torch.float32)

        return image, feature, label

class Dataset_multimodal_noise(Dataset_multimodal_segment_png):
    def __init__(self, feature: DataFrame, label: DataFrame, means, stds, image_size, stage, transform_config=None):
        super(Dataset_multimodal_noise, self).__init__(feature, label, means, stds, image_size, stage, transform_config)


    def feature_aug(self, feature):
        '''
        获取每个特征的所有样本间的平均值和方差， 随机加上高斯噪声
        '''
        return feature + random.gauss(feature.mean(), feature.std())

'''读取bmp格式的矢状位CT图像及临床数据'''
class Dataset_multimodal_crop_png(Dataset):
    def __init__(self, label: DataFrame):#输入为dataframe形式的label，index为住院号
        self.label = label
        self.image_path = '/home/user/suteng/data/CT-sagittal/segment_crop/segment/label'
        self.transform = transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((384, 384)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        label = self.label.loc[image_name, '骨质疏松']
        label = float(label)
        feature = self.label.loc[image_name]
        feature = feature.iloc[2:]
        image_name = self.image_path + str(label) + '/' + str(image_name) + '/' + str(image_name) + '.png'
        image = cv2.imread(image_name)
        image = self.transform(image)
        label = torch.tensor(label)
        feature = torch.tensor(feature)
        feature = feature.to(torch.float32)

        return image, feature, label



if __name__ == '__main__':
    flag_test_main = 1
    # id_label = '/home/user/suteng/data/CT-sagittal/segment_crop/segment_crop_id_label.xlsx'
    # feature_path = '/home/user/suteng/data/CT-sagittal/segment_crop/二分类_齐鲁省立汇总不缺失_image.xlsx'
    # data = pd.read_excel(feature_path, index_col=0, header=0, sheet_name='Sheet1')
    # # print(data.loc[17037394, 'label'])
    # dataset = Dataset_image_segment_png(data)
    # print(dataset[
    # 3])
    transform_config={
        'rot': (-25, 25),#旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }
    BATCH_SIZE = 10
    data = pd.read_excel(r'//home/user/suteng/data/CT-sagittal/segment_crop/二分类_齐鲁省立汇总不缺失_image.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 2:]
    labels = data.iloc[:, 0]

    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train)

    # print(y_train)
    '''loader'''

    # print(x_train.shape)
    means, stds, image_size = 0.5, 0.5, (384, 384)
    dataset = Dataset_multimodal_segment_png
    train_dataset = dataset(x_train, y_train, means, stds, image_size, stage='train', transform_config=transform_config)
    # print(train_dataset[0])
    val_dataset = dataset(x_train, y_train, means, stds, image_size, stage='not_train', transform_config=transform_config)
    test_dataset = dataset(x_train, y_train, means, stds, image_size, stage='not_train', transform_config=transform_config)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True)
    valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=BATCH_SIZE,
                                            shuffle=True)
    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=True)

    for i, data in enumerate(trainloader, 0):
        # get the inputs; data is a list of [inputs, labels]
        inputs_image, features, labels = data
        print('trainloader', i)
        print(inputs_image.size(), features.size(), labels.size())
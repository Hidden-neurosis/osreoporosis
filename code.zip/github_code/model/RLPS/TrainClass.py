import torch
import torch.nn as nn
import torch.nn.functional as F
import copy
from sklearn.model_selection import train_test_split
from torch import optim
from torch.utils.data import DataLoader
from dataset import DatasetSelector, DatasetClassifier
from ImgSelector import ImgSelector

def datasplit(features, labels, seed):
    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels, random_state=seed)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train, random_state=seed)
    max = x_train.max()
    min = x_train.min()
    '''归一化'''
    x_train = (x_train - min) / (max - min)
    x_val = (x_val - min) / (max - min)
    x_test = (x_test - min) / (max - min)
    return x_train, y_train, x_val, y_val, x_test, y_test


class Train:
    def __init__(self, model, device, dataset, batchsize, epoch_nums):
        self.device = device
        self.model = model
        self.trainloader = None
        self.valloader = None
        self.dataset = dataset
        self.train_dataset = None
        self.val_dataset = None
        self.batchsize = batchsize
        self.epoch_num = epoch_nums
        self.criterion = None
        self.optimizer = None
        self.scheduler = None

    def get_loader(self, x_train, y_train, x_val, y_val):
        self.train_dataset = self.dataset(x_train, y_train)
        self.val_dataset = self.dataset(x_val, y_val)

        self.trainloader = torch.utils.data.DataLoader(dataset=self.train_dataset,
                                                  batch_size=self.batchsize,
                                                  shuffle=True)
        self.valloader = torch.utils.data.DataLoader(dataset=self.val_dataset,
                                                batch_size=self.batchsize,
                                                shuffle=True)

    def get_loader_img(self, x_train, y_train, x_val, y_val):
        self.train_dataset = self.dataset(y_train, image_size=(384, 384), stage='train')
        self.val_dataset = self.dataset(y_val, image_size=(384, 384), stage='not_train',
                                        means=self.train_dataset.means, stds=self.train_dataset.stds)

        self.trainloader = torch.utils.data.DataLoader(dataset=self.train_dataset,
                                                  batch_size=self.batchsize,
                                                  shuffle=True)
        self.valloader = torch.utils.data.DataLoader(dataset=self.val_dataset,
                                                batch_size=self.batchsize,
                                                shuffle=True)

    def train(self, save_path):
        optimizer = self.optimizer
        scheduler = self.scheduler
        criterion = self.criterion
        label = {  # 存放真实标签和预测标签
            'train': {'real': [], 'predict': []},
            'val': {'real': [], 'predict': []}
        }
        result = {  # 用于存放最后的各种指标结果
            'train': {'accuracy': 0.0},
            'val': {'accuracy': 0.0}
        }
        best_acc = 0.0  # 保存当前最好的准确率
        best_model = self.model
        best_model_wts = copy.deepcopy(self.model.state_dict())
        mini_batches_num = 5  # 训练时每过mini_batches_num个batchsize打印loss
        for epoch in range(self.epoch_num):  # loop over the dataset multiple times
            train_total = 0  # 保存每个epoch的总的个数
            train_correct = 0  # 保存每个epoch的正确的个数
            train_loss = 0.0
            train_i = 0
            for i, data in enumerate(self.trainloader, 0):
                # get the inputs; data is a list of [inputs, labels]
                inputs, labels = data
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                optimizer.zero_grad()

                outputs = self.model(inputs)  # [N, C, H, W]
                # imshow_tensor(labels[0, 0, :, :])

                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                train_loss += loss.item()
                train_i += 1
                _, predicted = torch.max(outputs.data, 1)  # 将多分类的onehot编码转换成单个类别数字编码
                # _, labels = torch.max(labels, 1)
                # 每个epoch准确率
                train_total += labels.size(0)
                train_correct += ((predicted == labels).sum().item())

                # 结果保存，用于计算各种指标
                labels = labels.cpu()
                outputs = F.softmax(outputs, dim=1)
                outputs = outputs.cpu()
                labels = labels.detach().numpy()
                outputs = outputs.detach().numpy()
                label['train']['real'].extend(labels)
                label['train']['predict'].extend(outputs)

            train_loss = train_loss / train_i
            train_acc = train_correct / train_total
            print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" % (
                epoch + 1, self.epoch_num, train_loss, train_acc))
            scheduler.step()

            # Validation loss
            val_loss = 0.0
            val_steps = 0
            val_total = 0
            val_correct = 0
            val_i = 0
            for i, data in enumerate(self.valloader, 0):
                with torch.no_grad():
                    inputs, labels = data
                    inputs, labels = inputs.to(self.device), labels.to(self.device)
                    outputs = self.model(inputs)
                    # loss
                    # print('val outputs:\n', outputs)
                    # print('val labels:\n', labels)
                    loss = criterion(outputs, labels)
                    val_loss += loss.cpu().numpy()
                    val_steps += 1
                    val_i += 1

                    # 输出最大概率的类，predicted为max对应的index
                    _, predicted = torch.max(outputs.data, 1)
                    # print('val predicted:\n', predicted)
                    # 准确率打印
                    val_total += labels.size(0)
                    val_correct += ((predicted == labels).sum().item())

                    # 结果保存，用于计算各种指标
                    labels = labels.cpu()
                    outputs = F.softmax(outputs, dim=1)
                    outputs = outputs.cpu()
                    labels = labels.detach().numpy()
                    outputs = outputs.detach().numpy()
                    label['val']['real'].extend(labels)
                    label['val']['predict'].extend(outputs)

                    # print("Valdition [%d, %5d] loss: %.3f" % (epoch + 1, i + 1, val_loss))
                    # print('Valdition accuracy:', val_correct / val_total)
                    # val_loss = 0.0
            val_loss = val_loss / val_i
            val_acc = val_correct / val_total
            print(
                'Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' % (epoch + 1, self.epoch_num, val_loss, val_acc))

            # 利用验证集找出最好模型
            if val_acc > best_acc:
                best_acc = val_acc
                best_model_wts = copy.deepcopy(self.model.state_dict())
                best_model = copy.deepcopy(self.model)
                print('better model getted')
                result['train']['accuracy'] = train_acc
                result['val']['accuracy'] = val_acc
        torch.save(best_model_wts, save_path)

    def train_classifier(self, save_path):
        optimizer = self.optimizer
        scheduler = self.scheduler
        criterion = self.criterion
        label = {  # 存放真实标签和预测标签
            'train': {'real': [], 'predict': []},
            'val': {'real': [], 'predict': []}
        }
        result = {  # 用于存放最后的各种指标结果
            'train': {'accuracy': 0.0},
            'val': {'accuracy': 0.0}
        }
        best_acc = 0.0  # 保存当前最好的准确率
        best_model = self.model
        best_model_wts = copy.deepcopy(self.model.state_dict())
        mini_batches_num = 5  # 训练时每过mini_batches_num个batchsize打印loss
        for epoch in range(self.epoch_num):  # loop over the dataset multiple times
            train_total = 0  # 保存每个epoch的总的个数
            train_correct = 0  # 保存每个epoch的正确的个数
            train_loss = 0.0
            train_i = 0
            for i, data in enumerate(self.trainloader, 0):
                # get the inputs; data is a list of [inputs, labels]
                inputs, labels = data
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                optimizer.zero_grad()

                fea, outputs = self.model(inputs)  # [N, C, H, W]
                # imshow_tensor(labels[0, 0, :, :])
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                train_loss += loss.item()
                train_i += 1
                _, predicted = torch.max(outputs.data, 1)  # 将多分类的onehot编码转换成单个类别数字编码
                # _, labels = torch.max(labels, 1)
                # 每个epoch准确率
                train_total += labels.size(0)
                train_correct += ((predicted == labels).sum().item())

                # 结果保存，用于计算各种指标
                labels = labels.cpu()
                outputs = F.softmax(outputs, dim=1)
                outputs = outputs.cpu()
                labels = labels.detach().numpy()
                outputs = outputs.detach().numpy()
                label['train']['real'].extend(labels)
                label['train']['predict'].extend(outputs)

            train_loss = train_loss / train_i
            train_acc = train_correct / train_total
            print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" % (
                epoch + 1, self.epoch_num, train_loss, train_acc))
            scheduler.step()

            # Validation loss
            val_loss = 0.0
            val_steps = 0
            val_total = 0
            val_correct = 0
            val_i = 0
            for i, data in enumerate(self.valloader, 0):
                with torch.no_grad():
                    inputs, labels = data
                    inputs, labels = inputs.to(self.device), labels.to(self.device)
                    fea, outputs = self.model(inputs)
                    # loss
                    # print('val outputs:\n', outputs)
                    # print('val labels:\n', labels)
                    loss = criterion(outputs, labels)
                    val_loss += loss.cpu().numpy()
                    val_steps += 1
                    val_i += 1

                    # 输出最大概率的类，predicted为max对应的index
                    _, predicted = torch.max(outputs.data, 1)
                    # print('val predicted:\n', predicted)
                    # 准确率打印
                    val_total += labels.size(0)
                    val_correct += ((predicted == labels).sum().item())

                    # 结果保存，用于计算各种指标
                    labels = labels.cpu()
                    outputs = F.softmax(outputs, dim=1)
                    outputs = outputs.cpu()
                    labels = labels.detach().numpy()
                    outputs = outputs.detach().numpy()
                    label['val']['real'].extend(labels)
                    label['val']['predict'].extend(outputs)

                    # print("Valdition [%d, %5d] loss: %.3f" % (epoch + 1, i + 1, val_loss))
                    # print('Valdition accuracy:', val_correct / val_total)
                    # val_loss = 0.0
            val_loss = val_loss / val_i
            val_acc = val_correct / val_total
            print(
                'Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' % (epoch + 1, self.epoch_num, val_loss, val_acc))

            # 利用验证集找出最好模型
            if val_acc > best_acc:
                best_acc = val_acc
                best_model_wts = copy.deepcopy(self.model.state_dict())
                best_model = copy.deepcopy(self.model)
                print('better model getted')
                result['train']['accuracy'] = train_acc
                result['val']['accuracy'] = val_acc
        torch.save(best_model_wts, save_path)

if __name__ == '__main__':
    policy = ImgSelector()
    device = 'cpu'
    lr = 0.001
    step_size = 10
    selector = Train(policy, device, DatasetSelector, batchsize=16, epoch_nums=20)
    selector.criterion = nn.CrossEntropyLoss()
    selector.optimizer = optim.SGD(selector.model.parameters(), lr=lr, momentum=0.9)
    selector.scheduler = torch.optim.lr_scheduler.StepLR(selector.optimizer, step_size, gamma=0.1, last_epoch=-1)

    for j in range(selector.train_dataset.getImgNums(0)):#取图片的各种情况循环
        x_train, y_train, x_val, y_val, x_test, y_test = datasplit(features, labels)
        selector.get_loader(x_train, y_train, x_val, y_val)
        selector.train()
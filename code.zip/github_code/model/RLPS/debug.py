import pandas as pd
import numpy as np
label_index = np.arange(16)
label = pd.DataFrame(np.arange(10, 26),
                 index=label_index)
print(label)
index = [1, 2]
index = [x for x in label.index if x in index]
print(index)
label = label.loc[index, :]
print(label)
import torch
import torch.nn as nn

class ImgSelector(nn.Module):#ImgSelector结构为全连接层
    def __init__(self, struct=None):
        if struct is None:
            struct = [256, 64, 32, 16, 8, 2]
        super(ImgSelector, self).__init__()
        self.layers = nn.ModuleList()
        self.sigmoid = nn.Sigmoid()
        for i in range(len(struct)-1):
            self.layers.append(nn.Linear(struct[i], struct[i+1]))
            if i == len(struct)-2:
                self.layers.append(self.sigmoid)
            else:
                self.layers.append(nn.ReLU())

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

if __name__ == '__main__':
    config = [16, 8, 3]
    model = ImgSelector(config)
    print(model)

    config = [32, 3]
    model = ImgSelector(config)
    print(model)

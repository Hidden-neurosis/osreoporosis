import copy
import math
import os
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import f1_score, accuracy_score
from sklearn.model_selection import train_test_split
from torch.optim import Adam
from torch.utils.data import DataLoader
import torch.nn.functional as F
import torch.optim as optim
from ImgSelector import ImgSelector
from Classifier import qnet
from TrainClass import Train, datasplit
from dataset import DatasetSelector, DatasetClassifier

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True

class RLe2e:
    def __init__(self, init_alpha, data_dir, device):
        self.device = device
        self.action_label = None
        self.data_dir = data_dir#图片数据集所在的路径
        self.labels = None#所有数据的标签
        self.features = None#所有数据
        self.nimgs_i = None # 取不同图像的情况数
        self.id_now = None#当前epoch操作的图像id

        # self.selector_path = os.path.join(self.data_dir, "../shallow_cnn_noise_e2e.h5")
        self.classifier_path = './classifier_save/pretrain.pth'
        self.classifier_savepath = './classifier_save/trained_1225.pth'
        self.policy_path = './policy_save'
        self.policy = self.build_model()#图像筛选器
        self.policy = self.policy.to(device)
        self.classifier = qnet()#图像分类器
        self.classifier = self.classifier.to(device)

        self.batch_size = 16
        self.img_emb_dim = 128#特征向量的维度
        # self.classifier.load_state_dict(torch.load(PATH), strict=False)

        self.train_data, self.train_label_, self.train_label, self.train_face_label, \
            self.test_data, self.test_label, self.test_action_data, self.test_action_label = self.getdata()

        self.num_data, self.num_test_action_data, self.num_labels, self.num_each_label = self.getdata_num()

        # 所有样本的状态保存矩阵 （样本数*网络输出个数）,然后添加一列，即令第一列为id住院号
        self.state_feat = np.zeros((self.num_data, self.img_emb_dim))
        self.emb_input = np.zeros((self.num_data, self.img_emb_dim * 2)) #输入筛选器的特征向量，为之前状态平均值与当前状态的向量的拼接
        self.i_emb_in = 0 #记录是第几个特征向量
        self.test_emb = np.zeros((self.num_test_action_data, self.img_emb_dim))

        self.score = np.zeros(self.num_data, dtype=np.float32)#即为论文中的reward

        #初始化state_feat
        self.imgdataset = None
        self.init_statefeat(self.batch_size)
        self.get_nimgs_i()

        f1 = f1_score(self.label, self.pred_label, average='macro')
        self.tot_avg_score = np.mean(self.score)
        total_score = np.sum(self.score)
        self.total_score = []
        self.total_f1 = []
        self.total_score.append(total_score)
        self.total_f1.append(f1)
        print('avg_score:{} total_score:{}'.format(self.tot_avg_score, total_score))
        self.sample_time = 1

        self.best_ratio = 0.0
        self.best_f1 = 0.0

        self.final_selected_img = []
        self.selected_img_set = []
        self.selected_img = []
        self.rewards = []
        self.max_avg_score = self.tot_avg_score
        self.alpha = init_alpha / 16

        self.best_acc = 0

    def getdata(self):
        '''需要修改,face_label有什么用？？？'''
        # test_action is used to check whether the effect of the selector is consistent with the ideal effect
        train_label_ = pd.read_excel('../../dataRLPS/class3_image.xlsx', usecols=[0, 2], index_col=0)
        self.labels = train_label_
        self.features = train_label_
        noise_id = train_label_.index
        clean_id = []
        train_data = noise_id
        train_face_label = None
        test_data = []
        test_action_data = noise_id
        # test_action_label = noise_face_label
        # test_action_label[test_action_label <= 1] = 1
        # test_action_label[test_action_label > 1] = 0
        # del noise_data
        del clean_id
        # train_label_ -= 1
        test_label = None
        # test_label -= 1
        train_label = torch.squeeze(F.one_hot(torch.from_numpy(train_label_.values).to(torch.int64), num_classes=3))#类别变为独热编码形式
        test_action_label = np.zeros((10, 3))
        # test_label = F.one_hot(test_label, num_classes=-1)
        # test_action_label = F.one_hot(test_action_label, num_classes=-1)
        return train_data, train_label_, train_label, train_face_label, test_data, test_label, test_action_data, test_action_label

    def getdata_num(self):
        num_data = self.train_label.shape[0]#数据的数量
        num_test_action_data = self.test_action_label.shape[0]
        num_labels = 3#类别数
        num_each_label = torch.sum(self.train_label, dim=0)
        print("Distribution over labels: {}".format(num_each_label))
        return num_data, num_test_action_data, num_labels, num_each_label

    def get_nimgs_i(self):
        path = '../../data/img_num=5/label'
        nimgs_i = pd.Series(np.zeros(len(Labels.index), dtype=int), index=Labels.index)
        for label in ['0', '1', '2']:
            ids = os.listdir(path + label)
            for id in ids:
                nimgs_i[int(id)] = int(len(os.listdir(os.path.join(path + label, id))))
        print(nimgs_i)#(533,1),读取文件夹时有一些label的多余样本没有去除
        print('读取错误的nimg_i：', nimgs_i[nimgs_i <= 0])

    def init_statefeat(self, batch_size):
        '''按顺序依次取出一个batch的数据，并获得各样本的网络输出，存入state_feat中'''
        print('---'*16, 'init_statefeat', '---'*16)
        score = np.zeros((self.num_data, 3), dtype=np.float32)
        self.imgdataset = DatasetClassifier(Labels, image_size=(384, 384), stage='not_train', means=means, stds=stds)
        loader = torch.utils.data.DataLoader(dataset=self.imgdataset,
                                                  batch_size=16,
                                                  shuffle=False)#此处设置为False，保证输出顺序不变
        with torch.no_grad():
            for i, data in enumerate(loader, 0):
                inputs_image, labels = data
                inputs_image, labels = inputs_image.to(self.device), labels.to(self.device)
                label_emb, s = self.classifier(inputs_image)
                # print(i*batch_size, min((i+1)*batch_size-1, len(dataset)), label_emb.size())
                '''注意self.state_feat的顺序问题'''
                self.state_feat[i*batch_size: min((i+1)*batch_size, len(self.imgdataset))] = label_emb.cpu()
                score[i*batch_size: min((i+1)*batch_size, len(self.imgdataset))] = 3
        print(np.shape(self.state_feat))

        # 初始化各样本得分
        self.label = np.argmax(self.train_label, axis=-1)
        self.pred_label = np.argmax(score, axis=-1)
        # 对得分做减平均值处理,得到最终得分
        for i in range(self.num_data):
            label = self.label[i]
            self.score[i] = score[i][label] - np.mean(score[i])
        print(np.shape(self.score))
        self.update_emb_input()#更新self.emb_input状态

        '''暂时不使用测试集'''
        # # 按顺序依次取出一个batch的测试数据，并获得各样本的网络输出，存入state_feat中
        # lo, hi = 0, 0
        # while lo < self.num_test_action_data:
        #     if lo + batch_size < self.num_test_action_data:
        #         hi = lo + batch_size
        #     else:
        #         hi = self.num_test_action_data
        #     label_emb, _ = self.classifier([self.test_action_data[lo: hi]])
        #     self.test_emb[lo: hi] = label_emb
        #     lo += batch_size
    def statefeat_avg(self, ti):#更新t时间状态的分类器输出向量，也即selector的输入
        if ti == 0:#初始状态为0
            t = self.state_feat[ti]
            self.emb_input[ti, self.img_emb_dim:] = t
        else:#其余状态求平均
            avg_tminus2 = self.emb_input[ti - 1, :self.img_emb_dim]#t-2时刻的平均向量
            tminus1 = self.emb_input[ti - 1, self.img_emb_dim:]#t-1时刻的向量
            t = self.state_feat[ti]#t时刻的向量
            self.emb_input[ti, :self.img_emb_dim] = ((avg_tminus2 * (ti-1)) + tminus1) / ti
            self.emb_input[ti, self.img_emb_dim:] = t


    def update_emb_input(self):#调用statefeat_avg，更新self.emb_input状态
        for i in range(len(self.emb_input)):
            self.statefeat_avg(i)
        self.i_emb_in += 1

    def update_score(self):
        '''循环输入各个样本以及每个样本的不同图像输入情况，更新各个样本的得分，每个样本都包括许多种取图片的情况'''
        best_path = self.classifier_path
        self.classifier.load_state_dict(torch.load(best_path))

        best_score = 0.
        best_i = -1
        ids = self.labels.index
        '''需要修改'''
        for id in ids:
            self.imgdataset.offset[id] = 0
            for i in range(self.nimgs_i[id]):#取图片的情况数
                _, score = self.classifier(self.imgdataset[id])
                self.pred_label = np.argmax(score, axis=-1)
                print('id:', id, ' | offset:', self.imgdataset.offset[id],
                      ' | score:', score, ' | pred_label:', self.pred_label)
                self.imgdataset.offset[id] += 1#offset递增，滑动窗口逐渐向右滑动
                if score > best_score:
                    best_score = score
                    best_i = i
            self.imgdataset.offset[id] = best_i

        #循环查找之后更新
        self.init_statefeat(self.batch_size)

    def build_model(self):
        '''构建ImgSelector'''
        model = ImgSelector()
        return model

    def get_action(self):#根据分类器的输出得到policy的训练标签action_label,如果正确预测数据，奖励reward将是一个正数
        action = np.zeros(self.num_data)
        for i in range(self.num_data):
            if self.pred_label[i] == self.label[i]:
                action[i] = 1#
            else:
                action[i] = 0#
        return action

    def decide_action(self):
        input = torch.tensor(self.emb_input, dtype=torch.float32)
        input = input.to(device)
        prob = self.policy(input)[:, 1]
        action = np.zeros(self.num_data)
        for i in range(self.num_data):
            if prob[i] > 0.49:
                action[i] = 1
            else:
                action[i] = 0
        return action

    # def update_state_feat(self, label, k, before_selection):
    #     if before_selection:
    #         self.state_feat[:self.img_emb_dim] = self.train_emb_bags[label][k]
    #     else:
    #         num_selected = len(self.selected_img)
    #         tmp_feat = self.state_feat[self.img_emb_dim:]
    #         tmp_feat = (num_selected * tmp_feat + self.train_emb_bags[label][k]) / (num_selected + 1)
    #         self.state_feat[self.img_emb_dim:] = tmp_feat

    def selection(self, epochs=100):
        print('---' * 16, 'selection', '---' * 16)
        last_update_epoch = 0

        self.action_label = np.zeros(self.num_data)

        for epoch in range(epochs):
            rl_score = 0
            total_face = 0
            half_face = 0
            none_face = 0
            shuffle_idx = list(range(self.num_data))
            random.shuffle(shuffle_idx)
            # 训练imgselector
            self.train_imgselector(epoch)

            '''更新选择的样本集与指标'''
            for k in shuffle_idx:
                # face_label = self.train_face_label[k]
                if self.final_action[k] == 1:
                    self.final_selected_img.append(k)
                    # if face_label == 0:
                    #     total_face += 1
                    # elif face_label == 1:
                    #     half_face += 1
                    # else:
                    #     none_face += 1
                    rl_score += self.score[k]
            print('self.final_selected_img: ', self.final_selected_img)
            if self.final_selected_img:  # 如果选择保留，则更新分类器模型
                rl_score /= len(self.final_selected_img)
                num_selected_img = len(self.final_selected_img)
                ratio = num_selected_img / sum(self.num_each_label)
                print('\\n', "Selected: {} images ratio:{}".format(num_selected_img, ratio))
                self.train_classifier()
            else:#如果选择remove，则只更新指标
                rl_score = 1
                ratio = 0
            print("score: {:.4f}\tratio:{:.4f}".format(rl_score, ratio))

            '''更新参数'''
            _, score = self.classifier(self.train_data)
            self.pred_label = np.argmax(score, axis=-1)
            for i in range(self.num_data):
                label = self.label[i]
                self.score[i] = score[i][label] - np.mean(score[i])

            self.tot_avg_score = np.mean(self.score)
            total_score = np.sum(self.score)
            self.total_score.append(total_score)
            f1 = f1_score(self.label, self.pred_label, average='macro')
            print(f'total_reward:{total_score}')
            self.total_f1.append(f1)

            '''这段什么意思'''
            if epoch - last_update_epoch > 16:#？？？没看懂,如果不够16个样本，就不再训练了
                break
            self.update_score()#更新各个样本的得分，即输入classifier后的Reward,需要将各种情况都输入
            self.classifier.load_state_dict(torch.load(self.classifier_path))
            '''此句需要修改'''
            _, pred = self.classifier(self.test_data, batch_size=32, verbose=1)
            y_true = np.argmax(self.test_label, axis=-1)
            y_pred = np.argmax(pred, axis=-1)
            val_acc = accuracy_score(y_true, y_pred)
            f1 = f1_score(y_true, y_pred, average='macro')
            if self.best_acc <= val_acc:
                print("Weight updated!")
                last_update_epoch = epoch
                self.best_acc = val_acc
                self.best_f1 = f1
                self.best_ratio = ratio
                self.classifier.save('shallow_cnn_nise_best_e2e.pth')
                self.policy.save('policy_noise_e2e_best.pth')
            print("val_acc: {:.4f}\tmax val_acc: {:.4f}\t f1: {:.4f}\t ratio:{:.4f}".format(val_acc, self.best_acc,
                                                                                            self.best_f1,
                                                                                            self.best_ratio))

    def train_imgselector(self, epoch):
        print('- ' * 16, 'train_imgselector', ' -' * 16)
        lr = 0.001
        step_size = 40
        BATCH_SIZE = 16
        policy_name = 'pre-train-policy-new.pth'
        savepath = os.path.join(self.policy_path, policy_name)
        print("Epoch {}".format(epoch))
        if epoch > 0:
            self.update_score()
        self.final_selected_img.clear()
        self.rewards.clear()
        for j in range(self.sample_time):#根据选择数据的次数来确定epoch的训练次数，重新训练policy模型，policy的输入为features,输出为action
            self.selected_img.clear()
            #根据分类器的输出获得标签action_label,
            self.action_label = torch.tensor(self.get_action(), dtype=torch.int64)
            self.action_label = F.one_hot(self.action_label, 2)
            distribute = torch.sum(self.action_label, dim=0)
            print(f"distribute: {distribute}")

            #selector各种参数设置
            if os.path.exists(savepath):
                self.policy.load_state_dict(torch.load(savepath))#每次训练前加载之前那个epoch训练的模型,
            '''有无设置checkpoint的必要？？？'''
            selector = Train(self.policy, device, DatasetSelector, batchsize=16, epoch_nums=10)
            selector.criterion = nn.CrossEntropyLoss()
            selector.optimizer = optim.SGD(selector.model.parameters(), lr=lr, momentum=0.9)
            selector.scheduler = torch.optim.lr_scheduler.StepLR(selector.optimizer, step_size, gamma=0.1, last_epoch=-1)

            x_train, y_train, x_val, y_val, x_test, y_test = datasplit(np.array(self.emb_input),
                                                                       np.array(self.action_label), seed)
            selector.get_loader(x_train, y_train, x_val, y_val)
            selector.train(savepath)

        self.policy.load_state_dict(torch.load(savepath))#训练后更新模型
        self.final_action = self.decide_action()#根据选择器得到动作

    def train_classifier(self):
        print('-' * 16, 'train_classifier', '-' * 16)
        lr = 0.001
        step_size = 40
        BATCH_SIZE = 16
        for j in range(self.sample_time):  # 根据选择数据的次数来确定epoch的训练次数，重新训练policy模型，policy的输入为features,输出为action
            classifier = Train(self.classifier, device, DatasetClassifier, batchsize=16, epoch_nums=100)
            classifier.criterion = nn.CrossEntropyLoss()
            classifier.optimizer = optim.SGD(classifier.model.parameters(), lr=lr, momentum=0.9)
            classifier.scheduler = torch.optim.lr_scheduler.StepLR(classifier.optimizer, step_size, gamma=0.1,
                                                                 last_epoch=-1)
            x_train, y_train, x_val, y_val, x_test, y_test = datasplit(self.features, self.labels, seed)
            classifier.get_loader_img(x_train, y_train, x_val, y_val)
            classifier.train_classifier(self.classifier_savepath)


if __name__ == '__main__':
    seed = 666
    Labels = pd.read_excel('../../dataRLPS/class3_image.xlsx', usecols=[0, 2], index_col=0, nrows=20)
    _, _, Labels_train, _ = \
        train_test_split(Labels, Labels, test_size=0.2, stratify=Labels, random_state=seed)
    train_dataset = DatasetClassifier(Labels_train, image_size=(384, 384), stage='train')
    means, stds = train_dataset.means, train_dataset.stds
    os.environ[
        "CUDA_VISIBLE_DEVICES"] = '1'
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        device = "cuda:0"
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    print('device:', device)
    # x = torch.randn((8, 128))
    # sel = ImgSelector()
    # y = sel(x)
    setup_seed(seed)
    rlps = RLe2e(1, '', device=device)
    rlps.selection(epochs=465)

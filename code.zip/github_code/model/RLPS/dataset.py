import os
import cv2
import torch, torchvision
import pandas as pd
from pandas import DataFrame
import numpy as np
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader



class DatasetSelector(Dataset):
    def __init__(self, data, label):
        self.data = data
        self.label = label[:, 1]
        # self.index = pd.Series(pd.read_excel('../../dataRLPS/class3_image.xlsx', usecols=[0, 2], index_col=0).index)

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        # index = self.index[idx]
        # print('DatasetSelector: ', idx)
        index = idx
        data = torch.tensor(self.data[index])
        data = data.to(torch.float32)
        label = torch.tensor(self.label[index])
        label = torch.tensor(int(label))
        # label = label.to(torch.float32)
        return data, label


class DatasetClassifier(Dataset):
    def __init__(self, label:DataFrame, image_size, stage, means=0, stds=0, offset=None, transform_config=None):
        self.img_num = 3#每次取出的图片张数
        # 记录不同id的滑动窗口偏移量，为Series类型
        if offset == None:
            indexs = pd.read_excel('../../dataRLPS/class3_image.xlsx', usecols=[0, 2], index_col=0).index
            self.offset = pd.Series(data=np.zeros(435, dtype=int), index=indexs)
        else:
            self.offset = offset
        # index = [x for x in label.index if x in index]
        self.label = label
        self.stage = stage
        # self.image_path = '../../dataRLPS/label'
        self.image_path = '../../data/img_num=5/label'
        if transform_config is None:
            transform_config = {
                'rot': (-25, 25),
                'col': (0.05, 0),  # (亮度，对比度)，对比度设为0
            }

        if stage == 'train':
            self.means, self.stds = self.image_mean_std(label.index)
            print('DatasetClassifier  | means:', self.means, ' | stds :', self.stds)
        else:
            self.means, self.stds = means, stds
            if self.means * self.stds == 0:
                print('请输入训练集的 means 与 stds ')
        self.transform = {
            'train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.RandomVerticalFlip(p=0.5),
                    transforms.RandomRotation(degrees=transform_config['rot']),
                    transforms.ColorJitter(brightness=transform_config['col'][0], contrast=transform_config['col'][1]),
                    transforms.Normalize(self.means, self.stds)
                ]),
            'not_train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.Normalize(self.means, self.stds)
                ]),
        }

    def __len__(self):
        return len(self.label.index)

    def getImgNums(self, idx):
        id = self.label.index[idx]
        label = self.label.loc[id]
        path = os.path.join(self.image_path + str(label), str(id))
        names = os.listdir(path)
        return len(names)

    def __getitem__(self, idx):
        # print('DatasetClassifier: ', idx)
        id = self.label.index[idx]
        label = self.label.loc[id].values[0]
        path = os.path.join(self.image_path + str(label), str(id))
        images = torch.zeros((1, 384, 384))
        names = os.listdir(path)
        # print(id, label)
        for i in range(self.img_num):
            # image_name = names[i + self.offset]#返回相邻的n个图片，根据偏移量不同而变动
            image_name = str(i + self.offset[id]) + ".png"#names顺序可能不同，所以按照数字序列顺序来取图片
            # print(str(i + self.offset[id]) + ".png")
            imgpath = os.path.join(path, image_name)
            image = cv2.imread(imgpath, flags=cv2.IMREAD_GRAYSCALE)
            image = self.transform[self.stage](image)
            images = torch.cat((images, image), 0)
        images = images[1:, :, :]
        label = torch.tensor(int(label))
        return images, label

    def image_mean_std(self, id, dim: int = 1):
        '''
        :param id: 划分好的训练集病人id, list
        :param dim: 图像通道数
        :return:
        '''
        image_path = self.image_path
        mean = torch.zeros(dim)
        std = torch.zeros(dim)
        sum = 0
        for label in ['0', '1', '2']:
            ids = os.listdir(image_path+label)
            for idx in ids:
                if not (idx in id or int(idx) in id):
                    continue
                path = os.path.join(image_path+label, idx)
                for img in os.listdir(path):
                    image_name = os.path.join(path, img)
                    X = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
                    sum += 1
                    mean += X[:, :].mean()
                    std += X[:, :].std()
        mean.div_(sum * 255)
        std.div_(sum * 255)

        print('image sums: ', sum)
        return mean, std


if __name__ == '__main__':
    # data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_multimodal_limitextreme_onehot.xlsx',
    #                      index_col=0,
    #                      header=0,
    #                      sheet_name='Sheet1')  # 直接读取预处理后的数据
    # features = data.iloc[:, 7:]
    # labels = data.iloc[:, 1]
    print(pd.Series(data=np.zeros(435)))
    labels = pd.read_excel('../../dataRLPS/class3_image.xlsx', usecols=[0, 2], index_col=0)
    train_dataset = DatasetClassifier(labels, 0.5, 0.5, image_size=(384, 384), stage='train')
    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=16,
                                              shuffle=True)
    epochs = 10

    # train_dataset.offset = 0
    train_dataset.offset += 1
    for j in range(3):
        for epoch in range(10):
            for i, data in enumerate(trainloader, 0):
                imgs, label = data
                print('epoch: ', epoch, '| Img: ', j, ' | batch: ', i, ' label: ', label, ' Img Size: ', np.shape(imgs))

            # for i, data in enumerate(valloader, 0):
            #     imgs, label = data
            #     print('epoch: ', epoch, '| Img: ', j, ' | batch: ', i, ' label: ', label, ' Img Size: ', np.shape(imgs))

        train_dataset.offset += 1




import torch
import torch.nn as nn
from osteoV2.model.image.resnet18 import ResNet18_class
from osteoV2.model.clinical.mlp_V2 import Net_singlemodel_clinical
from osteoV2.model.model_fusion.fusion_dataset_V2 import *

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

def get_loader(transform_config: dict, features: DataFrame, labels: DataFrame, seed: int):
    BATCH_SIZE = 32
    image_size = (384, 384)
    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels, random_state=seed)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train, random_state=seed)
    max = x_train.max()
    min = x_train.min()
    '''归一化'''
    x_train = (x_train - min) / (max - min)
    x_val = (x_val - min) / (max - min)
    x_test = (x_test - min) / (max - min)
    '''loader'''
    means, stds = image_mean_std(y_train.index, flag='segment', dim=1)
    dataset = Dataset_multimodal_segment_png
    # print(x_train.shape)
    train_dataset = dataset(x_train, y_train, means, stds, image_size, stage='not_train',
                            transform_config=transform_config)
    # print(train_dataset[0])
    val_dataset = dataset(x_val, y_val, means, stds, image_size, stage='not_train',
                          transform_config=transform_config)
    test_dataset = dataset(x_test, y_test, means, stds, image_size, stage='not_train',
                           transform_config=transform_config)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True, num_workers=5,
                                              pin_memory=True)
    valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=BATCH_SIZE,
                                            shuffle=False,  num_workers=5,
                                              pin_memory=True)
    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=False,  num_workers=5,
                                              pin_memory=True)
    # print('get loader')
    return trainloader, valloader, testloader

os.environ["CUDA_VISIBLE_DEVICES"] = '1'
device = torch.device('cuda')
transform_config = None
# seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546]
seeds = [1,2,3,4,5]
transform_config = {
        'rot': (-25, 25),#旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }
data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_multimodal_limitextreme_onehot.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
features_all = data.iloc[:, 7:]
labels_all = data.iloc[:, 1]
layer = {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}
path2 = "/home/user/suteng/osteo/osteoV2/model_save/clinical/" \
        "step40bt128/seed2000{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}val0.574test0.570.pth"
teacher = Net_singlemodel_clinical(layer=layer)
teacher.load_state_dict(torch.load(path2))
teacher.to(device)
for i, seed in zip(range(len(seeds)), seeds):
    setup_seed(seed)
    trainloader, valloader, testloader = get_loader(transform_config, features_all, labels_all, seed)
    correct = 0
    total = 0
    label = {'real': [], 'predict': []}
    with torch.no_grad():
        for i, data in enumerate(trainloader, 0):
            _, features, labels = data
            features, labels = features.to(device), labels.to(device)
            outputs = teacher(features)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += ((predicted == labels).sum().item())
        print('seed=', seed, 'The Train Accuracy:', correct / total)
        for i, data in enumerate(valloader, 0):
            _, features, labels = data
            features, labels = features.to(device), labels.to(device)
            outputs = teacher(features)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += ((predicted == labels).sum().item())
        print('seed=', seed, 'The Val Accuracy:', correct / total)
        for i, data in enumerate(testloader, 0):
            _, features, labels = data
            features, labels = features.to(device), labels.to(device)
            outputs = teacher(features)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += ((predicted == labels).sum().item())
        print('seed=', seed, 'The Test Accuracy:', correct / total)



import pandas as pd
import torch
import torch.nn as nn
from osteoV2.model.image.resnet18 import ResNet18_class
from osteoV2.model.clinical.mlp_V2 import Net_singlemodel_clinical
from osteoV2.model.model_fusion.fusion_dataset_V2 import *


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

def get_loader(transform_config: dict, features: DataFrame, labels: DataFrame, seed: int):
    BATCH_SIZE = 32
    image_size = (384, 384)
    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels, random_state=seed)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train, random_state=seed)
    max = x_train.max()
    min = x_train.min()
    '''归一化'''
    x_train = (x_train - min) / (max - min)
    x_val = (x_val - min) / (max - min)
    x_test = (x_test - min) / (max - min)
    '''loader'''
    means, stds = image_mean_std(y_train.index, flag='segment', dim=1)
    dataset = Dataset_multimodal_segment_png
    # print(x_train.shape)
    train_dataset = dataset(x_train, y_train, means, stds, image_size, stage='not_train',
                            transform_config=transform_config)
    # print(train_dataset[0])
    val_dataset = dataset(x_val, y_val, means, stds, image_size, stage='not_train',
                          transform_config=transform_config)
    test_dataset = dataset(x_test, y_test, means, stds, image_size, stage='not_train',
                           transform_config=transform_config)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True, num_workers=5,
                                              pin_memory=True)
    valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=BATCH_SIZE,
                                            shuffle=False,  num_workers=5,
                                              pin_memory=True)
    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=False,  num_workers=5,
                                              pin_memory=True)
    # print('get loader')
    return trainloader, valloader, testloader

def writeExcel(i, data, label, img, cli):
    batchsize = label.size()[0]
    row = i * batchsize
    for r, j in zip(range(batchsize), range(row, row + batchsize)):
        data.loc[j]['label'] = label[r].item()
        data.loc[j]['img1'] = img[r, 0].item()
        data.loc[j]['img2'] = img[r, 1].item()
        data.loc[j]['img3'] = img[r, 2].item()
        data.loc[j]['cli1'] = cli[r, 0].item()
        data.loc[j]['cli2'] = cli[r, 1].item()
        data.loc[j]['cli3'] = cli[r, 2].item()
    return data

def getOutputs(stage, dataloader):
    '''

    :param stage: String  select values: 'train', 'val', 'test'
    :return:
    '''
    correct_img = 0
    total_img = 0
    correct_cli = 0
    total_cli = 0
    correct = 0
    total = 0
    if(stage == 'train'):
        length = 224
    elif(stage == 'val'):
        length = 56
    elif (stage == 'test'):
        length = 64
    else:
        length = 371
    dataframe = pd.DataFrame(index=range(length), columns=['label', 'img1', 'img2', 'img3', 'cli1', 'cli2', 'cli3'])
    for i, data in enumerate(dataloader, 0):
        inputs_image, features, labels = data
        inputs_image, features, labels = inputs_image.to(device), features.to(device), labels.to(device)
        outputs_img = teacher1(inputs_image)
        _, predicted = torch.max(outputs_img.data, 1)
        total_img += labels.size(0)
        correct_img += ((predicted == labels).sum().item())

        outputs_cli = teacher2(features)
        _, predicted = torch.max(outputs_cli.data, 1)
        total_cli += labels.size(0)
        correct_cli += ((predicted == labels).sum().item())

        outputs = stacking(torch.cat((outputs_img, outputs_cli), 1))
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += ((predicted == labels).sum().item())

        dataframe = writeExcel(i, dataframe, labels, outputs_img, outputs_cli)
    # dataframe.to_excel('data/qilu/seed=' + str(seed) + stage + '.xlsx')
    print('seed=', seed, '\tThe ' + stage + ' Accuracy \tImage:%.4f' % (correct_img / total_img),
          ' \tClinical:%.4f' % (correct_cli / total_cli), ' \tStacking:%.4f' % (correct / total))
    return correct_img / total_img, correct_cli / total_cli, correct / total

class StackingV2(nn.Module):
    def __init__(self):
        super(StackingV2, self).__init__()
        self.stacking = nn.Linear(6, 3)

    def forward(self, x):
        return self.stacking(x)

os.environ["CUDA_VISIBLE_DEVICES"] = '1'
device = torch.device('cuda')
transform_config = None
seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546]
# seeds = [1,2,3,4,5]
transform_config = {
        'rot': (-25, 25),#旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }
data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_multimodal_limitextreme_onehot.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
features_all = data.iloc[:, 7:]
labels_all = data.iloc[:, 1]
path1 = '/home/user/PycharmProjects/osteo/osteoV2/model_save/class3/image/[16, 32, 64, 128]val0.942test0.931.pth'
teacher1 = ResNet18_class(image_size=(384, 384), channels=[16, 32, 64, 128], n_classes=3)
teacher1.load_state_dict(torch.load(path1))
teacher1.to(device)

# layer = {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}
# path2 = "/home/user/suteng/osteo/osteoV2/model_save/clinical/" \
#         "step40bt128/seed2000{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}val0.574test0.570.pth"

layer = {'b1': [8, 8, 8], 'b2': [8, 8, 8], 'b3': [16]}
path2 = "/home/user/PycharmProjects/osteo/osteoV2/model_save/clinical/Qilu/" \
        "step40bt32/seed1000{'b1': [8, 8, 8], 'b2': [8, 8, 8], 'b3': [16]}val0.551test0.547.pth"
teacher2 = Net_singlemodel_clinical(layer=layer)
teacher2.load_state_dict(torch.load(path2))
teacher2.to(device)

path3 = "/home/user/PycharmProjects/osteo/osteoV2/model_save/distill/stacking/qilu" \
        "/seed=3045val0.928test0.937stacking.pth"
stacking = StackingV2()
stacking.load_state_dict(torch.load(path3))
stacking.to(device)

acc = {
    'train': {'img': 0.0, 'cli': 0.0, 'sta': 0.0},
    'val': {'img': 0.0, 'cli': 0.0, 'sta': 0.0},
    'test': {'img': 0.0, 'cli': 0.0, 'sta': 0.0},
}

for i, seed in zip(range(len(seeds)), seeds):

    setup_seed(seed)
    trainloader, valloader, testloader = get_loader(transform_config, features_all, labels_all, seed)

    with torch.no_grad():
        img_train, cli_train, sta_train = getOutputs('train', trainloader)
        img_val, cli_val, sta_val = getOutputs('val', valloader)
        img_test, cli_test, sta_test = getOutputs('test', testloader)
    acc['train']['img'] += img_train
    acc['train']['cli'] += cli_train
    acc['train']['sta'] += sta_train
    acc['val']['img'] += img_val
    acc['val']['cli'] += cli_val
    acc['val']['sta'] += sta_val
    acc['test']['img'] += img_test
    acc['test']['cli'] += cli_test
    acc['test']['sta'] += sta_test
for stage in ['train', 'val', 'test']:
    print('Average\tThe ' + stage + ' Accuracy \tImage:%.4f' % (acc[stage]['img']/10),
              ' \tClinical:%.4f' % (acc[stage]['cli']/10), ' \tStacking:%.4f' % (acc[stage]['sta']/10))

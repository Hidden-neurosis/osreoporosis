import torch
import torch.nn as nn
import torch.nn.functional as F
from osteoV2.model.image.resnet18 import ResNet18_class
from osteoV2.model.clinical.mlp_V2 import Net_singlemodel_clinical


class TeacherLabel:
    def __init__(self, model, device):
        self.model = model
        self.model.to(device)

    def label(self, x):
        self.model.eval()
        predict = self.model(x)
        return predict


class StackingTeacher(nn.Module):
    def __init__(self, device):
        super(StackingTeacher, self).__init__()
        teacher1, teacher2, stacking = self.getTeacher()
        self.teacher1 = TeacherLabel(teacher1, device)
        self.teacher2 = TeacherLabel(teacher2, device)
        # self.stacking = nn.Sequential(nn.Linear(6, 8), nn.ReLU(), nn.Linear(8, 3))
        self.stacking = TeacherLabel(stacking, device)
    def getTeacher(self):
        path1 = '/home/user/PycharmProjects/osteo/osteoV2/model_save/class3/image/[16, 32, 64, 128]val0.942test0.931.pth'
        teacher1 = ResNet18_class(image_size=(384, 384), channels=[16, 32, 64, 128], n_classes=3)
        teacher1.load_state_dict(torch.load(path1))

        layer = {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}
        path2 = "/home/user/suteng/osteo/osteoV2/model_save/clinical/" \
                "step40bt128/seed2000{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}val0.574test0.570.pth"
        teacher2 = Net_singlemodel_clinical(layer=layer)
        teacher2.load_state_dict(torch.load(path2))

        stacking = StackingV2()
        path3 = "/home/user/PycharmProjects/osteo/osteoV2/model_save/" \
                "distill/stacking/qilu/test91.4/seed=2000val0.946test0.968stacking.pth"
        stacking.load_state_dict(torch.load(path3))
        return teacher1, teacher2, stacking

    def forward(self, x1, x2):
        x1 = self.teacher1.label(x1)
        x2 = self.teacher2.label(x2)
        x1 = torch.detach(x1)
        x2 = torch.detach(x2)
        out = self.stacking.label(torch.cat((x1, x2), 1))
        # print(out.size())
        return x1, x2, out

class StackingV2(nn.Module):
    def __init__(self):
        super(StackingV2, self).__init__()
        self.stacking = nn.Sequential(
            nn.BatchNorm1d(6),
            nn.Linear(6, 3),
        )
    def forward(self, x):
        return self.stacking(x)

class Loss_Distill_Stacking(nn.Module):
    def __init__(self, alpha, T, device):
        super(Loss_Distill_Stacking, self).__init__()
        self.alpha = alpha
        self.T = T
        self.criterion1 = nn.CrossEntropyLoss()
        self.criterion2 = nn.KLDivLoss(reduction='batchmean')
        self.device = device
        self.p = 0
        self.q1 = 0
        self.teacher = StackingTeacher(device)
        # self.teacher = TeacherLabel(teacher, self.device)

    def forward(self, outputs, labels):
        self.p = F.log_softmax(outputs / self.T, dim=1)
        # print('self.p.size()', self.p.size())
        loss1 = self.criterion1(outputs, labels)
        loss2 = self.criterion2(self.p, self.q1) * self.alpha
        loss = loss1 + loss2
        return loss

    def get_teacher_label(self, x1, x2):
        soft_label = self.teacher(x1, x2)[2]
        # print('soft_label.size()', soft_label.size())
        q1 = F.softmax(soft_label / self.T, dim=1)
        q1 = q1.detach()
        self.q1 = q1


if __name__ == '__main__':
    model = StackingTeacher(device="cpu")
    x1 = torch.randn(3, 1, 384, 384)
    x2 = torch.randn(3, 40)
    out = model(x1, x2)
    print(out[2].size())


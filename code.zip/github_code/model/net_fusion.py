import torch
import torch.nn as nn
import torch.nn.functional as F
from clinical.mlp import Net_multimodel_clinical
from image.cnn import Net_multimodel_CNN

'''以图像特征与结构化数据特征拼接后的特征为输入的全连接层分类器部分， 输出为分类结果'''
class Net_fusion_classifier(nn.Module):
    def __init__(self, input_size=51, output_size=3, layer_size=[32, 16, 8, 4]):
        super(Net_fusion_classifier, self).__init__()
        self.n_classes = output_size
        self.len_layer = len(layer_size)
        self.activate_function = nn.ReLU()
        self.sequence = nn.Sequential()

        for i in range(len(layer_size)):
            if i == 0:
                self.sequence.append(nn.Linear(input_size, layer_size[0]))
            else:
                self.sequence.append(nn.Linear(layer_size[i - 1], layer_size[i]))
            self.sequence.append(nn.BatchNorm1d(layer_size[i]))
            self.sequence.append(self.activate_function)
        self.sequence.append(nn.Linear(layer_size[-1], self.n_classes))
    def forward(self, x):
        out = self.sequence(x)
        return out

'''整个模型的框架整合'''
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.image_marginal_representation = Net_multimodel_CNN()
        outsize_image = self.image_marginal_representation.get_output_size()[1]#获取CNN提取图像之后的特征尺寸，用于确定最后分类网络的输入
        self.clinical_marginal_representation = Net_multimodel_clinical()
        outsize_clinical = self.clinical_marginal_representation.get_output_size()[1]#获取特征提取之后的特征尺寸，用于确定最后分类网络的输入
        self.fusion_classifier = Net_fusion_classifier(input_size=outsize_clinical + outsize_image)
    def forward(self, data_image, data_clinical):
        image_marginal_representation = self.image_marginal_representation(data_image)
        clinical_marginal_representation = self.clinical_marginal_representation(data_clinical)
        image_marginal_representation = image_marginal_representation.view(len(image_marginal_representation), -1)
        clinical_marginal_representation = clinical_marginal_representation.view(len(clinical_marginal_representation), -1)
        marginal_representation = torch.concat((image_marginal_representation, clinical_marginal_representation), 1)
        out = self.fusion_classifier(marginal_representation)
        return out

if __name__ == '__main__':
    a = torch.randn(4, 3, 388, 388)
    b = torch.randn(4, 51)
    model = Net()
    outputs = model(a, b)
    print(outputs)
    print(outputs.size())
    print(list(model.children()))


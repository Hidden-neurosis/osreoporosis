import torch
import torch.nn as nn
import torch.nn.functional as F
from osteoV2.model.image.resnet18 import ResNet, ResidualBlock
from osteoV2.model.clinical.mlp_V2 import Net_singlemodel_clinical
from osteoV2.model.model_fusion.net_fusion import Net_V2
class ResnetDistillFeature(ResNet):
    def __init__(self, image_size, channels, n_classes=3):
        super(ResnetDistillFeature, self).__init__(ResidualBlock, image_size=image_size, channels=channels,  num_classes=n_classes)
    def forward(self, x):
        out = self.conv1(x)
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = F.avg_pool2d(out, 4)
        fea = out.view(out.size(0), -1)
        out_1 = self.fc(fea)
        return fea

class ClinicalDistillFeature(Net_singlemodel_clinical):
    def __init__(self, layer):
        super(ClinicalDistillFeature, self).__init__(layer)
    def forward(self, x):
        x1 = x[:, 0:11]
        x2 = x[:, 11:]
        x1 = self.block1(x1)
        x2 = self.block2(x2)
        x3 = torch.cat((x1, x2), 1)
        fea = self.block3(x3)
        out = self.classifier(fea)
        # x3 = torch.nn.functional.softmax(self.classifier(x3))
        return fea

class MultimodalDistillFeature(Net_V2):
    def __init__(self, config, n_classes):
        super(MultimodalDistillFeature, self).__init__(config, n_classes)

def resnetDistillFeature():
    return ResnetDistillFeature(ResidualBlock, (384, 384), [16, 32, 64, 128], 3)

def clinicalDistillFeature():
    return ClinicalDistillFeature({'b1': [3, 5], 'b2': [16, 3], 'b3': [8, 8, 5]})


if __name__ == '__main__':
    a = torch.randn(3, 1, 384, 384)
    b = torch.randn(3, 40)
    img = resnetDistillFeature()
    cli = clinicalDistillFeature()
    print(img(a)[0].size(), img(a)[1].size())
    print(cli(b)[0].size(), cli(b)[1].size())
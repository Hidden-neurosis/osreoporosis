import os
import torch
import torch.nn.functional as F
import torch.nn as nn
from osteoV2.model.image.resnet18 import ResNet18_class
from osteoV2.model.clinical.mlp_V2 import Net_singlemodel_clinical
from osteoV2.model.distill_feature.model import *
# use teacher to label the data
class TeacherLabel:
    def __init__(self, model, device):
        self.model = model
        self.model.to(device)
    def label(self, x):
        self.model.eval()
        predict = self.model(x)
        return predict

class Loss_Distill(nn.Module):
    def __init__(self, alpha, beta, T, device):
        super(Loss_Distill, self).__init__()
        self.alpha = alpha
        self.beta = beta
        self.T = T
        self.criterion1 = nn.CrossEntropyLoss()
        self.criterion2, self.criterion3 = self.getloss()
        self.device = device
        self.p = 0
        self.q1 = 0
        self.q2 = 0
        teacher1, teacher2 = self.loadmodel()
        self.teacher1 = TeacherLabel(teacher1, self.device)
        self.teacher2 = TeacherLabel(teacher2, self.device)

    def forward(self, outputs, labels):
        self.p = F.log_softmax(outputs / self.T, dim=1)
        loss1 = self.criterion1(outputs, labels)
        loss2 = self.criterion2(self.p, self.q1) * self.alpha
        loss3 = self.criterion3(self.p, self.q2) * self.beta
        # loss2 = self.criterion2(self.p, self.q1) * (self.T * self.T * self.alpha)
        # loss3 = self.criterion3(self.p, self.q2) * (self.T * self.T * self.beta)
        print("loss1:", loss1, "loss2 alpha:", loss2, "loss3 beta", loss3)
        loss = loss1 + loss2 + loss3
        return loss

    def get_teacher_label(self, x1, x2):
        soft_label1 = self.teacher1.label(x1)
        q1 = F.softmax(soft_label1 / self.T, dim=1)
        soft_label2 = self.teacher2.label(x2)
        q2 = F.softmax(soft_label2 / self.T, dim=1)
        q1 = q1.detach()
        q2 = q2.detach()
        self.q1 = q1
        self.q2 = q2

    def loadmodel(self):
        print('未重写')
        # self.teacher1 = TeacherLabel(teacher1, self.device)
        # self.teacher2 = TeacherLabel(teacher2, self.device)
        return 1, 1
    def getloss(self):
        criterion2 = nn.KLDivLoss(reduction='batchmean')
        criterion3 = nn.KLDivLoss(reduction='batchmean')
        return criterion2, criterion3

class Loss_Distill_Target(Loss_Distill):
    def __init__(self, alpha, beta, T, device):
        super(Loss_Distill_Target, self).__init__(alpha, beta, T, device)

    def loadmodel(self):
        # path1 = '/home/user/PycharmProjects/osteo/osteoV2/model_save/class3/image/[16, 32, 64, 128]val0.942test0.931.pth'
        path1 = '/home/user/PycharmProjects/osteo/osteoV2/model_save/class3/image11.7/seed=6[16, 32, 64, 128]val0.928test0.908.pth'
        teacher1 = ResNet18_class(image_size=(384, 384), channels=[16, 32, 64, 128], n_classes=3)
        teacher1.load_state_dict(torch.load(path1))

        layer = {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}
        path2 = "/home/user/suteng/osteo/osteoV2/model_save/clinical/" \
                "step40bt128/seed2000{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}val0.574test0.570.pth"
        teacher2 = Net_singlemodel_clinical(layer=layer)
        teacher2.load_state_dict(torch.load(path2))
        return teacher1, teacher2

class Loss_Distill_Target_T2(Loss_Distill_Target):
    def __init__(self, alpha, beta, T, device):
        super(Loss_Distill_Target_T2, self).__init__(alpha, beta, T, device)

    def forward(self, outputs, labels):
        self.p = F.log_softmax(outputs / self.T, dim=1)
        loss1 = self.criterion1(outputs, labels)
        loss2 = self.criterion2(self.p, self.q1) * (self.T * self.T * self.alpha)
        loss3 = self.criterion3(self.p, self.q2) * (self.T * self.T * self.beta)
        loss = loss1 + loss2 + loss3
        return loss

class Loss_Distill_Feature(nn.Module):
    def __init__(self, alpha, beta, T, device):
        super(Loss_Distill_Feature, self).__init__()
        self.alpha = alpha
        self.beta = beta
        self.T = T
        self.criterion1 = nn.CrossEntropyLoss()
        self.criterion2, self.criterion3 = self.getloss()
        self.device = device
        #以下四个属性都为特征
        self.t_img = 0
        self.t_cli = 0
        self.s_img = 0
        self.s_cli = 0
        teacher1, teacher2 = self.loadmodel()
        self.teacher1 = TeacherLabel(teacher1, self.device)
        self.teacher2 = TeacherLabel(teacher2, self.device)

    def getloss(self):
        criterion2 = nn.MSELoss()
        criterion3 = nn.MSELoss()
        return criterion2, criterion3

    def forward(self, outputs, labels):
        loss1 = self.criterion1(outputs, labels)
        loss2 = self.criterion2(self.s_img, self.t_img) * self.alpha
        loss3 = self.criterion3(self.s_cli, self.t_cli) * self.beta
        loss = loss1 + loss2 + loss3
        return loss

    def get_teacher_label(self, in_img, in_cli, fea_img, fea_cli):
        t_img = self.teacher1.label(in_img)
        t_cli = self.teacher2.label(in_cli)
        t_img = t_img.detach()
        t_cli = t_cli.detach()
        self.t_img = t_img
        self.t_cli = t_cli
        self.s_img = fea_img
        self.s_cli = fea_cli

    def loadmodel(self):
        path1 = '/home/user/PycharmProjects/osteo/osteoV2/model_save/class3/image/[16, 32, 64, 128]val0.942test0.931.pth'
        teacher1 = ResnetDistillFeature(image_size=(384, 384), channels=[16, 32, 64, 128], n_classes=3)
        teacher1.load_state_dict(torch.load(path1))

        layer = {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}
        path2 = "/home/user/suteng/osteo/osteoV2/model_save/clinical/" \
                "step40bt128/seed2000{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}val0.574test0.570.pth"
        teacher2 = ClinicalDistillFeature(layer=layer)
        teacher2.load_state_dict(torch.load(path2))
        return teacher1, teacher2

if __name__ == '__main__':
    os.environ[
        "CUDA_VISIBLE_DEVICES"] = '0'
    device = "cpu"
    # if torch.cuda.is_available():
    #     device = torch.device('cuda')
    # print('device:', device)
    x1 = torch.randn(3, 1, 384, 384)
    x2 = torch.randn(3, 40)
    outputs = torch.tensor([[0.9, 0.05, 0.05], [0.7, 0.2, 0.1], [0.8, 0.1, 0.1]])
    labels = torch.tensor([[1.0, 0, 0], [1.0, 0, 0], [1.0, 0, 0]])
    criterion = Loss_Distill_Feature(alpha=0.5, beta=0.5, T=1, device=device)
    # criterion.get_teacher_label(x1, x2)
    # print(criterion(outputs, labels))
    # print(criterion.q1, criterion.q2)
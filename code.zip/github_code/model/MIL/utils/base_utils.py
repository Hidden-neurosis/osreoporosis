import torch

def load_paraments_partial(model, path):
    model_pretrained = torch.load(path)
    flag = 1
    for i, key1, key2 in zip(range(20), model.state_dict().keys(), model_pretrained.keys()):
        if model.state_dict()[key1].size() == model_pretrained[key2].size():
            # print(key1, key2)
            model.state_dict()[key1].copy_(model_pretrained[key2])
        else:
            print('维度不匹配')
            flag = 0
            break
    if flag:
        print('模型已经预加载')
    else:
        print('模型预加载失败')
    return model

if __name__ == '__main__':
    path = '/home/user/PycharmProjects/osteo/pretrained/model_save/convnext/[40, 80, 160, 320].pth'


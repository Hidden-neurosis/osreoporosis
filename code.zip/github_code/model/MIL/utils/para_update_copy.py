import matplotlib.pyplot as plt
import os
from pandas import DataFrame
import numpy as np
from sklearn.metrics import roc_auc_score
import torch.nn as nn

def weights_init(m):                                               # 1
    classname = m.__class__.__name__                               # 2
    if classname.find('Conv') != -1:                               # 3
        nn.init.normal_(m.weight.data, 0.0, 0.02)                  # 4
    elif classname.find('BatchNorm') != -1:                        # 5
        nn.init.normal_(m.weight.data, 1.0, 0.02)                  # 6
        nn.init.constant_(m.bias.data, 0)                          # 7

# netG.apply(weights_init)                                           # 8

class ParaUpdate():
    def __init__(self):
        self.running_loss = 0.0  # 保存每个mini_batches的loss之和，用于打印，打印后清空
        self.train_total = 0  # 保存每个epoch的总的个数
        self.train_correct = 0  # 保存每个epoch的正确的个数
        self.train_loss = 0.0
        self.train_i = 0#训练过程batchsize循环计数
        self.train_acc = 0

        # Validation loss
        self.val_loss = 0.0
        self.val_steps = 0
        self.val_total = 0
        self.val_correct = 0
        self.val_i = 0
        self.val_acc = 0

        self.label ={
        'train': {'real': [], 'predict': []},
        'val': {'real': [], 'predict': []},
        'test': {'real': [], 'predict': []}
    }
        self.result = {  # 用于存放最后的各种指标结果
        'train': {'acc': 0.0, 'auc': 0.0},
        'val': {'acc': 0.0},
        'test': {'acc': 0.0, 'auc': 0.0},
    }
        self.plot = {
        'train': {'loss': [], 'acc': []},
        'val': {'loss': [], 'acc': []}
    }

    def getLabel(self):
        return self.label

    def getLabel_p1(self, stage):
        return self.label[stage]['real'], self.label[stage]['predict']

    def getLabel_p2(self, stage, metric):
        return self.label[stage][metric]

    def getResult(self):
        return self.result

    def getResult_p2(self, stage, metric):
        return self.result[stage][metric]

    def getPlot(self):
        return self.plot

    def getPlot_p1(self, metric):
        if metric == 'loss' or metric == 'acc':
            return self.plot['train'][metric], self.plot['val'][metric]
        else:
            print("指标输入错误")

    def getPlot_p2(self, stage, metric):
        if (stage == 'train' or stage == 'val') and (metric == 'loss' or metric == 'acc'):
            return self.plot[stage][metric]
        else:
            print("参数输入错误")

    def addLabel(self, stage, real, predict):
        if stage == 'train' or stage == 'val' or stage == 'test':
            self.label[stage]['real'].extend(real)
            self.label[stage]['predict'].extend(predict)
        else:
            print('阶段输入错误')

    def setResult_p1(self, metric, metric_t, metric_v):
        if metric == 'acc' or metric == 'auc':
            self.result['train'][metric] = metric_t
            self.result['val'][metric] = metric_v
        else:
            print('setResult_p1 输入错误')


    def setResult_p2(self, stage, acc, auc=None):
        if stage == 'train' or stage == 'val' or stage == 'test':
            self.result[stage]['acc'] = acc
            self.result[stage]['auc'] = auc
        else:
            print('setResult_p2 阶段输入错误')

    def setResult_p3(self, stage, metirc, metric_value):
        if stage == 'train' or stage == 'val' or stage == 'test':
            self.result[stage][metirc] = metric_value
        else:
            print('setResult_p3 阶段输入错误')

    def addPlot(self, stage, loss, acc):
        if stage == 'train' or stage == 'val':
            self.plot[stage]['loss'].append(loss)
            self.plot[stage]['acc'].append(acc)

    def plot_savefig(self, path_plot, seed, epoch_num):
        if not os.path.exists(path_plot):
            os.makedirs(path_plot)
        x = range(epoch_num)
        plt.plot(x, self.plot['train']['loss'], label='train')
        plt.plot(x, self.plot['val']['loss'], label='val')
        plt.legend()
        plt.savefig(os.path.join(path_plot, str(seed) + 'loss.png'))
        plt.close()
        plt.plot(x, self.plot['train']['acc'], label='train')
        plt.plot(x, self.plot['val']['acc'], label='val')
        plt.legend()
        plt.savefig(os.path.join(path_plot, str(seed) + 'acc.png'))
        plt.close()

    def metric_compute(self, result: DataFrame,
                    seed: int, i: int, n_class: int = 2):
        '''
        计算AUC指标并写入dataframe
        :param result: 最后的指标结果总表
        :param seed:
        :param i: 第几行，从seed的for循环中获取
        :param n_class: 几分类
        :return:
        '''
        if n_class == 2:
            multi_class = 'raise'
        elif n_class >= 3:
            multi_class = 'ovo'  # 'ovo'
        label_train_predict = np.array(self.label['train']['predict'])
        label_test_predict = np.array(self.label['test']['predict'])
        label_train_real = np.array(self.label['train']['real'])
        label_test_real = np.array(self.label['test']['real'])
        if multi_class == 'raise':
            print('二分类AUC')
            label_train_predict = label_train_predict[:, 1]
            label_test_predict = label_test_predict[:, 1]
        elif multi_class == 'ovo' or multi_class == 'ovr':
            print('多分类AUC')
        # print('label_train_predict:\n', label_train_predict.sum(axis=1))
        # try:
        self.result['train']['auc'] = roc_auc_score(label_train_real, label_train_predict,
                                                    multi_class=multi_class)
        self.result['test']['auc'] = roc_auc_score(label_test_real, label_test_predict, multi_class=multi_class)
        # except:
        #     self.result['train']['auc'] = 0
        #     self.result['test']['auc'] = 0
        # 'accuracy_train', 'accuracy_val', 'accuracy_test'
        result.loc[i]['seed'] = seed
        result.loc[i]['accuracy_train'] = self.result['train']['acc']
        result.loc[i]['accuracy_val'] = self.result['val']['acc']
        result.loc[i]['accuracy_test'] = self.result['test']['acc']
        result.loc[i]['auc_train'] = self.result['train']['auc']
        result.loc[i]['auc_test'] = self.result['test']['auc']
        return result

    def epoch_init(self):
        self.running_loss = 0.0  # 保存每个mini_batches的loss之和，用于打印，打印后清空
        self.train_total = 0  # 保存每个epoch的总的个数
        self.train_correct = 0  # 保存每个epoch的正确的个数
        self.train_loss = 0.0
        self.train_i = 0  # 训练过程batchsize循环计数

        # Validation loss
        self.val_loss = 0.0
        self.val_steps = 0
        self.val_total = 0
        self.val_correct = 0
        self.val_i = 0

    def epoch_update(self, stage, loss, labels, predicted):
        if stage == 'train':
            self.running_loss += loss
            self.train_loss += loss
            self.train_i += 1
            self.train_total += labels.size(0)
            self.train_correct += ((predicted == labels).sum().item())
        elif stage == 'val':
            self.val_loss += loss
            self.val_steps += 1
            self.val_i += 1
            self.running_loss += loss
            self.val_total += labels.size(0)
            self.val_correct += ((predicted == labels).sum().item())


    def update(self, savefig):
        self.train_loss = self.train_loss / self.train_i
        self.train_acc = self.train_correct / self.train_total
        self.val_loss = self.val_loss / self.val_i
        self.val_acc = self.val_correct / self.val_total
        if savefig:
            self.addPlot('train', self.train_loss, self.train_acc)
            self.addPlot('val', self.val_loss, self.val_acc)

    def acc_getbetter(self):
        self.result['train']['acc'] = self.train_acc
        self.result['val']['acc'] = self.val_acc






if __name__ == '__main__':
    a = ParaUpdate()
    a.addPlot('train', [1, 2], [2, 4])
    print(a.getPlot())
    print(a.getPlot_p1('loss'))
    print(a.getPlot_p2('train', 'loss'))

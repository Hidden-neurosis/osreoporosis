from ray import tune
import copy
import torch.optim as optim
import torch.backends.cudnn
from excel_name import get_excel_name
from utils.para_update import *
from MILmodel import Attention, AttentionPaper
import torch.nn.functional as F
import pandas as pd
from MILutils import setup_seed
from MILdataloader import get_loader
from torch.autograd import Variable

def get_labels_outputs(labels, outputs):
    labels = labels.cpu()
    outputs = F.softmax(outputs, dim=1)
    outputs = outputs.cpu()
    labels = labels.detach().numpy()
    outputs = outputs.detach().numpy()
    return labels, outputs

def train(config, model, device, para: ParaUpdate, model_save_dir, checkpoint_dir=None, data_dir=None):
    global trainloader, valloader
    epoch_num = config["epoch_num"]
    lr = config["lr"]
    step_size = config["step_size"]
    criterion = nn.CrossEntropyLoss()
    weight_p, bias_p = get_para_weight_bias(model)
    optimizer = optim.SGD(
            [
                {'params': weight_p, 'weight_decay': 1e-4},
                {'params': bias_p, 'weight_decay': 0}
            ], lr=lr, momentum=0.9
        )
    # optimizer = optim.Adam(model.parameters(), lr=lr)
    #step_size为几个epoch进行衰减，gamma为衰减系数
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)
    # scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=30, verbose=False,
    #                                            threshold=0.0001, threshold_mode='rel', cooldown=10, eps=1e-08)
    best_acc = 0.0#保存当前最好的准确率
    best_model = model
    best_model_wts = copy.deepcopy(model.state_dict())
    for epoch in range(epoch_num):  # loop over the dataset multiple times
        para.epoch_init()
        train_acc = 0.
        train_loss = 0.
        train_error = 0.
        for i, data in enumerate(trainloader, start=0):
            # get the inputs; data is a list of [inputs, labels]
            inputs_image, labels = data
            inputs_image, labels = inputs_image.to(device), labels.to(device)
            inputs_image, labels = Variable(inputs_image), Variable(labels)
            optimizer.zero_grad()

            # calculate loss and metrics
            loss = model.calculate_objective_batch(inputs_image, labels)
            # print(loss)
            train_loss += loss.item()
            error = model.calculate_classification_error_batch(inputs_image, labels)
            train_error += error
            # backward pass
            loss.backward()
            optimizer.step()
        train_loss /= len(trainloader)
        train_error /= len(trainloader)
        train_acc = 1 - train_error
        scheduler.step()

        '-----------------------------------------------------------------------------'
            # outputs = model(inputs_image)#[N, C, H, W]
            # loss = criterion(outputs, labels)

            # _, predicted = torch.max(outputs.data, 1)
            # loss.backward()
            # optimizer.step()
            #
            # para.epoch_update('train', loss.item(), labels, predicted)
            # labels, outputs = get_labels_outputs(labels, outputs)
            # para.addLabel('train', labels, outputs)
        '----------------------------------------------------------------------------'

        val_loss = 0.
        val_error = 0.
        val_acc = 0.
        for i, data in enumerate(valloader, 0):
            with torch.no_grad():
                inputs_image, labels = data
                inputs_image, labels = inputs_image.to(device), labels.to(
                    device)
                inputs_image, labels = Variable(inputs_image), Variable(labels)
                #loss
                loss = model.calculate_objective_batch(inputs_image, labels)
                val_loss += loss.item()
                error = model.calculate_classification_error_batch(inputs_image, labels)
                val_error += error
        val_loss /= len(valloader)
        val_error /= len(valloader)
        val_acc = 1-val_error
        # para.update(savefig=True)
        if flag_print:
            print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" %
                  (epoch + 1, epoch_num, train_loss, train_acc))
            print('Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' %
                  (epoch + 1, epoch_num, val_loss, val_acc))

        # 利用验证集找出最好模型
        if val_acc > best_acc:
            best_acc = val_acc
            best_model_wts = copy.deepcopy(model.state_dict())
            best_model = copy.deepcopy(model)
            para.acc_getbetter()

    model.load_state_dict(best_model_wts)

    # 只保存模型参数
    if flag_print:
        print('The Best Valdition |  accuracy: %.3f |' % best_acc)
    return model, para, train_acc, val_acc

def test(model, device, para, testloader):
    global trainloader, valloader, writer_train, writer_val
    correct = 0
    total = 0
    test_loss = 0.
    test_error = 0.
    label = {'real': [], 'predict': []}
    with torch.no_grad():
        for i, data in enumerate(testloader, 0):
            inputs_image, labels = data
            inputs_image, labels = inputs_image.to(device), labels.to(
                device)
            inputs_image, labels = Variable(inputs_image), Variable(labels)
            loss = model.calculate_objective_batch(inputs_image, labels)
            test_loss += loss.item()
            error = model.calculate_classification_error_batch(inputs_image, labels)
            test_error += error
            # print('test image total num:', total)
    test_error /= len(testloader)
    test_loss /= len(testloader)
    if flag_print:
        print('The Test Accuracy:', 1-test_error)
    return 1-test_error, label

def main(config):
    '''--------------------参数设置-------------------------'''
    global trainloader, valloader, seeds, config_i, path_plot
    # 输入为四节椎骨还是一节椎骨
    image_size = config['image_size']

    excel_name = get_excel_name(config, transform_config)

      # CUDA_VISIBLE_DEVICES限制一下使用的GPU。比如有0,1,2,3号GPU，CUDA_VISIBLE_DEVICES=2,3，则当前进程的可见GPU只有物理上的2、3号GPU，此时它们的编号也对应变成了0、1，即cuda:0对应2号GPU，cuda:1对应3号GPU

    '''---------------------------------------------------'''


    '''--------------------device-----------------------'''
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        # device = "cuda:0"
        device = torch.device('cuda')
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    print('device:', device)

    '''-----------------------------------------------------'''

    '''--------------------读取数据----------------------------'''
    data = pd.read_excel(r'../../data/EXCEL/class3/class3_image.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 0]
    labels = data.iloc[:, 1]
    print(features)
    print(labels)
    accuracy_test_average = 0  #
    result = pd.DataFrame(index=range(len(seeds)),
                          columns=['seed', 'accuracy_train', 'accuracy_val', 'accuracy_test'])

    if not os.path.exists(path_plot):
        os.makedirs(path_plot)
    config_i = len(os.listdir(path_plot)) + 1
    path_plot += str(config_i)
    for i, seed in enumerate(seeds):
        para = ParaUpdate()  # 存放参数的类
        setup_seed(seed)
        if flag_print:
            print('-----seed=%d-----' % seed)

        trainloader, valloader, testloader = get_loader(config, transform_config, features, labels, seed=seed)
        model = AttentionPaper(config, device, seed)
        if torch.cuda.device_count() > 1:
            model = nn.DataParallel(model)
        if flag_model_load:
            model = load_paraments_partial(model, model_load)
        model.to(device)
        model, para, train_acc, val_acc = train(config, model, device, para, model_save_dir=model_save)
        test_acc, label_test = test(model, device, para, testloader)
        if flag_model_save:
            torch.save(model.state_dict(), os.path.join(model_save, 'seed=' + str(seed) +
                                                             str(config["resnet18_channels"]) +
                                                             "val" + str(para.val_acc)[:5] +
                                                             "test" + str(test_acc)[:5] +
                                                            ".pth"))
        result.loc[i] = [seed,  train_acc, val_acc, test_acc]
        if flag_print:
            print('---------------' + ('-' * len(str(seed))))
    result.loc['mean'] = result.mean()
    print(result)

    path = path_excel
    if not os.path.exists(path):
        os.makedirs(path)
    result.to_excel(os.path.join(path, excel_name + '.xlsx'))
    if flag_print:
        print('The Test Average Accuracy:', accuracy_test_average / len(seeds))
    if flag_tune:
        tune.report(
            acc_train=result.loc['mean', 'accuracy_train'],
            acc_val=result.loc['mean', 'accuracy_val'],
            acc_test=result.loc['mean', 'accuracy_test'],
            auc_train=result.loc['mean', 'auc_train'],
            auc_test=result.loc['mean', 'auc_test'],
                    )
    return

if __name__ == '__main__':
    global trainloader, valloader, writer_train, writer_val, seeds, config_i
    config_i = 0
    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    os.environ["CUDA_VISIBLE_DEVICES"] = '1'

    #设定默认数据类型为float16，以减小显存的使用
    # torch.set_default_tensor_type(torch.cuda.HalfTensor)
    flag_tune = False
    flag_print = True
    flag_model_load = True
    flag_model_save = False

    model_load = r'./model_pretrained/[16, 32, 64, 128].pth'
    model_save = r'./model_save/'
    path_excel = r'./result/'
    path_plot = r'./plot/'
    seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546]
    # seeds = seeds[:2]
    # config = {
    #     "epoch_num": 150,
    #     "lr": 0.001,
    #     "batch_size": tune.grid_search([8, 16, 32]),
    #     "image_flag": 'segment',  # 'segment', 'crop'
    #     "image_size": (384, 384),
    #     "resnet18_channels":
    #     tune.grid_search([
    #         [16, 32, 64, 128]
    #     ])
    # }
    config = {
        "epoch_num": 280,
        "step_size": 70,
        "lr": 0.001,
        "batch_size": 16,
        "image_flag": 'segment',  # 'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": [16, 32, 64, 128],
    }

    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0.05),#(亮度，对比度)，对比度设为0
        'flip': 'h-v',
    }
    main(config)
    print(config)
    print("MILtrain_batch.py")
    # absolute_path = '/home/user/suteng/osteo'
    # result = tune.run(
    #     main,
    #     resources_per_trial={"cpu": 28, "gpu": 1},  # 运行时的资源限制
    #     config=config,
    #     local_dir=absolute_path + '/ray_results',  # 运行以及保存结果的位置
    #     # num_samples=3,  # random search时的采样次数
    # )

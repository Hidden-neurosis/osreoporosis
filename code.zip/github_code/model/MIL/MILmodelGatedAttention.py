import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from MILresnet import ResNet18

class GatedAttention(nn.Module):
    def __init__(self, config, device):
        super(GatedAttention, self).__init__()
        self.L = 1000
        self.D = 128
        self.K = 1
        self.device = device
        self.model = ResNet18(config, self.L)

        self.attention_V = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh()
        )

        self.attention_U = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Sigmoid()
        )

        self.attention_weights = nn.Linear(self.D, self.K)

        self.classifier = nn.Sequential(
            nn.Linear(self.L * self.K, 3),
            nn.Sigmoid()
        )

    def forward(self, x):
        #Y_A为attention的系数，所以此时为5维
        Y_prob, Y_hat, Y_A = torch.empty((0, 3)), torch.empty((0, 1)), torch.empty((0, 5))
        Y_prob, Y_A = Y_prob.to(self.device), Y_A.to(self.device)
        for i in range(len(x)):
            pro, hat, a = self.forwardOnePerson(x[i])
            Y_prob = torch.cat((Y_prob, pro), 0)
            # Y_hat = torch.cat((Y_hat, hat), 0)  出错原因hat维度为（1，），而Y_hat为（0，1）
            Y_A = torch.cat((Y_A, a), 0)
        return Y_prob

    def forwardOnePerson(self, x):
        x = x.squeeze(0)
        # x = x[0]
        # 将数据输入网络
        H = self.model(x)  # NxL

        # 经过分类器之前先经过注意力机制网络，得到对应的权重
        A_V = self.attention_V(H)  # NxD
        A_U = self.attention_U(H)  # NxD
        A = self.attention_weights(A_V * A_U)  # element wise multiplication # NxK
        A = torch.transpose(A, 1, 0)  # KxN，翻转维度
        A = F.softmax(A, dim=1)  # softmax over N

        # 权重乘以网络的输出,从N个实例的N个特征向量L，变成一个特征向量L
        M = torch.mm(A, H)  # KxL

        # 最后的特征经过分类器得到输出
        Y_prob = self.classifier(M)
        Y_hat = torch.argmax(Y_prob, dim=1)

        return Y_prob, Y_hat, A

if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    a = torch.randn(3, 5, 1, 384, 384)

    device = "cpu"
    if torch.cuda.is_available():
        device = torch.device('cuda')
    print('device:', device)

    a = a.to(device)
    config = {"resnet18_channels": [16, 32, 64, 128]}
    model = Attention(config, device)
    model = model.to(device)
    # print(model.forwardOnePerson(torch.randn(5, 1, 384, 384)))
    print(model(a))

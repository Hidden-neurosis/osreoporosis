import torch.nn
import torch.optim as optim
from osteoV2.model.MIL.MILdataset import *
from MILmodel import Attention
seed = 6
image_size = (384, 384)
BATCH_SIZE = 3

def get_loader(transform_config: dict, features: DataFrame, labels: DataFrame, seed: int):
    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels, random_state=seed)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train, random_state=seed)
    '''loader'''
    means, stds = image_mean_std(y_train.index, dim=1)
    dataset = Dataset_image_segment_png
    # print(x_train.shape)
    train_dataset = dataset(y_train, means, stds, image_size, stage='train',
                            transform_config=transform_config)
    # print(train_dataset[0])
    val_dataset = dataset(y_val, means, stds, image_size, stage='not_train',
                          transform_config=transform_config)
    test_dataset = dataset(y_test, means, stds, image_size, stage='not_train',
                           transform_config=transform_config)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True, num_workers=5,
                                              pin_memory=True)
    valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=BATCH_SIZE,
                                            shuffle=False, num_workers=5,
                                            pin_memory=True)
    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=False, num_workers=5,
                                             pin_memory=True)
    return trainloader, valloader, testloader

if __name__ == '__main__':
    data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_image.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 0]
    labels = data.iloc[:, 1]
    config = {"resnet18_channels": [16, 32, 64, 128]}
    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0.05),  # (亮度，对比度)，对比度设为0
        'flip': 'h-v',
    }
    device = "cpu"
    if torch.cuda.is_available():
        device = torch.device('cuda')
    print('device:', device)
    lr = 0.01
    trainloader, valloader, testloader = get_loader(transform_config, features, labels, seed=seed)
    model = Attention(config, device)
    model.to(device)
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 10, gamma=0.1, last_epoch=-1)
    for i, data in enumerate(trainloader, start=0):
        # get the inputs; data is a list of [inputs, labels]
        inputs_image, labels = data
        inputs_image, labels = inputs_image.to(device), labels.to(device)
        optimizer.zero_grad()

        outputs, A = model(inputs_image)  # [N, C, H, W]

        loss = criterion(outputs, labels)
        print('loss: ', loss)
        loss.backward()
        optimizer.step()

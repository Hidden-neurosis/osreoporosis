import time
import pandas as pd

def get_excel_name(config: dict, transform: dict):
    name = {
        "epoch_num": 'epo',
        "step_size": 'ste',
        "lr": 'lr',
        "batch_size": 'bat',
        "image_flag": 'imf',  #'segment', 'crop'
        "image_size": 'ims',
        "resnet18_channels": 'cha',
        "convnext_dims": 'cha',
        "convnext_dep": 'dep',
        'mlp': 'mlp',
        'classifier': 'cla',  # 分类器的网络结构
        'freeze': 'fre',  # 'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'dis',  # 'cli', 'not' 蒸馏标志位
        'transfer': 'tra',  # 'cli', 'not'迁移标志位
        'alpha': 'alf',
        'dis_alpha': 'd_a',
        'beta': 'b',
        'T': 'T',
    }
    end_time = time.localtime()
    end_time = time.strftime('%Y-%m-%d %H.%M.%S', end_time)

    excel_name = end_time + '{'
    for key in transform.keys():
        excel_name += (key + str(transform[key]) + ' ')
    excel_name = excel_name + '}'

    excel_name = excel_name + '{'
    for key in config.keys():
        excel_name += (name[key] + str(config[key]) + ' ')
    excel_name = excel_name + '}'

    excel_name = excel_name.replace(':', '')
    return excel_name

def simple_config_name(keys):
    config = {
        "epoch_num": 'epo',
        "step_size": 'ste',
        "lr": 'lr',
        "batch_size": 'bat',
        "image_flag": 'imf',  #'segment', 'crop'
        "image_size": 'ims',
        "resnet18_channels": 'res',
        'mlp': 'mlp',
        'classifier': 'cla',  # 分类器的网络结构
        'freeeze': 'fre',  # 'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'dis',  # 'cli', 'not' 蒸馏标志位
        'transfer': 'tra',  # 'cli', 'not'迁移标志位
    }
if __name__ == '__main__':
    config = {
        "epoch_num": 90,
        "step_size": 30,
        "lr": 0.001,
        "batch_size": 5,
        "image_flag": 'segment',  # 'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": [8, 8, 8, 8],
        'mlp': {'b1': [2, 2], 'b2': [2, 2], 'b3': [2, 2]},
        'classifier': [512],  # 分类器的网络结构
        'freeze': 'not',  # 'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'not',  # 'cli', 'not' 蒸馏标志位
        'transfer': 'not',  # 'cli', 'not'迁移标志位
        'dis_alpha': 0.1,#tune.grid_search([0.8, 0.5, 0.2]),
        'beta': 0.1,#tune.grid_search([0.8, 0.5, 0.2]),
        'T': 1
    }
    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }
    print(transform_config.keys())
    name = get_excel_name(config, transform_config)
    print(name)
    # data = pd.read_excel(r'/home/user/suteng/osteo_results/image/8.21_0.xlsx', index_col=0,
    #                      header=0,
    #                      sheet_name='Sheet1')
    # data.loc['mean'] = data.mean()
    # print(data)

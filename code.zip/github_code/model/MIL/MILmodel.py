import os

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from MILresnet import ResNet18, Pretrain

def freeze(model):
    for name, parameter in model.named_parameters():
         if 'key' in name:
             parameter.requires_grad = False
    return model

class AttentionPaper(nn.Module):
    def __init__(self, config, device, seed):
        super(AttentionPaper, self).__init__()
        self.L = 500
        self.D = 256
        self.K = 1
        self.device = device
        self.batch = config["batch_size"]
        self.model = ResNet18(config, self.L)

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

        self.classifier = nn.Sequential(
            nn.Linear(self.L * self.K, 3),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        x = x.squeeze(0)
        # x = x[0]
        # 将数据输入网络
        H = self.model(x)  # NxL

        # 经过分类器之前先经过注意力机制网络，得到对应的权重
        A = self.attention(H)  # NxK
        A = torch.transpose(A, 1, 0)  # KxN，翻转维度
        A = F.softmax(A, dim=1)  # softmax over N

        # 权重乘以网络的输出,从N个实例的N个特征向量L，变成一个特征向量L
        M = torch.mm(A, H)  # KxL
        # print('M', M.size())
        # 最后的特征经过分类器得到输出
        Y_prob = self.classifier(M)
        # print('Y_prob', Y_prob)
        Y_hat = torch.argmax(Y_prob, dim=1).float()
        # print('Y_hat', Y_hat)
        # Y_hat = torch.ge(Y_prob, 0.5).float()

        return Y_prob, Y_hat, A

        # AUXILIARY METHODS
    def calculate_classification_error(self, X, Y):
        Y = Y.float()
        _, Y_hat, _ = self.forward(X)
        error = 1. - Y_hat.eq(Y).cpu().float().mean().data.item()
        return error, Y_hat

    def calculate_classification_error_batch(self, X, Y):
        error = 0.
        for batch in range(len(X)):
            e, hat = self.calculate_classification_error(X[batch], Y[batch])
            error = error + e
        return error/len(X)


    def calculate_objective(self, X, Y):
        # print("X", X.size(), "Y", Y.size())

        Y = F.one_hot(Y, num_classes=3)
        Y = Y.float()
        Y = Y.squeeze(0)
        # print('Y:', Y)
        Y_prob, _, A = self.forward(X)
        Y_prob = Y_prob.squeeze(0)
        # print("Y_prob 1", Y_prob)
        Y_prob = torch.clamp(Y_prob, min=1e-5, max=1. - 1e-5)

        # print("Y_prob clamp", Y_prob)
        neg_log_likelihood = -1. * (
                    Y[0] * torch.log(Y_prob[0]) + Y[1] * torch.log(Y_prob[1]) + Y[2] * torch.log(Y_prob[2]))  # negative log bernoulli
        # print("loss:", neg_log_likelihood)
        return neg_log_likelihood, A

    def calculate_objective_batch(self, X, Y):
        Loss, A = 0., torch.empty((0, 5))
        A = A.to(self.device)
        for batch in range(len(X)):
            l, a = self.calculate_objective(X[batch], Y[batch])
            Loss = Loss + l
            A = torch.cat((A, a), 0)
        return Loss/len(X)


class Attention(nn.Module):
    def __init__(self, config, device, seed):
        super(Attention, self).__init__()
        self.L = 500
        self.D = 256
        self.K = 1
        self.device = device
        self.model = ResNet18(config, self.L)

        # self.model = Pretrain(self.model, seed)
        # self.model = freeze(self.model)

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

        self.classifier = nn.Sequential(
            nn.Linear(self.L * self.K, 3),
            # nn.Sigmoid()
        )

    def forward(self, x):
        #Y_A为attention的系数，所以此时为5维
        Y_prob, Y_hat, Y_A = torch.empty((0, 3)), torch.empty((0, 1)), torch.empty((0, 5))
        Y_prob, Y_A = Y_prob.to(self.device), Y_A.to(self.device)
        for i in range(len(x)):
            pro, hat, a = self.forwardOnePerson(x[i])
            Y_prob = torch.cat((Y_prob, pro), 0)
            # Y_hat = torch.cat((Y_hat, hat), 0)  出错原因hat维度为（1，），而Y_hat为（0，1）
            Y_A = torch.cat((Y_A, a), 0)
        return Y_prob

    def forwardOnePerson(self, x):
        x = x.squeeze(0)
        # x = x[0]
        # 将数据输入网络
        H = self.model(x)  # NxL

        # 经过分类器之前先经过注意力机制网络，得到对应的权重
        A = self.attention(H)  # NxK
        A = torch.transpose(A, 1, 0)  # KxN，翻转维度
        A = F.softmax(A, dim=1)  # softmax over N

        # 权重乘以网络的输出,从N个实例的N个特征向量L，变成一个特征向量L
        M = torch.mm(A, H)  # KxL

        # 最后的特征经过分类器得到输出
        Y_prob = self.classifier(M)
        Y_hat = torch.argmax(Y_prob, dim=1)

        return Y_prob, Y_hat, A

    # def forward(self, x):
    #     x = x.squeeze(0)
    #     # x = x[0]
    #     # 将数据输入网络
    #     H = self.model(x)  # NxL
    #
    #     # 经过分类器之前先经过注意力机制网络，得到对应的权重
    #     A = self.attention(H)  # NxK
    #     A = torch.transpose(A, 1, 0)  # KxN，翻转维度
    #     A = F.softmax(A, dim=1)  # softmax over N
    #
    #     # 权重乘以网络的输出,从N个实例的N个特征向量L，变成一个特征向量L
    #     M = torch.mm(A, H)  # KxL
    #
    #     # 最后的特征经过分类器得到输出
    #     Y_prob = self.classifier(M)
    #     # Y_hat = torch.argmax(Y_prob, dim=1)
    #     Y_hat = torch.ge(Y_prob, 0.5).float()
    #
    #     return Y_prob, Y_hat, A

        # AUXILIARY METHODS
    def calculate_classification_error(self, X, Y):
        Y = Y.float()
        _, Y_hat, _ = self.forward(X)
        error = 1. - Y_hat.eq(Y).cpu().float().mean().data.item()
        return error, Y_hat

    def calculate_objective(self, X, Y):
        # print("X", X.size(), "Y", Y.size())
        Y = Y.float()
        Y_prob, _, A = self.forward(X)
        # print("Y_prob 1", Y_prob.size())
        Y_prob = torch.clamp(Y_prob, min=1e-5, max=1. - 1e-5)
        # print("Y_prob clamp", Y_prob.size())
        neg_log_likelihood = -1. * (
                    Y * torch.log(Y_prob) + (1. - Y) * torch.log(1. - Y_prob))  # negative log bernoulli
        # print("loss:", neg_log_likelihood)
        return neg_log_likelihood, A


class ConCat(nn.Module):
    def __init__(self, config, device, seed):
        super(ConCat, self).__init__()
        self.L = 500
        self.K = 5
        self.device = device
        self.model = ResNet18(config, self.L)

        # self.model = Pretrain(self.model, seed)
        # self.model = freeze(self.model)

        self.classifier = nn.Sequential(
            nn.Linear(self.L * self.K, 3),
            # nn.Sigmoid()
        )

    def forward(self, x):
        #Y_A为attention的系数，所以此时为5维
        Y_prob, Y_hat, Y_A = torch.empty((0, 3)), torch.empty((0, 1)), torch.empty((0, 5))
        Y_prob, Y_A = Y_prob.to(self.device), Y_A.to(self.device)
        for i in range(len(x)):
            pro, hat = self.forwardOnePerson(x[i])
            Y_prob = torch.cat((Y_prob, pro), 0)
            # Y_hat = torch.cat((Y_hat, hat), 0)  出错原因hat维度为（1，），而Y_hat为（0，1）
        return Y_prob

    def forwardOnePerson(self, x):
        x = x.squeeze(0)
        # x = x[0]
        # 将数据输入网络
        H = self.model(x)  # NxL

        # 权重乘以网络的输出,从N个实例的N个特征向量L，变成一个特征向量L
        M = H.view(-1, self.L * self.K)  # KxL

        # 最后的特征经过分类器得到输出
        Y_prob = self.classifier(M)
        Y_hat = torch.argmax(Y_prob, dim=1)

        return Y_prob, Y_hat
if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    a = torch.randn(8, 5, 1, 224, 224)

    device = "cpu"
    if torch.cuda.is_available():
        device = torch.device('cuda')
    print('device:', device)

    a = a.to(device)
    config = {
        "epoch_num": 280,
        "step_size": 70,
        "lr": 0.001,
        "batch_size": 2,
        "image_flag": 'segment',  # 'segment', 'crop'
        "image_size": (224, 224),
        "resnet18_channels": [16, 32, 64, 128],
    }
    model = AttentionPaper(config, device, 6)
    model = model.to(device)
    # print(model.forwardOnePerson(torch.randn(5, 1, 384, 384)))
    y = torch.tensor([1, 0, 1, 1, 1, 1, 1, 0])
    y = y.to(device)
    print(model.calculate_objective_batch(a, y))
    loss = model.calculate_objective_batch(a, y)
    loss.backward()
    print(loss)

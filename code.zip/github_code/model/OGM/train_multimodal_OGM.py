import copy
import os.path

import torch.optim as optim
import numpy as np
import pandas as pd
import torch.backends.cudnn
import matplotlib.pyplot as plt
from osteoV2.model.image.excel_name import get_excel_name
from osteoV2.model.model_fusion.train_multimodal_V2_p2 import get_loader, setup_seed, test, get_labels_outputs
from ray import tune
from osteoV2.utils.para_update import *
from osteoV2.model.OGM.base_OGM import *

def train(config, model, device, para: ParaUpdate, model_save_dir, trainloader, valloader, checkpoint_dir=None, data_dir=None):
    epoch_num = config["epoch_num"]
    lr = config["lr"]
    step_size = config["step_size"]

    criterion = nn.CrossEntropyLoss()
    weight_p, bias_p = get_para_weight_bias(model)
    # optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)#weight_decay=1e-4
    optimizer = optim.SGD(
        [
            {'params': weight_p, 'weight_decay': 1e-4},
            {'params': bias_p, 'weight_decay': 0}
        ], lr=lr, momentum=0.9
    )
    # optimizer = optim.Adam(model.parameters(), lr=lr)
    #step_size为几个epoch进行衰减，gamma为衰减系数
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)

    '''checkpoint可以进行断点继续训练，保存模型时要将很多必要的状态都保存，此处是进行断点数据的读取'''
    if checkpoint_dir:
        model_state, optimizer_state = torch.load(
            os.path.join(checkpoint_dir, "checkpoint"))
        # model_state, optimizer_state = torch.load(checkpoint_dir)
        model.load_state_dict(model_state)
        optimizer.load_state_dict(optimizer_state)

    flag_imageval_print = False#是否显示验证集图像
    best_acc = 0.0#保存当前最好的准确率
    best_model = model
    best_model_wts = copy.deepcopy(model.state_dict())

    mini_batches_num = 5#训练时每过mini_batches_num个batchsize打印loss
    for epoch in range(epoch_num):  # loop over the dataset multiple times
        para.epoch_init()
        for i, data in enumerate(trainloader, 0):
            # get the inputs; data is a list of [inputs, labels]
            inputs_image, features, labels = data
            inputs_image, features, labels = inputs_image.to(device), features.to(device), labels.to(device)
            optimizer.zero_grad()
            img, cli, outputs = model(inputs_image, features)#[N, C, H, W]
            _, predicted = torch.max(outputs.data, 1)
            loss = criterion(outputs, labels)
            loss.backward()

            '/*********************************OGM**************************************/'
            clf = model.fusion_classifier
            out_v = (torch.mm(img, torch.transpose(clf.weight[:, :model.outsize_image], 0, 1))
                     + clf.bias / 2)

            out_a = (torch.mm(cli, torch.transpose(clf.weight[:, model.outsize_image:], 0, 1))
                     + clf.bias / 2)
            loss_v = criterion(out_v, labels)
            loss_a = criterion(out_a, labels)
            # Calculation of discrepancy ration and k.
            k_a, k_v = calculate_coefficient(labels, out_v, out_a, alpha=config['alpha'])

            # Gradient Modulation begins before optimization, and with GE applied.
            update_model_with_OGM_GE(model, k_a, k_v)

            '/**********************************************************************************/'

            optimizer.step()
            para.OGMLoss_update(loss_v.item(), loss_a.item())
            para.epoch_update('train', loss.item(), labels, predicted)
            labels, outputs = get_labels_outputs(labels, outputs)
            para.addLabel('train', labels, outputs)
        scheduler.step()

        for i, data in enumerate(valloader, 0):
            with torch.no_grad():
                inputs_image, features, labels = data
                inputs_image, features, labels = inputs_image.to(device), features.to(device), labels.to(device)
                _, _, outputs = model(inputs_image, features)
                #loss

                loss = criterion(outputs, labels)
                _, predicted = torch.max(outputs.data, 1)
                # print('predicted', predicted)
                para.epoch_update('val', loss.item(), labels, predicted)
                labels, outputs = get_labels_outputs(labels, outputs)
                para.addLabel('val', labels, outputs)
        para.update(savefig=True)
        if flag_print:
            print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" %
                  (epoch + 1, epoch_num, para.train_loss, para.train_acc))
            print('Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' %
                  (epoch + 1, epoch_num, para.val_loss, para.val_acc))

        # 利用验证集找出最好模型
        if para.val_acc > best_acc:
            best_acc = para.val_acc
            best_model_wts = copy.deepcopy(model.state_dict())
            best_model = copy.deepcopy(model)
            para.acc_getbetter()
        
    model.load_state_dict(best_model_wts)

    if flag_print:
        print('The Best Valdition |  accuracy: %.3f |' % best_acc)
    return model, para



def main(config):
    global seeds, path_plot
    image_size = config['image_size']
    # 8345, 28934, 209345, 599484, 30994, 9394, 92389, 39494, 394903, 1349]
    config["epoch_num"] = 3 * config["step_size"]
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        device = torch.device('cuda')
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    if flag_print:
        print('device:', device)
    '''================================================'''
    excel_name = get_excel_name(config, transform_config)

    data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_multimodal_limitextreme_onehot.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 7:]
    labels = data.iloc[:, 1]
    print('features:\n', features)
    print('labels:\n', labels)

    accuracy_test_average = 0#
    result = pd.DataFrame(index=range(len(seeds)),
                          columns=['seed', 'accuracy_train', 'accuracy_val', 'accuracy_test', 'auc_train', 'auc_test'])

    path_plot = '/home/user/suteng/osteo_results/OGM/plot/2.8/'
    if not os.path.exists(path_plot):
        os.makedirs(path_plot)
    config_i = len(os.listdir(path_plot)) + 1
    path_plot += ("alpha=" + str(config['alpha']) + "batch=" + str(config['batch_size'])
                  + "resnet=" + str(config['resnet18_channels'])
                  + "mlp=" + str(config['mlp']))
    path_plot += ("i=" + str(config_i))
    for i, seed in zip(range(len(seeds)), seeds):
        para = ParaUpdate()
        setup_seed(seed)
        if flag_print:
            print('-----seed=%d-----' % seed)
        trainloader, valloader, testloader = get_loader(config, transform_config, features, labels, seed)

        '''==================训练======================='''
        model = Net_resmlp(config, n_classes=3)
        if flag_model_load:
            model.load_state_dict(torch.load(model_load))
        model.to(device)
        model, para = train(config, model, device, para,
                            model_save_dir=model_save, trainloader=trainloader, valloader=valloader)
        test_acc, label_test = test(model, device, para, testloader)
        para.setResult_p3('test', 'acc', test_acc)

        # 保存图像
        para.plot_savefig(path_plot, seed, config["epoch_num"])
        para.plot_OGM(path_plot, seed, config["epoch_num"])

        accuracy_test_average += para.getResult_p2('test', 'acc')
        result = para.metric_compute(result, seed, i, n_class=3)

        if flag_model_save:
            path_save = "seed"+str(seed)+"val:"+str(para.val_acc)[:5]\
                        +"test"+str(test_acc)[:5]+"[16,32,64,128]{'b1': [4, 4], 'b2': [4, 4], 'b3': [4]}"+".pth"
            torch.save(model.state_dict(), os.path.join(model_save, path_save))  # 只保存模型参数

        if flag_print:
            print('---------------' + ('-'*len(str(seed))))
    result.loc['mean'] = result.mean()
    if flag_print:
        print(result)

    path = r'/home/user/suteng/osteo_results/OGM/2.8'
    if not os.path.exists(path):
        os.makedirs(path)
    result.to_excel(os.path.join(path, excel_name + '.xlsx'))
    if flag_print:
        print('The Test Average Accuracy:', accuracy_test_average / len(seeds))
    tune.report(
        acc_train=result.loc['mean', 'accuracy_train'],
        acc_val=result.loc['mean', 'accuracy_val'],
        acc_test=result.loc['mean', 'accuracy_test'],
        auc_train=result.loc['mean', 'auc_train'],
        auc_test=result.loc['mean', 'auc_test'],
                )
    return

if __name__ == '__main__':

    '''==================参数设置======================='''
    global seeds
    flag_print = True
    flag_model_load = False
    model_load = '/home/user/PycharmProjects/osteo/pretrained/model_save/fashionmnist/[16, 32, 64, 128].pth'
    flag_model_save = True
    model_save = '/home/user/PycharmProjects/osteo/osteoV2/model_save/OGM'
    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    os.environ[
        "CUDA_VISIBLE_DEVICES"] = '0'
    seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546]
    # seeds = seeds[:2]
    config = {
        "epoch_num": 420,
        "step_size": 140, #tune.grid_search([70, 100, 140]),
        "lr": 0.001,
        "batch_size": tune.grid_search([32]),
        "image_flag": 'segment',#'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": tune.grid_search([
            [16, 32, 64, 128]
        ]),
        'mlp': tune.grid_search([
            # 16,
            # [8],
            {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]},
            # {'b1': [8, 8], 'b2': [8, 8], 'b3': [8]},
            # {'b1': [16, 16], 'b2': [16, 16], 'b3': [16]},
        ]),
        'classifier': [0],#分类器的网络结构
        'freeze': 'not',#'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'not',#'cli', 'not' 蒸馏标志位
        'transfer': 'cli',#'cli', 'not'迁移标志位
        'alpha': tune.grid_search([0.1, 0.1, 0.1, 0.1, 0.1])
        # tune.grid_search([0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1])
    }
    transform_config = {
        'rot': (-25, 25),#旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }

    #输入为四节椎骨还是一节椎骨
    # torch.backends.cudnn.enabled = False
 # CUDA_VISIBLE_DEVICES限制一下使用的GPU。比如有0,1,2,3号GPU，CUDA_VISIBLE_DEVICES=2,3，则当前进程的可见GPU只有物理上的2、3号GPU，此时它们的编号也对应变成了0、1，即cuda:0对应2号GPU，cuda:1对应3号GPU

    '''================================================'''
    absolute_path = '/home/user/suteng/osteo'
    result = tune.run(
        main,
        resources_per_trial={"cpu": 28, "gpu": 1},  # 运行时的资源限制
        config=config,
        local_dir=absolute_path + '/ray_results/multimodal',  # 运行以及保存结果的位置
        # num_samples=3,  # random search时的采样次数
    )







# from osteoV2.model.clinical.mlp_V2 import *
import torch
import torch.nn as nn
from MILimg import Attention

def freeze_paraments(model):
    '''
    冻结部分层参数
    '''
    for child in model.children():
        # print(child)
        for param in child.parameters():
            param.requires_grad = False
            # print(param)
    return model

class Net(nn.Module):
    def __init__(self, config, device, n_classes=3):
        super(Net, self).__init__()
        self.device = device
        self.image, self.outsize_image = self.imgmodel(config)
        self.clinical, self.outsize_clinical = self.climodel(config)

        if config['freeze'] == 'cli' or config['freeze'] == 'both':
            self.clinical = freeze_paraments(self.clinical)
        if config['freeze'] == 'img' or config['freeze'] == 'both':
            self.image = freeze_paraments(self.image)

        self.fusion_classifier = nn.Linear(self.outsize_clinical + self.outsize_image, n_classes)

    def imgmodel(self, config):
        model = Attention(config, self.device)
        outsize = model.L * model.K
        return model, outsize

    def climodel(self, config):
        # model = Net_multimodel_clinical(layer=config['mlp'])
        # outsize = model.get_output_size()[1]
        midsize = config['mlp'][0]
        outsize = config['mlp'][1]
        l1 = nn.Linear(40, midsize)
        l2 = nn.Linear(midsize, outsize)
        model = nn.Sequential(l1, l2)
        return model, outsize

    def forward(self, data_image, data_clinical):
        image = self.image(data_image)#图像的边际表示
        clinical = self.clinical(data_clinical)#结构化数据的边际表示
        #拉成一维拼接后输入分类器
        image = image.view(len(image), -1)
        clinical = clinical.view(len(clinical), -1)
        marginal_representation = torch.concat((image, clinical), 1)
        out = self.fusion_classifier(marginal_representation)
        return out

class NetOutput3(Net):
    def forward(self, data_image, data_clinical):
        image = self.image(data_image)#图像的边际表示
        clinical = self.clinical(data_clinical)#结构化数据的边际表示
        #拉成一维拼接后输入分类器
        image = image.view(len(image), -1)
        clinical = clinical.view(len(clinical), -1)
        marginal_representation = torch.concat((image, clinical), 1)
        out = self.fusion_classifier(marginal_representation)
        return image, clinical, out

if __name__ == '__main__':
    # print(range(0))
    # for i in range(0):
    #     print(i)

    config = {
        "epoch_num": 5,
        "step_size": 30,
        "lr": 0.001,
        "batch_size": 5,
        "image_flag": 'segment',  # 'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": [16, 32, 64, 128],
        'mlp': [16, 8],
        'classifier': [512],  # 分类器的网络结构
        'freeze': 'not',  # 'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'not',  # 'cli', 'not' 蒸馏标志位
        'transfer': 'cli',  # 'cli', 'not'迁移标志位
    }
    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }

    device = "cpu"
    if torch.cuda.is_available():
        device = torch.device('cuda')
    print('device:', device)

    a = torch.randn(3, 5, 1, 384, 384)
    b = torch.randn(3, 40)
    a = a.to(device)
    b = b.to(device)
    model = Net(config, device)
    model.to(device)
    # print(model)
    outputs = model(a, b)

    # print(outputs)
    print(outputs[0].size())
    print(outputs[1].size())
    print(outputs[2].size())

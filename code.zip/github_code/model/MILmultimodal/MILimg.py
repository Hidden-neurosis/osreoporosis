import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from MILresnet import ResNet18

class Attention(nn.Module):
    def __init__(self, config, device, pretrained=True):
        super(Attention, self).__init__()
        self.L = 500
        self.D = 128
        self.K = 1
        self.device = device
        self.model = ResNet18(config, self.L, pretrained)

        self.attention = nn.Sequential(
            nn.Linear(self.L, self.D),
            nn.Tanh(),
            nn.Linear(self.D, self.K)
        )

    def forward(self, x):
        #Y_A为attention的系数，所以此时为5维
        Y = torch.empty((0, self.L))
        Y = Y.to(self.device)
        for i in range(len(x)):
            y = self.forwardOnePerson(x[i])
            Y = torch.cat((Y, y), 0)
        return Y

    def forwardOnePerson(self, x):
        x = x.squeeze(0)
        # x = x[0]
        # 将数据输入网络
        H = self.model(x)  # NxL

        # 经过分类器之前先经过注意力机制网络，得到对应的权重
        A = self.attention(H)  # NxK
        A = torch.transpose(A, 1, 0)  # KxN，翻转维度
        A = F.softmax(A, dim=1)  # softmax over N

        # 权重乘以网络的输出,从N个实例的N个特征向量L，变成一个特征向量L
        M = torch.mm(A, H)  # KxL

        return M


if __name__ == '__main__':
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    a = torch.randn(3, 5, 1, 384, 384)

    device = "cpu"
    if torch.cuda.is_available():
        device = torch.device('cuda')
    print('device:', device)

    a = a.to(device)
    config = {"resnet18_channels": [16, 32, 64, 128]}
    model = Attention(config, device)
    model = model.to(device)
    # print(model.forwardOnePerson(torch.randn(5, 1, 384, 384)))
    print(model(a))

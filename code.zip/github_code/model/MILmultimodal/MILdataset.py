import os
import cv2
import torch
import numpy as np
import pandas as pd
from pandas import DataFrame
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split

flag_test_main = 0#用于区分是否单独运行该py文件的标志位

'''计算训练集图像的均值与方差'''
def image_mean_std(id , dim: int = 1):
    '''
    :param id: 划分好的训练集病人id, list
    :param dim: 图像通道数
    :return:
    '''
    image_path = '../../data/img_num=5'
    mean = torch.zeros(dim)
    std = torch.zeros(dim)
    for label in ['label0', 'label1', 'label2']:
        ids = os.listdir(os.path.join(image_path, label))
        for idx in ids:
            if not (idx in id or int(idx) in id):
                continue
            path = os.path.join(image_path, label, idx)
            for i in os.listdir(path):
                image_name = os.path.join(path, i)
                X = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
                if dim == 1:
                    mean += X[:, :].mean()
                    std += X[:, :].std()
                elif dim > 1:
                    for d in range(dim):
                        mean[d] += X[d, :, :].mean()
                        std[d] += X[d, :, :].std()

    mean.div_(len(id) * 5 * 255)
    std.div_(len(id) * 5 * 255)
    return list(mean.numpy()), list(std.numpy())


'''读取png格式的分割完的矢状位的CT图像'''
class DatasetMultimodal(Dataset):
    def __init__(self, feature: DataFrame, label: DataFrame, means, stds, image_size, stage, transform_config=None):#输入为dataframe形式的label，index为住院号
        '''
        :param label: 输入为dataframe形式的label，index为住院号
        :param means: 训练集图像均值
        :param stds: 训练集图像方差
        :param stage: 设定是否为训练阶段，'train' 'not_train'
        '''
        self.image_size = image_size
        self.feature = feature
        self.label = label
        self.image_path = '/home/user/PycharmProjects/osteo/osteoV2/data/img_num=5/label'
        if flag_test_main:
            print('means, stds:', means, stds)
        self.stage = stage
        self.transform = {
            'train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.RandomVerticalFlip(p=0.5),
                    # 'rot': (-25, 25) 旋转角度
                    transforms.RandomRotation(degrees=transform_config['rot']),
                    # # 'col': (0.05, 0.05) (亮度，对比度)
                    transforms.ColorJitter(brightness=transform_config['col'][0], contrast=transform_config['col'][1]),
                    transforms.Normalize(means, stds)

                ]),
            'not_train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.Normalize(means, stds)
                ]),
        }

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        id = self.label.index[idx]
        label = self.label.loc[id]
        feature = self.feature.loc[id]
        image_path = os.path.join(self.image_path + str(label), str(id))
        imgs = torch.empty((0, 1, self.image_size[0], self.image_size[1]))
        # dir = os.listdir(image_path)
        for path in ['0.png', '1.png', '2.png', '3.png', '4.png']:
            image = cv2.imread(os.path.join(image_path, path), flags=cv2.IMREAD_GRAYSCALE)
            image = self.transform[self.stage](image)
            image = image.unsqueeze(0)
            imgs = torch.cat((imgs, image), 0)
        # image = image.type(torch.float16)
        label = torch.tensor(int(label), dtype=torch.int64)
        feature = torch.tensor(feature)
        feature = feature.to(torch.float32)
        return imgs, feature, label

def _init_fn(seed, worker_id):
    np.random.seed(seed+worker_id)
    return


if __name__ == '__main__':
    l = os.listdir('/home/user/suteng/osteo_data/Dataset/segment/label0')
    print(image_mean_std(l, dim=1))

    data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_multimodal_limitextreme_onehot.xlsx',
                         index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 7:]
    labels = data.iloc[:, 1]
    # print('features:\n', features)
    # print('labels:\n', labels)

    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train)
    means, stds = image_mean_std(y_train, dim=1)

    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0.05),  # (亮度，对比度)，对比度设为0
        'flip': 'h-v',
    }
    train_dataset = DatasetMultimodal(x_train, y_train, means, stds, (384, 384), 'not_train', transform_config)
    t = train_dataset[0]
    a = train_dataset[0][0]
    # print(a[2])
    b = train_dataset[0][1]
    print(t[0].size())
    print(t[1].size())
    print(t[2].size())
    print(t[2].shape)

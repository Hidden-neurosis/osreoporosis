import torch.nn as nn
import torch
from osteoV2.model.model_fusion.net_fusion import Net, Net_resmlp
import os
import matplotlib.pyplot as plt
softmax = nn.Softmax(dim=1)
tanh = nn.Tanh()
relu = nn.ReLU(inplace=True)


class Arguements:
    def __init__(self):
        self.alpha = 0.1
        self.modulation_starts = 1
        self.modulation_ends = 100
        self.modulation = "OGM_GE"

def calculate_coefficient(labels, out_v, out_a,  alpha):
    # print('size:', out_v.size(), out_a.size())
    score_v = sum([softmax(out_v)[i][labels[i]] for i in range(out_v.size(0))])
    score_a = sum([softmax(out_a)[i][labels[i]] for i in range(out_a.size(0))])

    ratio_v = score_v / score_a
    ratio_a = 1 / ratio_v

    if ratio_v > 1:
        coeff_v = 1 - tanh(alpha * relu(ratio_v))
        coeff_a = 1
    else:
        coeff_a = 1 - tanh(alpha * relu(ratio_a))
        coeff_v = 1

    return coeff_a, coeff_v

def update_model_OGM(model, coeff_a, coeff_v):
    args = Arguements()
    # 遍历模型修改梯度参数
    if args.modulation_starts <= epoch <= args.modulation_ends:  # bug fixed
        for name, parms in model.named_parameters():
            layer = str(name).split('.')[1]

            if 'audio' in layer and len(parms.grad.size()) == 4:
                if args.modulation == 'OGM_GE':  # bug fixed
                    parms.grad = parms.grad * coeff_a + \
                                 torch.zeros_like(parms.grad).normal_(0, parms.grad.std().item() + 1e-8)
                elif args.modulation == 'OGM':
                    parms.grad *= coeff_a

            if 'visual' in layer and len(parms.grad.size()) == 4:
                if args.modulation == 'OGM_GE':  # bug fixed
                    parms.grad = parms.grad * coeff_v + \
                                 torch.zeros_like(parms.grad).normal_(0, parms.grad.std().item() + 1e-8)
                elif args.modulation == 'OGM':
                    parms.grad *= coeff_v
    else:
        pass

def update_model_with_OGM_GE(model, coeff_a, coeff_v):
    args = Arguements()
    for name, parms in model.named_parameters():
        layer = str(name).split('.')[1]
        # print(parms.grad)
        if 'cli' in layer:
            # print(layer, 'cli')
            if args.modulation == 'OGM_GE':  # bug fixed
                parms.grad = parms.grad * coeff_a + \
                             torch.zeros_like(parms.grad).normal_(0, parms.grad.std().item() + 1e-8)
            elif args.modulation == 'OGM':
                parms.grad *= coeff_a
        elif 'img' in layer:
            # print(layer, 'img')
            if args.modulation == 'OGM_GE':  # bug fixed
                parms.grad = parms.grad * coeff_v + \
                             torch.zeros_like(parms.grad).normal_(0, parms.grad.std().item() + 1e-8)
            elif args.modulation == 'OGM':
                parms.grad *= coeff_v
        # print(parms.grad)

if __name__ == '__main__':
    config = {
        "epoch_num": 600,
        "step_size": 70,
        "lr": 0.001,
        "batch_size": 16,
        "image_flag": 'segment',#'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels":
            [16, 32, 64, 128],
        'mlp':
            {'b1': [4, 4], 'b2': [4, 4], 'b3': [4]},
        'classifier': [0],#分类器的网络结构
        'freeze': 'not',#'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'not',#'cli', 'not' 蒸馏标志位
        'transfer': 'not',#'cli', 'not'迁移标志位
    }
    net = Net(config, n_classes=3)
    model_name(net)
import torch
from pandas import DataFrame
from MILdataset import train_test_split, image_mean_std, DatasetMultimodal

def get_loader(config, transform_config: dict, features: DataFrame, labels: DataFrame, seed: int):
    image_size = config['image_size']
    BATCH_SIZE = config['batch_size']
    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels, random_state=seed)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train, random_state=seed)
    '''loader'''
    means, stds = image_mean_std(y_train.index, dim=1)
    dataset = DatasetMultimodal

    # print(x_train.shape)
    train_dataset = dataset(x_train, y_train, means, stds, image_size, stage='train',
                            transform_config=transform_config)
    # print(train_dataset[0])
    val_dataset = dataset(x_val, y_val, means, stds, image_size, stage='not_train',
                          transform_config=transform_config)
    test_dataset = dataset(x_test, y_test, means, stds, image_size, stage='not_train',
                           transform_config=transform_config)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True, num_workers=5,
                                              pin_memory=True)
    valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=BATCH_SIZE,
                                            shuffle=False, num_workers=5,
                                            pin_memory=True)
    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=False, num_workers=5,
                                             pin_memory=True)
    return trainloader, valloader, testloader
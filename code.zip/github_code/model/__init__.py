config = {
        "epoch_num": 280,
        "step_size": 70,
        "lr": 0.001,
        "batch_size": 16,
        "image_flag": 'segment',  # 'segment', 'crop'
        "image_size": (384, 384),
        "resnet18_channels": [32, 64, 128, 256],
    }
print(config)
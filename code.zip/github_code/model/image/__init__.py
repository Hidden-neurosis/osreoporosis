'''
image包主要包括单模态图像的数据类，图像数据处理，和单模态图像分类模型
cnn.py:自己编写的cnn通用模块
image_dataset.py:分割好的图像及其标签的读取类, 获取图像均值标准差的函数
image_process.py: 提取出分割后的标签文件
resnet18.py:现成的图像分类模型
'''
import yaml
import pandas as pd
yaml_path = './config.yaml'

def read_yaml(path):
    file = open(path, 'r', encoding='utf-8')
    string = file.read()
    dict = yaml.safe_load(string)

    return dict

Dict = read_yaml(yaml_path)
print(Dict['path_excel'])
data = pd.read_excel(Dict['path_excel'], index_col=0,
                         header=0,
                         sheet_name='Sheet1', nrows=20)
print(data)
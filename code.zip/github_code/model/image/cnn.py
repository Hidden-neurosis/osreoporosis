'''
自己编写的cnn通用模块
'''
import torch
import torch.nn as nn
import torch.nn.functional as F

'''多模态融合分割后图像的特征提取部分完整框架'''
class Net_multimodel_CNN(nn.Module):

    def __init__(self):
        super(Net_multimodel_CNN, self).__init__()
        self.conv1 = nn.Conv2d(3, 8, kernel_size=1, stride=1, padding=0, bias=True)
        self.maxpool_0 = nn.MaxPool2d(3, stride=2)
        self.block1 = CNN_block(8, 8)
        self.block2 = CNN_block(8, 16)
        self.block3 = CNN_block(16, 32)
        self.block4 = CNN_block(32, 16)
        self.maxpool = nn.MaxPool2d(2, stride=2)
    def forward(self, x):
        out = self.conv1(x)
        out = self.maxpool_0(out)
        out = self.block1(out)
        out = self.maxpool(out)
        out = self.block2(out)
        out = self.maxpool(out)
        out = self.block3(out)
        out = self.maxpool(out)
        out = self.block4(out)
        out = self.maxpool(out)
        return out
    def get_output_size(self):
        a = torch.randn(4, 3, 388, 388)#需要根据数据尺寸修改
        out = self.forward(a)
        out = out.view(len(a), -1)
        return out.size()

# '''单独CT图像分类模型'''
# class Net_singlemodel_CNN(nn.Module):
#

'''分割后图像的特征提取部分的组成模块，使用卷积层'''
class CNN_block(nn.Module):
    def __init__(self, input_channels, output_channels):
        super(CNN_block, self).__init__()
        channel_1 = 5
        channel_2 = 5
        channel_3 = output_channels
        #设计残差块时要保证输入与输出的特征图尺寸相同，通道数可以不同，采用1*1卷积即可。
        self.conv1 = nn.Conv2d(input_channels, channel_1, kernel_size=1, stride=1, padding=0, bias=True)
        self.bn1 = nn.BatchNorm2d(channel_1)
        self.conv2 = nn.Conv2d(channel_1, channel_2, kernel_size=3, stride=1, padding=1, bias=True)
        self.bn2 = nn.BatchNorm2d(channel_2)
        self.conv3 = nn.Conv2d(channel_2, channel_3, kernel_size=1, stride=1, padding=0, bias=True)
        self.bn3 = nn.BatchNorm2d(channel_3)
        self.shortcut = nn.Sequential()
        if input_channels != output_channels:#若通道数不同，则使用1*1卷积改变通道数
            self.shortcut.add_module('shortcut_conv',
                                     nn.Conv2d(input_channels, output_channels, kernel_size=1, stride=1, padding=0,
                                               bias=False))
            self.shortcut.add_module('shortcut_bn', nn.BatchNorm2d(output_channels))

    def forward(self, x):
        out = self.conv1(x)
        out = self.bn1(out)
        out = F.relu(out, inplace=False)
        out = self.conv2(out)
        out = self.bn2(out)
        out = F.relu(out, inplace=False)
        out = self.conv3(out)
        out = self.bn3(out)
        residual = self.shortcut(x)
        return F.relu(out + residual)


if __name__ == '__main__':
    a = torch.randn(4, 3, 388, 388)
    b = torch.randn(4, 30)
    model = Net_CNN()
    outputs = model(a)
    # print(outputs)
    print(outputs.size())
    print(model.get_output_size())
    # print(list(model.children()))
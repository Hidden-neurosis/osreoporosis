import sklearn.model_selection
import torch
import numpy as np
import random
import pandas as pd
from pandas import DataFrame
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split, StratifiedKFold
from image_dataset_V2_class3 import *
import torch.nn.functional as F

def load_paraments_partial(model, path):
    model_pretrained = torch.load(path)
    for i, key1, key2 in zip(range(20), model.state_dict().keys(), model_pretrained.keys()):
        if model.state_dict()[key1].size() == model_pretrained[key2].size():
            # print(key1, key2)
            model.state_dict()[key1].copy_(model_pretrained[key2])
        else:
            print('维度不匹配')
            break
    print('模型已经预加载')
    return model

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True

def data_split_kfold(features, labels, seed):
    train = {
        'X': [],
        'y': []
    }
    test = {
        'X': [],
        'y': []
    }
    train['X'], test['X'], train['y'], test['y'] = \
        train_test_split(features, labels, test_size=0.2, stratify=labels)
    kfold = StratifiedKFold(n_splits=5, random_state=seed, shuffle=True)
    # kfold.get_n_splits(X['train'], y['train'])
    return kfold.split(train['X'], train['y']), train, test


def get_loader(config: dict, transform_config: dict, features: DataFrame, labels: DataFrame, seed: int):

    image_size = config['image_size']
    BATCH_SIZE = config['batch_size']
    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels, random_state=seed)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train, random_state=seed)
    '''loader'''
    if config['image_flag'] == 'concat':
        means, stds = imageConcat_mean_std(y_train.index, config['image_flag'], dim=1)
    else:
        means, stds = image_mean_stdMIL(y_train.index, config['image_flag'], dim=1)

    if config['image_flag'] == 'segment':
        # dataset = Dataset_image_segment_png
        dataset = Dataset_image_segment_pngV2
    elif config['image_flag'] == 'crop':
        dataset = Dataset_image_crop_png
    elif config['image_flag'] == 'concat':
        dataset = Dataset_imageConcat

    # print(x_train.shape)
    train_dataset = dataset(y_train, means, stds, image_size, stage='train',
                            transform_config=transform_config)
    # print(train_dataset[0])
    val_dataset = dataset(y_val, means, stds, image_size, stage='not_train',
                          transform_config=transform_config)
    test_dataset = dataset(y_test, means, stds, image_size, stage='not_train',
                           transform_config=transform_config)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True, num_workers=5,
                                              pin_memory=True)
    valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=BATCH_SIZE,
                                            shuffle=False, num_workers=5,
                                            pin_memory=True)
    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=False, num_workers=5,
                                             pin_memory=True)
    return trainloader, valloader, testloader

def test(model, device, testloader):

    correct = 0
    total = 0
    label = {'real': [], 'predict': []}
    with torch.no_grad():
        for i, data in enumerate(testloader, 0):
            inputs_image, labels = data
            inputs_image, labels = inputs_image.to(device), labels.to(
                device)
            outputs = model(inputs_image)
            # print('testloader outputs.size():', outputs.size())
            _, predicted = torch.max(outputs.data, 1)
            # print('testloader predicted.size():', predicted.size())
            # print('testloader label.size():', labels.size())
            total += labels.size(0)
            # print(labels.size(0))
            # imshow_tensor(predicted)
            correct += ((predicted == labels).sum().item())
            # print('test image total num:', total)

            # 保存结果，计算指标
            labels = labels.cpu()
            outputs = F.softmax(outputs, dim=1)
            outputs = outputs.cpu()
            labels = labels.detach().numpy()
            outputs = outputs.detach().numpy()
            label['real'].extend(labels)
            label['predict'].extend(outputs)

    print('The Test Accuracy:', correct / total)
    return correct / total, label

def auc_compute(result: DataFrame, result_metric: dict,
                label_train: dict, label_test: dict,
                seed: int, i: int, n_class: int =2):
    '''
    计算AUC指标并写入dataframe
    :param result: 最后的指标结果总表
    :param result_metric: 从训练过程获得的指标计算结果
    :param label_train: 训练过程的标签
    :param label_test: 训练过程的标签
    :param seed:
    :param i: 第几行，从seed的for循环中获取
    :param n_class: 几分类
    :return:
    '''
    if n_class == 2:
        multi_class = 'raise'
    elif n_class >= 3:
        multi_class = 'ovo'#'ovo'
    label_train_predict = np.array(label_train['train']['predict'])
    label_test_predict = np.array(label_test['predict'])
    label_train_real = np.array(label_train['train']['real'])
    label_test_real = np.array(label_test['real'])
    if multi_class == 'raise':
        print('二分类AUC')
        label_train_predict = label_train_predict[:, 1]
        label_test_predict = label_test_predict[:, 1]
    elif multi_class == 'ovo' or multi_class == 'ovr':
        print('多分类AUC')
    # print('label_train_predict:\n', label_train_predict.sum(axis=1))
    try:
        result_metric['train']['auc'] = roc_auc_score(label_train_real, label_train_predict, multi_class=multi_class)
        result_metric['test']['auc'] = roc_auc_score(label_test_real, label_test_predict, multi_class=multi_class)
    except:
        result_metric['train']['auc'] = 0
        result_metric['test']['auc'] = 0
    # 'accuracy_train', 'accuracy_val', 'accuracy_test'
    result.loc[i]['seed'] = seed
    result.loc[i]['accuracy_train'] = result_metric['train']['accuracy']
    result.loc[i]['accuracy_val'] = result_metric['val']['accuracy']
    result.loc[i]['accuracy_test'] = result_metric['test']['accuracy']
    result.loc[i]['auc_train'] = result_metric['train']['auc']
    result.loc[i]['auc_test'] = result_metric['test']['auc']
    return result

if __name__ == '__main__':
    data = pd.read_excel(r'//home/user/suteng/data/CT-sagittal/segment_crop/二分类_齐鲁省立汇总不缺失_image.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 2:]
    labels = data.iloc[:, 0]
    # kfold, train, test = data_split(features, labels, seed=6)
    # X = train["]
    # for train_index, val_index in kfold:
    #     X_train, X_test = X[train_index], X[test_index]
    #     y_train, y_test = y[train_index], y[test_index]
    #     print(np.shape())


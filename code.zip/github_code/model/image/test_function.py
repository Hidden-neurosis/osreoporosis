import torch
import numpy as np
import random
from sklearn.model_selection import train_test_split
from pandas import DataFrame
from osteoV2.model.image.image_dataset_V2 import Dataset_image_segment_png, Dataset_image_crop_png, image_mean_std
from sklearn.metrics import roc_auc_score

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

def get_loader(config: dict, transform_config: dict, features: DataFrame, labels: DataFrame, seed: int):

    image_size = config['image_size']
    BATCH_SIZE = config['batch_size']
    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels, random_state=seed)
    '''loader'''
    means, stds = image_mean_std(y_train.index, flag=config['image_flag'], dim=1)
    if config['image_flag'] == 'segment':
        dataset = Dataset_image_segment_png
    elif config['image_flag'] == 'crop':
        dataset = Dataset_image_crop_png
    train_dataset = dataset(y_train, means, stds, image_size, stage='train',
                            transform_config=transform_config)

    test_dataset = dataset(y_test, means, stds, image_size, stage='not_train',
                           transform_config=transform_config)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True)

    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=True)
    return trainloader, testloader

def auc_compute(result: DataFrame, result_metric: dict,
                label_train: dict, label_test: dict,
                seed: int, i: int, n_class: int =2):
    '''
    计算AUC指标并写入dataframe
    :param result: 最后的指标结果总表
    :param result_metric: 从训练过程获得的指标计算结果
    :param label_train: 训练过程的标签
    :param label_test: 训练过程的标签
    :param seed:
    :param i: 第几行，从seed的for循环中获取
    :param n_class: 几分类
    :return:
    '''
    if n_class == 2:
        multi_class = 'raise'
    elif n_class >= 3:
        multi_class = 'ovr'#'ovo'
    label_train_predict = np.array(label_train['train']['predict'])
    label_test_predict = np.array(label_test['predict'])
    label_train_real = np.array(label_train['train']['real'])
    label_test_real = np.array(label_test['real'])
    if multi_class == 'raise':
        print('二分类AUC')
        label_train_predict = label_train_predict[:, 1]
        label_test_predict = label_test_predict[:, 1]
    elif multi_class == 'ovo' or multi_class == 'ovr':
        print('多分类AUC')

    result_metric['train']['auc'] = roc_auc_score(label_train_real, label_train_predict, multi_class=multi_class)
    result_metric['test']['auc'] = roc_auc_score(label_test_real, label_test_predict, multi_class=multi_class)
    # 'accuracy_train', 'accuracy_val', 'accuracy_test'
    result.loc[i]['seed'] = seed
    result.loc[i]['accuracy_train'] = result_metric['train']['accuracy']
    result.loc[i]['accuracy_val'] = result_metric['val']['accuracy']
    result.loc[i]['accuracy_test'] = result_metric['test']['accuracy']
    result.loc[i]['auc_train'] = result_metric['train']['auc']
    result.loc[i]['auc_test'] = result_metric['test']['auc']
    return result

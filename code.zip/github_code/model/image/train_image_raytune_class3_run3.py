
from ray import tune
import copy
import torch.optim as optim
import torch.backends.cudnn
from osteoV2.model.image.resnet18 import ResNet18_class
from osteoV2.model.image.excel_name import get_excel_name
from osteoV2.model.image.train_image_raytune_class3_p2 import *
from osteoV2.utils.para_update import *

global trainloader, valloader, writer_train, writer_val


def get_labels_outputs(labels, outputs):
    labels = labels.cpu()
    outputs = F.softmax(outputs, dim=1)
    outputs = outputs.cpu()
    labels = labels.detach().numpy()
    outputs = outputs.detach().numpy()
    return labels, outputs

def train(config, model, device, para: ParaUpdate, model_save_dir, checkpoint_dir=None, data_dir=None):
    global trainloader, valloader, writer_train, writer_val
    epoch_num = config["epoch_num"]
    lr = config["lr"]
    step_size = config["step_size"]

    criterion = nn.CrossEntropyLoss()
    # criterion = nn.BCELoss()
    # criterion = Weighted_Cross_Entropy_Loss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    # optimizer = optim.Adam(model.parameters(), lr=lr)
    #step_size为几个epoch进行衰减，gamma为衰减系数
    # scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=16,
                                                           verbose=False,
                                                           threshold=0.0001, threshold_mode='rel', cooldown=10,
                                                           eps=1e-08)
    '''checkpoint可以进行断点继续训练，保存模型时要将很多必要的状态都保存，此处是进行断点数据的读取'''
    if checkpoint_dir:
        model_state, optimizer_state = torch.load(
            os.path.join(checkpoint_dir, "checkpoint"))
        # model_state, optimizer_state = torch.load(checkpoint_dir)
        model.load_state_dict(model_state)
        optimizer.load_state_dict(optimizer_state)

    flag_imageval_print = False#是否显示验证集图像
    best_acc = 0.0#保存当前最好的准确率
    best_model = model
    best_model_wts = copy.deepcopy(model.state_dict())
    for epoch in range(epoch_num):  # loop over the dataset multiple times
        para.epoch_init()
        for i, data in enumerate(trainloader, start=0):
            # get the inputs; data is a list of [inputs, labels]
            inputs_image, labels = data
            inputs_image, labels = inputs_image.to(device), labels.to(device)
            optimizer.zero_grad()

            outputs = model(inputs_image)#[N, C, H, W]
            loss = criterion(outputs, labels)
            _, predicted = torch.max(outputs.data, 1)
            loss.backward()
            optimizer.step()

            para.epoch_update('train', loss.item(), labels, predicted)
            labels, outputs = get_labels_outputs(labels, outputs)
            para.addLabel('train', labels, outputs)

        scheduler.step(loss)

        for i, data in enumerate(valloader, 0):
            with torch.no_grad():
                inputs_image, labels = data
                inputs_image, labels = inputs_image.to(device), labels.to(
                    device)
                outputs = model(inputs_image)
                #loss
                loss = criterion(outputs, labels)
                _, predicted = torch.max(outputs.data, 1)
                para.epoch_update('val', loss.item(), labels, predicted)

                # 结果保存，用于计算各种指标
                labels, outputs = get_labels_outputs(labels, outputs)
                para.addLabel('val', labels, outputs)

        para.update(savefig=True)
        if flag_print:
            print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" %
                  (epoch + 1, epoch_num, para.train_loss, para.train_acc))
            print('Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' %
                  (epoch + 1, epoch_num, para.val_loss, para.val_acc))

        # 利用验证集找出最好模型
        if para.val_acc > best_acc:
            best_acc = para.val_acc
            best_model_wts = copy.deepcopy(model.state_dict())
            best_model = copy.deepcopy(model)
            para.acc_getbetter()

    model.load_state_dict(best_model_wts)

    # 只保存模型参数
    if flag_print:
        print('The Best Valdition |  accuracy: %.3f |' % best_acc)
    return model, para

def test(model, device, para, testloader):
    global trainloader, valloader, writer_train, writer_val
    correct = 0
    total = 0
    label = {'real': [], 'predict': []}
    with torch.no_grad():
        for i, data in enumerate(testloader, 0):
            inputs_image, labels = data
            inputs_image, labels = inputs_image.to(device), labels.to(
                device)
            outputs = model(inputs_image)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            # imshow_tensor(predicted)
            correct += ((predicted == labels).sum().item())
            # print('test image total num:', total)

            # 保存结果，计算指标
            labels, outputs = get_labels_outputs(labels, outputs)
            para.addLabel('test', labels, outputs)
    if flag_print:
        print('The Test Accuracy:', correct / total)
    return correct / total,label

def main(config):
    global config_i

    # config["epoch_num"] = 4 * config["step_size"]

    '''==================参数设置======================='''
    global trainloader, valloader, seeds
    # 输入为四节椎骨还是一节椎骨
    image_size = config['image_size']
    BATCH_SIZE = config['batch_size']
      # ,
    # 8345, 28934, 209345, 599484, 30994, 9394, 92389, 39494, 394903, 1349]
    # seeds = [6, 666]
    excel_name = get_excel_name(config, transform_config)

      # CUDA_VISIBLE_DEVICES限制一下使用的GPU。比如有0,1,2,3号GPU，CUDA_VISIBLE_DEVICES=2,3，则当前进程的可见GPU只有物理上的2、3号GPU，此时它们的编号也对应变成了0、1，即cuda:0对应2号GPU，cuda:1对应3号GPU

    '''================================================'''

    '''==================device======================='''
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        # device = "cuda:0"
        device = torch.device('cuda')
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    print('device:', device)

    '''================================================'''

    '''==================读取数据======================='''
    data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_image.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 0]
    labels = data.iloc[:, 1]
    print(features)
    print(labels)
    accuracy_test_average = 0  #
    result = pd.DataFrame(index=range(len(seeds)),
                          columns=['seed', 'accuracy_train', 'accuracy_val', 'accuracy_test', 'auc_train', 'auc_test'])
    path_plot = '/home/user/suteng/osteo_results/class3/plot/image_pretrained/11.7_sample435'
    if not os.path.exists(path_plot):
        os.makedirs(path_plot)
    config_i = len(os.listdir(path_plot)) + 1
    path_plot += str(config_i)
    for i, seed in enumerate(seeds):
        para = ParaUpdate()  # 存放参数的类
        setup_seed(seed)
        if flag_print:
            print('-----seed=%d-----' % seed)

        trainloader, valloader, testloader = get_loader(config, transform_config, features, labels, seed=seed)
        #half()函数为使用float16，以减少显存使用
        model = ResNet18_class(image_size=image_size, channels=config["resnet18_channels"], n_classes=3)
        if flag_model_load:
            # model.load_state_dict(torch.load(model_load), strict=False)
            model = load_paraments_partial(model, model_load)
        model.to(device)
        model, para = train(config, model, device, para, model_save_dir=model_save)
        test_acc, label_test = test(model, device, para, testloader)
        if flag_model_save:
            torch.save(model.state_dict(), os.path.join(model_save, 'seed=' + str(seed) +
                                                             str(config["resnet18_channels"]) +
                                                             "val" + str(para.val_acc)[:5] +
                                                             "test" + str(test_acc)[:5] +
                                                            ".pth"))
        para.setResult_p3('test', 'acc', test_acc)

        #保存图像
        para.plot_savefig(path_plot, seed, config["epoch_num"])

        accuracy_test_average += para.getResult_p2('test', 'acc')
        result = para.metric_compute(result, seed, i, n_class=3)
        if flag_print:
            print('---------------' + ('-' * len(str(seed))))
    result.loc['mean'] = result.mean()
    print(result)

    path = r'/home/user/suteng/osteo_results/class3/image_pretrained/11.7_sample435'
    if not os.path.exists(path):
        os.makedirs(path)
    result.to_excel(os.path.join(path, excel_name + '.xlsx'))
    if flag_print:
        print('The Test Average Accuracy:', accuracy_test_average / len(seeds))
    if flag_tune:
        tune.report(
            acc_train=result.loc['mean', 'accuracy_train'],
            acc_val=result.loc['mean', 'accuracy_val'],
            acc_test=result.loc['mean', 'accuracy_test'],
            auc_train=result.loc['mean', 'auc_train'],
            auc_test=result.loc['mean', 'auc_test'],
                    )
    return

if __name__ == '__main__':
    global trainloader, valloader, writer_train, writer_val, seeds, config_i
    config_i = 0
    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'

    #设定默认数据类型为float16，以减小显存的使用
    # torch.set_default_tensor_type(torch.cuda.HalfTensor)
    flag_tune = False
    flag_print = True
    flag_model_load = True
    model_load = '/home/user/PycharmProjects/osteo/pretrained/model_save/fashionmnist/[16, 32, 64, 128].pth'
    flag_model_save = True
    model_save = '/home/user/PycharmProjects/osteo/osteoV2/model_save/class3/image11.7/'
    seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546]
    # seeds = seeds[:1]
    config = {
        "epoch_num": 200,
        "step_size": 70, #tune.grid_search([30]),
        "lr": 0.001,
        "batch_size": tune.grid_search([16]),
        "image_flag": 'segment',  # 'segment', 'crop'
        "image_size": (224, 224),
        "resnet18_channels":
        tune.grid_search([
            [16, 32, 64, 128]
        ])
    }

    # config = {
    #     "epoch_num": 200,
    #     "step_size": 1,
    #     "lr": 0.001,
    #     "batch_size": 16,
    #     "image_flag": 'segment',  # 'segment', 'crop'
    #     "image_size": (384, 384),
    #     "resnet18_channels": [16, 32, 64, 128],
    # }

    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0),#(亮度，对比度)，对比度设为0
        'flip': 'h-v',
    }
    # main(config)
    absolute_path = '/home/user/suteng/osteo'
    result = tune.run(
        main,
        resources_per_trial={"cpu": 28, "gpu": 1},  # 运行时的资源限制
        config=config,
        local_dir=absolute_path + '/ray_results',  # 运行以及保存结果的位置
        # num_samples=3,  # random search时的采样次数
    )






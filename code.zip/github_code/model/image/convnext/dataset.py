import os
import cv2
import torch
from pandas import DataFrame
from torch.utils.data import Dataset
import torchvision.transforms as transforms

flag_test_main = 0#用于区分是否单独运行该py文件的标志位

'''计算训练集图像的均值与方差'''
def image_mean_std(id :DataFrame.index, flag: str, dim: int = 1):
    '''
    :param id: 划分好的训练集病人id, list
    :param dim: 图像通道数
    :return:
    '''
    image_path = '/home/user/suteng/osteo_data/Dataset'
    image_path += '/' + flag
    dir = os.walk(image_path)
    mean = torch.zeros(dim)
    std = torch.zeros(dim)
    for root, dirs, files in dir:
        # print('root:', root)
        # print('dirs:', dirs)
        if files != [] and dirs == []:
            # print('files:', files)
            name, endings = os.path.splitext(files[0])
            # print(name, type(name))
            if flag == 'crop':
                name, Ln = name.split('_', 2)
            elif flag == 'segment':
                Ln = 'L1-4'

            if (name in id or int(name) in id) and \
                    (Ln == 'L1-4' or Ln == 'L1' or Ln == 'L2' or Ln == 'L3' or Ln == 'L4'):
                image_name = root + '/' + files[0]
                X = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
                if dim == 1:
                    mean += X[:, :].mean()
                    std += X[:, :].std()
                elif dim > 1:
                    for d in range(dim):
                        mean[d] += X[d, :, :].mean()
                        std[d] += X[d, :, :].std()

    mean.div_(len(id) * 255)
    std.div_(len(id) * 255)
    return list(mean.numpy()), list(std.numpy())

'''读取png格式的分割完的矢状位的CT图像'''
class Dataset_image_segment_png(Dataset):
    def __init__(self, label: DataFrame, means, stds, image_size, stage, transform_config=None):#输入为dataframe形式的label，index为住院号
        '''
        :param label: 输入为dataframe形式的label，index为住院号
        :param means: 训练集图像均值
        :param stds: 训练集图像方差
        :param stage: 设定是否为训练阶段，'train' 'not_train'
        '''
        self.label = label
        self.image_path = '/home/user/suteng/osteo_data/Dataset/segment/label'
        if flag_test_main:
            print('means, stds:', means, stds)
        self.stage = stage
        self.transform = {
            'train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.RandomVerticalFlip(p=0.5),#增强到此还是过拟合
                    # transforms.RandomRotation(degrees=transform_config['rot']),#此时800个epoch后可以过拟合
                    # transforms.ColorJitter(brightness=transform_config['col'][0], contrast=transform_config['col'][1]),
                    transforms.Normalize(means, stds)
                ]),
            'not_train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.Normalize(means, stds)
                ]),
        }

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        label = self.label.loc[image_name]
        image_name = os.path.join(self.image_path + str(label), str(image_name), str(image_name) + '.png')
        image = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
        image = self.transform[self.stage](image)
        # image = image.type(torch.float16)
        label = torch.tensor(int(label), dtype=torch.int64)
        # label = torch.tensor(int(label))
        # plt.imshow(image, cmap='gray')
        # plt.show()
        return image, label

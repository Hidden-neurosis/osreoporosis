import os
import cv2
import numpy as np
import pandas as pd
import shutil
from sklearn.preprocessing import OneHotEncoder

if __name__ == '__main__':
    '''提取出分割后的标签文件'''
    root = '/home/user/suteng/osteo/osteo_new/data/train/labelme/json_to_dataset'
    destination = '/home/user/suteng/osteo/data/image/segment_label'
    print(len(os.listdir(root)))
    for i, filename in zip(range(len(os.listdir(root))), os.listdir(root)):
        source = root + '/' + filename + '/label.png'
        shutil.copy(source, destination)
        os.rename(destination + '/label.png', destination + '/' + filename + '.png')

    # '''将彩色图像转换为灰度图像'''
    # root = '/home/user/suteng/osteo/data/image/segment_label'



import os
import cv2
import torch, torchvision
import numpy as np
import pandas as pd
from pandas import DataFrame
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

flag_test_main = 0#用于区分是否单独运行该py文件的标志位

'''计算训练集图像的均值与方差'''
def image_mean_std(id :DataFrame.index, flag: str, dim: int = 1):
    '''
    :param id: 划分好的训练集病人id, list
    :param dim: 图像通道数
    :return:
    '''
    image_path = '/home/user/suteng/osteo_data/Dataset'
    image_path += '/' + flag
    dir = os.walk(image_path)
    mean = torch.zeros(dim)
    std = torch.zeros(dim)
    for root, dirs, files in dir:
        # print('root:', root)
        # print('dirs:', dirs)
        if files != [] and dirs == []:
            # print('files:', files)
            name, endings = os.path.splitext(files[0])
            # print(name, type(name))
            if flag == 'crop':
                name, Ln = name.split('_', 2)
            elif flag == 'segment':
                Ln = 'L1-4'

            if (name in id or int(name) in id) and \
                    (Ln == 'L1-4' or Ln == 'L1' or Ln == 'L2' or Ln == 'L3' or Ln == 'L4'):
                image_name = root + '/' + files[0]
                X = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
                if dim == 1:
                    mean += X[:, :].mean()
                    std += X[:, :].std()
                elif dim > 1:
                    for d in range(dim):
                        mean[d] += X[d, :, :].mean()
                        std[d] += X[d, :, :].std()

    mean.div_(len(id) * 255)
    std.div_(len(id) * 255)
    return mean, std

'''读取png格式的分割完的矢状位的CT图像'''
class Dataset_image_segment_png(Dataset):
    def __init__(self, label: DataFrame, means, stds, image_size, stage, transform_config=None):#输入为dataframe形式的label，index为住院号
        '''

        :param label: 输入为dataframe形式的label，index为住院号
        :param means: 训练集图像均值
        :param stds: 训练集图像方差
        :param stage: 设定是否为训练阶段，'train' 'not_train'
        '''
        self.label = label
        # self.image_path = '/home/user/suteng/data/CT-sagittal/segment_crop/segment/label'
        self.image_path = '/home/user/suteng/osteo_data/Dataset/segment/label'
        if flag_test_main:
            print('means, stds:', means, stds)
        self.stage = stage
        self.transform = {
            'train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.RandomVerticalFlip(p=0.5),
                    transforms.RandomRotation(degrees=transform_config['rot']),
                    transforms.ColorJitter(brightness=transform_config['col'][0], contrast=transform_config['col'][1]),
                    transforms.Normalize(means, stds)
                ]),
            'not_train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.Normalize(means, stds)
                ]),
        }

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        label = self.label.loc[image_name]
        image_name = os.path.join(self.image_path + str(label), str(image_name), str(image_name) + '.png')
        image = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
        image = self.transform[self.stage](image)
        label = torch.tensor(int(label))
        # plt.imshow(image, cmap='gray')
        # plt.show()
        return image, label

'''读取png格式的分割完的矢状位的一节椎骨的CT图像'''
class Dataset_image_crop_png(Dataset):
    def __init__(self, label :DataFrame, means, stds, image_size, stage, transform_config=None):#输入为dataframe形式的label，index为住院号
        '''

        :param label: 输入为dataframe形式的label，index为住院号
        :param means: 训练集图像均值
        :param stds: 训练集图像方差
        :param stage: 设定是否为训练阶段，'train' 'not_train'
        '''
        self.label = label
        self.image_path = '/home/user/suteng/data/CT-sagittal/segment_crop/crop/label'
        self.endings = ['_L1.png', '_L2.png', '_L3.png', '_L4.png']
        if flag_test_main:
            print('means, stds:', means, stds)
        self.stage = stage
        self.transform = {
            'train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    # transforms.RandomCrop(384, 300),
                    # transforms.RandomAffine(0, (0.1, 0)),
                    transforms.RandomHorizontalFlip(p=0.5),
                    transforms.RandomVerticalFlip(p=0.5),
                    transforms.RandomRotation(degrees=transform_config['rot']),
                    transforms.ColorJitter(brightness=transform_config['col'][0], contrast=transform_config['col'][1]),
                    transforms.Normalize(means, stds)
                ]),
            'not_train':
                transforms.Compose([
                    # transforms.ToPILImage(),
                    transforms.ToTensor(),
                    transforms.Resize(image_size),
                    transforms.Normalize(means, stds)
                ]),
        }

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        label = self.label.loc[image_name]
        label = float(label)
        image_root = self.image_path + str(label) + '/' + str(image_name) + '/' + str(image_name)
        for ending in self.endings:
            if os.path.exists(image_root + ending):
                image_name = image_root + ending
                break
        image = cv2.imread(image_name, flags=cv2.IMREAD_GRAYSCALE)
        image = self.transform[self.stage](image)
        label = torch.tensor(int(label))
        # plt.imshow(image, cmap='gray')
        # plt.show()
        return image, label

'''读取bmp格式的矢状位CT图像及临床数据'''
class Dataset_multimodal_segment_png(Dataset):
    def __init__(self, label: DataFrame):#输入为dataframe形式的label，index为住院号
        self.label = label
        self.image_path = '/home/user/suteng/data/CT-sagittal/segment_crop/segment/label'
        self.transform = transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((384, 384)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        print(self.label)
        label = self.label.loc[image_name, '骨质疏松']
        label = float(label)
        feature = self.label.loc[image_name]
        feature = feature.iloc[2:]
        image_name = self.image_path + str(label) + '/' + str(image_name) + '/' + str(image_name) + '.png'
        print(image_name)
        image = cv2.imread(image_name)
        image = self.transform(image)
        label = torch.tensor(label)
        feature = torch.tensor(feature)
        feature = feature.to(torch.float32)

        return image, feature, label



if __name__ == '__main__':
    flag_test_main = 1
    # id_label = '/home/user/suteng/data/CT-sagittal/segment_crop/segment_crop_id_label.xlsx'
    # feature_path = '/home/user/suteng/data/CT-sagittal/segment_crop/二分类_齐鲁省立汇总不缺失_image.xlsx'
    # data = pd.read_excel(feature_path, index_col=0, header=0, sheet_name='Sheet1')
    # # print(data.loc[17037394, 'label'])
    # dataset = Dataset_image_segment_png(data)
    # print(dataset[3])
    BATCH_SIZE = 100
    data = pd.read_excel(r'//home/user/suteng/data/CT-sagittal/segment_crop/二分类_齐鲁省立汇总不缺失_image.xlsx', index_col=0,
                         header=0,
                         sheet_name='Sheet1')  # 直接读取预处理后的数据
    features = data.iloc[:, 2:]
    labels = data.iloc[:, 0]

    x_train, x_test, y_train, y_test = \
        train_test_split(features, labels, test_size=0.2, stratify=labels)
    x_train, x_val, y_train, y_val = \
        train_test_split(x_train, y_train, test_size=0.2, stratify=y_train)

    print(y_train)
    '''loader'''

    # print(x_train.shape)
    train_dataset = Dataset_image_segment_png(y_train)
    # print(train_dataset[0])
    val_dataset = Dataset_image_segment_png(y_val)
    test_dataset = Dataset_image_segment_png(y_test)

    trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True)
    valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=BATCH_SIZE,
                                            shuffle=True)
    testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                             batch_size=BATCH_SIZE,
                                             shuffle=True)

    for i, data in enumerate(trainloader, 0):
        # get the inputs; data is a list of [inputs, labels]
        inputs_image, labels = data
        print('trainloader', i)
'''
分割好的图像及其标签的读取类
'''
import os
import cv2
import pydicom
from skimage import io
import json
import torch, torchvision
import numpy as np
import pandas as pd
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from torch.utils.data import random_split
# from image_label_process import mask_to_onehot

def imshow(img, color):
    # img = img / 2 + 0.5  # unnormalize
    # npimg = img.numpy()
    # print("img_shape:", np.shape(img))
    if color == 0:
        plt.imshow(img, cmap='gray')
    else:
        plt.imshow(img)
    plt.show()

def mask_to_onehot(mask, palette):
    """
    Converts a segmentation mask (H, W, C) to (H, W, K) where the last dim is a one
    hot encoding vector, C is usually 1 or 3, and K is the number of class.
    """
    semantic_map = []
    for colour in palette:
        equality = np.equal(mask, colour)
        class_map = np.all(equality, axis=-1)
        semantic_map.append(class_map)
    semantic_map = np.stack(semantic_map, axis=-1).astype(np.float32)
    return semantic_map

def getStat(train_data, dim):
    '''
    计算训练集的均值与标准差
    :param train_data: 自定义类Dataset(或ImageFolder即可)
    :return: (mean, std)
    '''
    print('Compute mean and variance for training data.')
    print(len(train_data))
    train_loader = torch.utils.data.DataLoader(
        train_data, batch_size=1, shuffle=False, num_workers=0,
        pin_memory=True)
    mean = torch.zeros(dim)
    std = torch.zeros(dim)
    for X, _ in train_loader:
        print(X.size())
        for d in range(dim):
            mean[d] += X[d, :, :].mean()
            std[d] += X[d, :, :].std()

    mean.div_(len(train_data))
    std.div_(len(train_data))
    return list(mean.numpy()), list(std.numpy())



'''将分割后的图像输入分类器,输入为路径'''
class Osteo_classifier_Dataset(Dataset):
    def __init__(self, image_path, label_path):
        self.image_name = os.listdir(image_path)
        self.label = pd.read_excel(label_path, header=0, index_col=0, usecols=[0, 1])
        self.image_path = image_path
        self.transform = transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((388, 388)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.image_name)

    def __getitem__(self, idx):
        image_name = self.image_name[idx]
        image_name, _ = os.path.splitext(image_name)#去除名称后缀
        label = self.label.loc[int(image_name), :]
        image = cv2.imdecode(np.fromfile(self.image_path + '/' + image_name + '.png', dtype=np.uint8), 0)
        _, image = cv2.threshold(image, 5, 255, cv2.THRESH_BINARY)
        # imshow(image, 0)
        image = self.transform(image)
        label = torch.tensor(label)
        return image, label

'''将分割后的图像输入分类器,输入为名称和标签'''
class Dataset_image(Dataset):
    def __init__(self, label):#输入为dataframe形式的label，index为住院号
        self.label = label
        self.image_path = '/home/user/suteng/osteo/data/image/segment_label'
        self.transform = transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((64, 64)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        label = self.label[image_name]
        image = cv2.imdecode(np.fromfile(self.image_path + '/' + str(image_name) + '.png', dtype=np.uint8), 0)
        _, image = cv2.threshold(image, 5, 255, cv2.THRESH_BINARY)#读取二值化后的图像
        # imshow(image, 0)
        image = self.transform(image)
        label = torch.tensor(label)
        return image, label

'''读取DICOM格式的CT图像'''
class Dataset_image_dicom(Dataset):
    def __init__(self, label):#输入为dataframe形式的label，index为住院号
        self.label = label
        self.image_path = '/home/user/suteng/osteo/data/image/segment_label'
        self.transform = transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((64, 64)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        image_name = self.label.index[idx]
        label = self.label[image_name]
        image = cv2.imdecode(np.fromfile(self.image_path + '/' + str(image_name) + '.png', dtype=np.uint8), 0)
        _, image = cv2.threshold(image, 5, 255, cv2.THRESH_BINARY)#读取二值化后的图像
        # imshow(image, 0)
        image = self.transform(image)
        label = torch.tensor(label)
        return image, label

def dcm_show(file):
    ds = pydicom.dcmread(file, force=True)
    ds.file_meta.TransferSyntaxUID = pydicom.uid.ImplicitVRLittleEndian
    ds = ds.pixel_array
    print(np.shape(ds))
    plt.figure(figsize=(10, 10))
    plt.imshow(ds, cmap=plt.cm.bone)
    plt.show()
    return

def index_get_imagemodal():
    image_path = '/home/user/suteng/osteo/data/image/segment_label'
    data_path = '/home/user/suteng/osteo/data/2_onehot.xlsx'
    # dataset = Dataset_multimodal(image_path=image_path, data_path=data_path)
    # print(dataset[1])
    image_name = os.listdir(image_path)
    data = pd.read_excel(data_path, header=0, index_col=0, sheet_name='Sheet1')
    data_index = data.index
    index = pd.DataFrame(index=data_index, columns=['complete'])
    index_complete = []
    print(index)
    # image_name, _ = os.path.splitext(image_name)

    for name in image_name:
        # name, _ = os.path.splitext(name)
        name = int(name)
        print(name)
        if name in data_index:
            index.loc[name, ['complete']] = 1
            index_complete.append(name)
        else:
            index.loc[name, ['complete']] = 0

    print('index_complete:', index_complete)
    print(len(index_complete))
    # index.to_excel('/home/user/suteng/osteo/data/不缺失多模态数据.xlsx')

    '''筛选出模态不缺失的结构化数据'''
    data = pd.read_excel(r'//home/user/suteng/data/clinical/2_onehot.xlsx', index_col=0, header=0,
                         sheet_name='Sheet1')
    data = data.loc[index_complete]
    data.to_excel(r'/home/user/suteng/data/clinical/3_modalconplete_onehot.xlsx')
    print(data.shape)
    return

if __name__ == '__main__':
    # image_train = '/home/user/suteng/osteo/data/image/segment_label'
    # label_path = '/home/user/suteng/osteo/data/image_label.xlsx'
    # transform = {'image': transforms.Compose([
    #     # transforms.ToPILImage(),
    #     transforms.ToTensor(),
    #     # transforms.Resize((572, 572)),
    # ]),
    #     'labels': transforms.Compose([
    #         # transforms.ToPILImage(),
    #         transforms.ToTensor(),
    #         transforms.Resize((388, 388)),
    #         # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
    #     ])}
    #
    # dataset = Dataset_image()
    # print(dataset[0][0].shape)
    path = '/home/user/suteng/osteo_data/21024730/1.3.12.2.1107.5.1.4.65373.30000021021423574854900230713_S1.I1.dcm'
    dcm_show(path)








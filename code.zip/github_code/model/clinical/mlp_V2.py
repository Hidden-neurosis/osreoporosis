'''
此文件为全连接层的通用模型，包括单模态和多模态的特征提取部分
'''
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F

'''结构化数据提取特征部分的组成模块，使用全连接层构成'''
class Net_fc_V2(nn.Module):

    def __init__(self,  input_size=51, layer_size=[32, 16, 8]):
        super(Net_fc_V2, self).__init__()
        self.n_classes = layer_size[-1]
        layer_size = layer_size[: -1]
        self.len_layer = len(layer_size)
        self.activate_function = nn.ReLU(inplace=True)
        self.modulelist = nn.ModuleList()
        if self.len_layer > 0:
            for i in range(len(layer_size)):
                if i == 0:
                    self.modulelist.append(nn.Linear(input_size, layer_size[0]))
                else:
                    self.modulelist.append(nn.Linear(layer_size[i - 1], layer_size[i]))
                self.modulelist.append(self.activate_function)
                self.modulelist.append(nn.BatchNorm1d(layer_size[i]))
            self.modulelist.append(nn.Linear(layer_size[-1], self.n_classes))
            self.modulelist.append(self.activate_function)
            self.modulelist.append(nn.BatchNorm1d(self.n_classes))
        if self.len_layer == 0:
            self.modulelist.append(nn.Linear(input_size, self.n_classes))
            self.modulelist.append(self.activate_function)
            self.modulelist.append(nn.BatchNorm1d(self.n_classes))
    def forward(self, x):
        for layer in self.modulelist:
            x = layer(x)
        return x

'''多模态融合模型结构化数据的特征提取部分的完整框架'''
class Net_multimodel_clinical(nn.Module):
    def __init__(self, layer: dict = None, n_classes: int = 3):#
        '''
        :param layer: 形式为字典，layer = {'b1': [], 'b2': [], 'b3': []}
        '''
        super(Net_multimodel_clinical, self).__init__()
        if layer is None:
            layer = {'b1': [8, 5], 'b2': [16, 3], 'b3': [8, 8, 2]}
        self.block1_cli = Net_fc_V2(input_size=11, layer_size=layer['b1'])#提取第一部分特征的边际表示
        self.block2_cli = Net_fc_V2(input_size=29, layer_size=layer['b2'])#提取第二部分特征的边际表示
        self.block3_cli = Net_fc_V2(input_size=layer['b1'][-1] + layer['b2'][-1], layer_size=layer['b3'])#将得到的边际表示融合
        # self.classifier = nn.Linear(layer['b3'][-1], n_classes)
    def forward(self, x):
        x1 = x[:, 0:11]
        x2 = x[:, 11:]
        x1 = self.block1_cli(x1)
        x2 = self.block2_cli(x2)
        x3 = torch.cat((x1, x2), 1)
        x3 = self.block3_cli(x3)
        # x3 = self.classifier(x3)
        return x3
    def get_output_size(self):
        a = torch.randn(3, 40)#需要根据数据修改
        out = self.forward(a)
        return out.size()

'''单一模态结构化数据的分类模型'''
class Net_singlemodel_clinical(nn.Module):
    def __init__(self, layer=None,
                 n_classes: int = 3):
        super(Net_singlemodel_clinical, self).__init__()
        if layer is None:
            layer = {'b1': [8, 5], 'b2': [16, 3], 'b3': [8, 8, 2]}
        self.block1 = Net_fc_V2(input_size=11, layer_size=layer['b1'])#提取第一部分特征的边际表示
        self.block2 = Net_fc_V2(input_size=29, layer_size=layer['b2'])#提取第二部分特征的边际表示
        self.block3 = Net_fc_V2(input_size=layer['b1'][-1] + layer['b2'][-1], layer_size=layer['b3'])#将得到的边际表示融合
        self.classifier = nn.Linear(layer['b3'][-1], n_classes)

    def forward(self, x):
        x1 = x[:, 0:11]
        x2 = x[:, 11:]
        x1 = self.block1(x1)
        x2 = self.block2(x2)
        x3 = torch.cat((x1, x2), 1)
        x3 = self.block3(x3)
        x3 = self.classifier(x3)
        # x3 = torch.nn.functional.softmax(self.classifier(x3))
        return x3

'''用于存储蒸馏数据的单一模态结构化数据的分类模型'''
class Net_singlemodel_distillclinical(nn.Module):
    def __init__(self, n_classes):
        super(Net_singlemodel_distillclinical, self).__init__()
        self.fusion_layersize = [8, 8]#数据融合后的全连接层尺寸
        self.block1 = Net_fc(input_size=11, output_size=5, layer_size=[8])#提取第一部分特征的边际表示
        self.block2 = Net_fc(input_size=29, output_size=3, layer_size=[16])#提取第二部分特征的边际表示
        self.block3_1 = nn.Linear(8, self.fusion_layersize[0])
        self.block3_2 = nn.Linear(self.fusion_layersize[0], self.fusion_layersize[1])
        self.block3_n = nn.Linear(self.fusion_layersize[1], n_classes)
        self.activate_function = nn.ReLU()
        self.batchnorm1 = nn.BatchNorm1d(self.fusion_layersize[0])
        self.batchnorm2 = nn.BatchNorm1d(self.fusion_layersize[1])
    def forward(self, x):
        x1 = x[:, 0:11]
        x2 = x[:, 11:]
        x1 = self.block1(x1)
        x2 = self.block2(x2)
        x3 = torch.cat((x1, x2), 1)
        x3 = self.block3_1(x3)
        x3 = self.activate_function(self.batchnorm1(x3))
        feature0 = copy.deepcopy(x3)
        x3 = self.block3_2(x3)
        x3 = self.activate_function(self.batchnorm2(x3))

        x3 = self.block3_n(x3)
        return feature0#只返回想要的中间层特征输出

if __name__ == '__main__':
    a = torch.randn(4, 40)
    b = torch.randn(4, 30)
    model = Net_singlemodel_clinical(layer = {'b1': [3, 5], 'b2': [16, 3], 'b3': [8, 8, 5]}, n_classes=3)
    outputs = model(a)
    print(outputs)
    print(outputs.size())
    print(list(model.children()))




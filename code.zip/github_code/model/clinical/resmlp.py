'''
与图像处理的ResMLP不同，此MLP只是加入了skip connection
'''
import torch
import torch.nn as nn
import torch.nn.functional as F
from osteoV2.model.clinical.mlp_V2 import Net_fc_V2
class SmallBlock(nn.Module):
    def __init__(self, inputsize, outputsize, relu=True):
        super(SmallBlock, self).__init__()
        self.left = nn.Sequential(
            nn.Linear(inputsize, outputsize),
            nn.BatchNorm1d(outputsize),
        )
        if relu:
            self.left.append(nn.ReLU(inplace=True))

    def forward(self, x):
        out = self.left(x)
        return out

class Block(nn.Module):
    def __init__(self, insize, outsize, layersize=None, last_relu=False):
        super(Block, self).__init__()
        self.layer = nn.Sequential()
        if layersize is not None:
            for i in range(len(layersize)+1):
                if i == 0:
                    self.layer.append(SmallBlock(insize, layersize[0]))
                elif i == len(layersize):
                    self.layer.append(SmallBlock(layersize[-1], outsize, last_relu))
                else:
                    self.layer.append(SmallBlock(layersize[i-1], layersize[i]))
        else:
            self.layer.append(SmallBlock(insize, outsize, last_relu))
    def forward(self, x):
        for layer in self.layer:
            x = layer(x)
        return x


class Net_multimodal_cli_res(nn.Module):
    def __init__(self, layer=None):#
        '''
        :param layer: 形式为字典或者列表，layer = {'b1': [], 'b2': [], 'b3': []}
                                    layer = 【1，2，3，4】
        '''
        super(Net_multimodal_cli_res, self).__init__()
        if layer is None:
            layer = {'b1': [8, 5], 'b2': [16, 3], 'b3': [8, 8, 2]}

        if 'dict' in str(type(layer)):
            self.mode = 'dict'

            hids = [0, 0, 0]
            for i, bi in enumerate(['b1', 'b2', 'b3']):
                if len(layer[bi]) > 1:
                    hids[i] = layer[bi][:-1]
                else:
                    hids[i] = None

            self.block1_cli = Block(11, layer['b1'][-1], hids[0])#提取第一部分特征的边际表示
            self.block2_cli = Block(29, layer['b2'][-1], hids[1])#提取第二部分特征的边际表示
            self.block3_cli = Block(layer['b1'][-1] + layer['b2'][-1],
                                    layer['b3'][-1], hids[2], last_relu=False)#将得到的边际表示融合
            self.shortcut_cli = nn.Sequential(
                nn.Linear(40, layer['b3'][-1]),
                nn.BatchNorm1d(layer['b3'][-1])
            )
        elif 'list' in str(type(layer)):
            self.mode = 'list'
            if len(layer) == 0:
                self.mode = 'list_None'
            elif len(layer) >= 2:
                self.block_cli = Block(40, layer[-1], layer[:-1], last_relu=False)
            else:
                self.block_cli = Block(40, layer[0], last_relu=False)
        self.activate_f = nn.ReLU(inplace=True)
    def forward(self, x):
        x1 = x[:, 0:11]
        x2 = x[:, 11:]
        if self.mode == 'dict':
            x1 = self.block1_cli(x1)
            x2 = self.block2_cli(x2)
            x3 = torch.cat((x1, x2), 1)
            x3 = self.block3_cli(x3)
            x3 += self.shortcut_cli(x)
        elif self.mode == 'list':
            x3 = self.block_cli(x)
        elif self.mode == 'list_None':#此时不进行特征提取，直接输入分类器
            return x
        else:
            print("clinical网络输入错误")
            return
        x3 = self.activate_f(x3)
        return x3

    def get_output_size(self):
        a = torch.randn(3, 40)#需要根据数据修改
        out = self.forward(a)
        return out.size()


class Net_multimodal_cli(Net_multimodal_cli_res):
    '''
    不采用渐进融合，直接输入MLP提取特征
    '''
    def __init__(self, layer):
        super(Net_multimodal_cli, self).__init__(layer)
        self.block_cli = nn.Sequential

if __name__ == '__main__':
    a = torch.randn(4, 40)
    b = torch.randn(4, 30)
    # model = Net_multimodal_cli_res(layer={'b1': [3, 5], 'b2': [16, 3], 'b3': [8, 8, 5]})
    # outputs = model(a)
    # print(outputs)
    # print(outputs.size())

    # model = Block(4, 3, last_relu=True)
    # print(model(torch.randn(16, 4)).size())
    # print(list(model.children()))
    # model = Block(4, 3, last_relu=False)
    # print(model(torch.randn(16, 4)).size())
    # print(list(model.children()))

    # layer = {'b1': [3, 5], 'b2': [16, 3], 'b3': [8, 8, 5]}
    # model = Net_multimodal_cli_res(layer)
    # print('dict' in str(type(layer)))
    layer1 = [8]
    model = Net_multimodal_cli_res(layer1)
    print(layer1)
    print('list' in str(type(layer1)))

    layer1 = [8]
    model = Net_multimodal_cli_res(layer1)
    print(model(a).size())
import torch, torchvision
import numpy as np
import pandas as pd
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from torch.utils.data import random_split


class Dataset_clinical(Dataset):
    def __init__(self, feature, label, root_dir=None, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.feature = feature
        self.label = label

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        label = self.label.iloc[idx]
        feature = self.feature.iloc[idx, :]
        # feature = np.array(feature, dtype=float).reshape(1, 1, len(feature))
        feature = np.array(feature, dtype=float).reshape(len(feature))
        feature = torch.tensor(feature, dtype=torch.float)
        label = torch.tensor(label, dtype=torch.long)
        return feature, label

if __name__ == '__main__':
    root_dir = '/home/user/suteng/data/1_去除极端值.xlsx'

    dataset = Dataset_clinical(root_dir)
    # print('len:', len(dataset))
    print('feature:', dataset[0][0])
    print('label:', dataset[0][1])
    # data = pd.read_excel('/home/user/suteng/data/不缺失的病人描述.xlsx', header=0, index_col=0, sheet_name='Sheet1')
    # print(data.loc['mean'][1:])
    # print(data.loc['std'][1:])

    '''归一化后写入表格'''
    # data = pd.read_excel(root_dir, header=0, index_col='住院号', sheet_name='all_notmissing')
    # # data_describe = pd.read_excel('/home/user/suteng/data/不缺失的病人描述.xlsx', header=0, index_col=0, sheet_name='Sheet1')
    # data_describe = data.describe().iloc[:, 1:]
    # print(data_describe)
    # max = data_describe.loc['max']
    # min = data_describe.loc['min']
    # data.iloc[:, 1:] = (data.iloc[:, 1:] - min) / (max - min)
    # print(data)
    # data.to_excel('/home/user/suteng/data/归一化后.xlsx')


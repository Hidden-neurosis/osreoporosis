import time
import pandas as pd

def get_excel_name(config: dict, transform: dict=None):
    name = {
        "epoch_num": 'epo',
        "step_size": 'ste',
        "lr": 'lr',
        "batch_size": 'bat',
        "layer": 'lay',

    }
    end_time = time.localtime()
    end_time = time.strftime('%Y-%m-%d %H.%M.%S', end_time)

    excel_name = end_time + '{'
    # for key in transform.keys():
    #     excel_name += (key + str(transform[key]) + ' ')
    # excel_name = excel_name + '}'
    #
    # excel_name = excel_name + '{'
    for key in config.keys():
        excel_name += (name[key] + str(config[key]) + ' ')
    excel_name = excel_name + '}'

    excel_name = excel_name.replace(':', '')
    return excel_name

def simple_config_name(keys):
    config = {
        "epoch_num": 'epo',
        "step_size": 'ste',
        "lr": 'lr',
        "batch_size": 'bat',
        "image_flag": 'imf',  #'segment', 'crop'
        "image_size": 'ims',
        "resnet18_channels": 'res',
        'mlp': 'mlp',
        'classifier': 'cla',  # 分类器的网络结构
        'freeeze': 'fre',  # 'img', 'cli', 'both', 'not' 冻结特征提取标志位
        'distill': 'dis',  # 'cli', 'not' 蒸馏标志位
        'transfer': 'tra',  # 'cli', 'not'迁移标志位
    }
if __name__ == '__main__':
    config = {
        "epoch_num": 90,
        "step_size": 30,
        "lr": 0.001,
        "batch_size": 5,
        "layer": [2],
    }
    transform_config = {
        'rot': (-25, 25),  # 旋转角度
        'col': (0.05, 0.05),
        'flip': 'h-v',
    }
    # print(transform_config.keys())
    name = get_excel_name(config)
    print(name)
    # data = pd.read_excel(r'/home/user/suteng/osteo_results/image/8.21_0.xlsx', index_col=0,
    #                      header=0,
    #                      sheet_name='Sheet1')
    # data.loc['mean'] = data.mean()
    # print(data)

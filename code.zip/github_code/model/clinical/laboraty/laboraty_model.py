'''
此文件为全连接层的通用模型，包括单模态和多模态的特征提取部分
'''
import copy
import torch
import torch.nn as nn
import torch.nn.functional as F

'''结构化数据提取特征部分的组成模块，使用全连接层构成'''
class Net_fc_V2(nn.Module):

    def __init__(self,  input_size=51, layer_size=[32, 16, 8], n_classes=3):
        super(Net_fc_V2, self).__init__()
        self.n_classes = n_classes
        self.len_layer = len(layer_size)
        self.activate_function = nn.ReLU()
        self.modulelist = nn.ModuleList()
        if self.len_layer > 0:
            for i in range(len(layer_size)):
                if i == 0:
                    self.modulelist.append(nn.Linear(input_size, layer_size[0]))
                else:
                    self.modulelist.append(nn.Linear(layer_size[i - 1], layer_size[i]))
                self.modulelist.append(nn.BatchNorm1d(layer_size[i]))
                self.modulelist.append(self.activate_function)
            self.modulelist.append(nn.Linear(layer_size[-1], self.n_classes))
            self.modulelist.append(nn.BatchNorm1d(self.n_classes))
            self.modulelist.append(self.activate_function)
        if self.len_layer == 0:
            self.modulelist.append(nn.Linear(input_size, self.n_classes))
            self.modulelist.append(nn.BatchNorm1d(self.n_classes))
            self.modulelist.append(self.activate_function)
    def forward(self, x):
        for layer in self.modulelist:
            x = layer(x)
        return x


if __name__ == '__main__':
    a = torch.randn(4, 40)
    b = torch.randn(4, 30)
    model = Net_fc_V2(30, [5, 4], 3)
    outputs = model(b)
    print(outputs)
    print(outputs.size())
    print(list(model.children()))




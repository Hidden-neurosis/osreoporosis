'''

'''
import os
import copy
import torch
import torch.nn as nn
import pandas as pd
import numpy as np
import random
import torch.backends.cudnn
from torch.utils.tensorboard import SummaryWriter
from osteoV2.model.clinical.mlp import Net_singlemodel_distillclinical, Net_multimodel_clinical
from torch.utils.data import DataLoader
from torch.utils.data import Dataset

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def get_feature():
    '''
    获取教师网络中间层的输出特征
    读取训练好的模型，将所有数据放入一个batchsize输入，执行前向过程，存储输出数据
    :return:
    '''
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        device = "cuda:0"
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    print('device:', device)


    data = pd.read_excel(r'//home/user/suteng/data/clinical/2_onehot.xlsx', index_col=0, header=0,
                         sheet_name='二分类')  # 直接读取预处理后的数据
    features = data.iloc[:, 4:]
    labels = data.iloc[:, 3]
    BATCH_SIZE = len(labels)
    max = features.max()
    min = features.min()
    '''归一化'''
    features = (features - min) / (max - min)
    print(features.describe())

    dataset = Dataset_clinical(features, labels)
    dataloader = torch.utils.data.DataLoader(dataset=dataset,
                                              batch_size=BATCH_SIZE,
                                              shuffle=True)
    model = Net_singlemodel_distillclinical(n_classes=2)
    # model.load_state_dict(torch.load('../model_save/7.4_微调.pth'))
    model.to(device)
    # model = torch.load()
    for data in dataloader:
        with torch.no_grad():
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)#已更改该模型输出为中间特征输出
            print(outputs.size())
            labels = torch.unsqueeze(labels, 1)
            data_distill = torch.concat((labels, outputs, inputs), 1)
    print(data_distill.size())
    data_distill = data_distill.cpu()
    data_distill = np.array(data_distill)
    data_distill = pd.DataFrame(data_distill)
    print(data_distill)
    data_distill.to_excel('/home/user/suteng/data/distill/8.6test.xlsx')

class Dataset_clinical(Dataset):
    def __init__(self, feature, label, root_dir=None, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.feature = feature
        self.label = label

    def __len__(self):
        return len(self.label)

    def __getitem__(self, idx):
        label = self.label.iloc[idx]
        feature = self.feature.iloc[idx, :]
        # feature = np.array(feature, dtype=float).reshape(1, 1, len(feature))
        feature = np.array(feature, dtype=float).reshape(len(feature))
        label = np.array(label, dtype=float).reshape(len(label))
        feature = torch.tensor(feature, dtype=torch.float)
        label = torch.tensor(label, dtype=torch.float)
        return feature, label



if __name__ == '__main__':
    get_feature()

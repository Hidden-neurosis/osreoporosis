import os
import cv2
import copy
import torch
import torch.nn as nn
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import random_split
import numpy as np
import pandas as pd
import random
import torch.backends.cudnn
import matplotlib.pyplot as plt
from torch.utils.tensorboard import SummaryWriter
from clinical_dataset import Dataset_clinical
from mlp import Net_fc, Net_singlemodel_clinical

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def train(config, model, device, model_save_dir, checkpoint_dir=None, data_dir=None):
    epoch_num = config["epoch_num"]
    lr = config["lr"]
    step_size = config["step_size"]
    criterion = nn.CrossEntropyLoss()
    # criterion = nn.BCELoss()
    # criterion = Weighted_Cross_Entropy_Loss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    # optimizer = optim.Adam(model.parameters(), lr=lr)
    #step_size为几个epoch进行衰减，gamma为衰减系数
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)

    '''checkpoint可以进行断点继续训练，保存模型时要将很多必要的状态都保存，此处是进行断点数据的读取'''
    if checkpoint_dir:
        model_state, optimizer_state = torch.load(
            os.path.join(checkpoint_dir, "checkpoint"))
        # model_state, optimizer_state = torch.load(checkpoint_dir)
        model.load_state_dict(model_state)
        optimizer.load_state_dict(optimizer_state)

    flag_imageval_print = False#是否显示验证集图像
    best_acc = 0.0#保存当前最好的准确率
    best_model = model
    best_model_wts = copy.deepcopy(model.state_dict())
    mini_batches_num = 5#训练时每过mini_batches_num个batchsize打印loss
    for epoch in range(epoch_num):  # loop over the dataset multiple times
        running_loss = 0.0# 保存每个mini_batches的loss之和，用于打印，打印后清空
        train_total = 0# 保存每个epoch的总的个数
        train_correct = 0# 保存每个epoch的正确的个数
        train_loss = 0.0
        train_i = 0
        for i, data in enumerate(trainloader, 0):
            # get the inputs; data is a list of [inputs, labels]
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()

            outputs = model(inputs)#[N, C, H, W]
            # imshow_tensor(labels[0, 0, :, :])
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            train_loss += loss.item()
            train_i += 1
            _, predicted = torch.max(outputs.data, 1)#将多分类的onehot编码转换成单个类别数字编码
            # _, labels = torch.max(labels, 1)
            # 每个epoch准确率
            train_total += labels.size(0)
            train_correct += ((predicted == labels).sum().item())

            if i % mini_batches_num == (mini_batches_num - 1):  # print every mini-batches-num
                print("Train mini-batches [%d, %5d] loss: %.3f" % (epoch + 1, i + 1,
                                                running_loss / mini_batches_num))
                running_loss = 0.0
        train_loss = train_loss / train_i
        train_acc = train_correct / train_total
        print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" % (epoch + 1, epoch_num, train_loss, train_acc))
        scheduler.step()


        # Validation loss
        val_loss = 0.0
        val_steps = 0
        val_total = 0
        val_correct = 0
        val_i = 0
        for i, data in enumerate(valloader, 0):
            with torch.no_grad():
                inputs, labels = data
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                #loss
                # print('val outputs:\n', outputs)
                # print('val labels:\n', labels)
                loss = criterion(outputs, labels)
                val_loss += loss.cpu().numpy()
                val_steps += 1
                val_i += 1
                running_loss += loss.item()

                # 输出最大概率的类，predicted为max对应的index
                _, predicted = torch.max(outputs.data, 1)
                # print('val predicted:\n', predicted)
                # 准确率打印
                val_total += labels.size(0)
                val_correct += ((predicted == labels).sum().item())

                # print("Valdition [%d, %5d] loss: %.3f" % (epoch + 1, i + 1, val_loss))
                # print('Valdition accuracy:', val_correct / val_total)
                # val_loss = 0.0
        val_loss = val_loss / val_i
        val_acc = val_correct / val_total
        print('Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' % (epoch + 1, epoch_num, val_loss, val_acc))

        # 利用验证集找出最好模型
        if val_acc > best_acc:
            best_acc = val_acc
            best_model_wts = copy.deepcopy(model.state_dict())
            best_model = copy.deepcopy(model)
            print('better model getted')

        #将数据传入tensorboard
        if flag_tensorboard:
            writer_train.add_scalar('loss', train_loss, epoch)
            writer_train.add_scalar('accuracy', train_acc, epoch)
            writer_val.add_scalar('loss', val_loss, epoch)
            writer_val.add_scalar('accuracy', val_acc, epoch)
    if flag_tensorboard:
        writer_train.flush()
        writer_val.flush()
    model.load_state_dict(best_model_wts)
    if flag_model_save:
        torch.save(best_model.state_dict(), model_save_dir)  # 只保存模型参数
    print('The Best Valdition |  accuracy: %.3f |' % best_acc)
    return model

def test(model, device, testloader):

    correct = 0
    total = 0
    with torch.no_grad():
        for i, data in enumerate(testloader, 0):
            images, labels = data
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            # print('testloader outputs.size():', outputs.size())
            _, predicted = torch.max(outputs.data, 1)
            # print('testloader predicted.size():', predicted.size())
            # print('testloader label.size():', labels.size())
            total += labels.size(0)
            # print(labels.size(0))
            # imshow_tensor(predicted)
            correct += ((predicted == labels).sum().item())
            # print('test image total num:', total)

    print('The Test Accuracy:', correct / total)
    return correct / total

if __name__ == '__main__':
    '''==================参数设置======================='''
    flag_tensorboard = True
    flag_model_load = False
    flag_model_save = False
    config = {
        "epoch_num": 500,
        "step_size": 100,
        "lr": 0.01,
        "batch_size": 256,
    }
    BATCH_SIZE = config['batch_size']
    seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546,
             8345, 28934, 209345, 599484, 30994, 9394, 92389, 39494, 394903, 1349]
    seeds = [666]

    # torch.backends.cudnn.enabled = False
    os.environ[
        "CUDA_VISIBLE_DEVICES"] = '2'  # CUDA_VISIBLE_DEVICES限制一下使用的GPU。比如有0,1,2,3号GPU，CUDA_VISIBLE_DEVICES=2,3，则当前进程的可见GPU只有物理上的2、3号GPU，此时它们的编号也对应变成了0、1，即cuda:0对应2号GPU，cuda:1对应3号GPU
    '''================================================'''


    '''==================device======================='''
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        device = "cuda:0"
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    print('device:', device)
    '''================================================'''


    '''==================读取数据======================='''
    data = pd.read_excel(r'//home/user/suteng/data/clinical/5_去除极端值.xlsx', index_col=0, header=0,
                         sheet_name='feature_onehot')  # 直接读取预处理后的数据
    features = data.iloc[:, 1:]
    labels = data.iloc[:, 0]
    # print('features:\n', features)
    # print('labels:\n', labels)

    accuracy_test_average = 0#
    for seed in seeds:
        setup_seed(seed)
        print('-----seed=%d-----' % seed)
        x_train, x_test, y_train, y_test = \
            train_test_split(features, labels, test_size=0.2, stratify=labels)
        max = x_train.max()
        min = x_train.min()
        '''归一化'''
        x_train = (x_train - min) / (max - min)
        x_test = (x_test - min) / (max - min)
        print(x_train.describe())
        print(x_test.describe())
        # '''标准化'''
        # x_train = (x_train - x_train.mean()) / x_train.std()
        # x_test = (x_test - x_test.mean()) / (x_test.max() - x_test.min())
        # print(x_train.describe())

        '''loader'''
        x_train, x_val, y_train, y_val = \
            train_test_split(x_train, y_train, test_size=0.2, stratify=y_train)
        # print(x_train.shape)
        train_dataset = Dataset_clinical(x_train, y_train)
        val_dataset = Dataset_clinical(x_val, y_val)
        test_dataset = Dataset_clinical(x_test, y_test)

        trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                                   batch_size=BATCH_SIZE,
                                                   shuffle=True)
        valloader = torch.utils.data.DataLoader(dataset=val_dataset,
                                                   batch_size=BATCH_SIZE,
                                                   shuffle=True)
        testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                                  batch_size=BATCH_SIZE,
                                                  shuffle=True)
        # print('get loader')
        '''================================================'''


        '''==================训练======================='''
        if flag_tensorboard:
            writer_train = SummaryWriter('./runs/train/')
            writer_val = SummaryWriter('./runs/val/')

        # model = Net_fc(output_size=3, layer_size=[32, 32, 16, 8], input_size=51)
        model = Net_singlemodel_clinical()
        if flag_model_load:
            model.load_state_dict(torch.load('../model_save/7.4_微调.pth'))
        model.to(device)
        model = train(config, model, device, model_save_dir='../model_save/7.4_微调_4.pth')
        accuracy_test_average += test(model, device, testloader)
        if flag_tensorboard:
            writer_train.close()
            writer_val.close()
        print('---------------' + ('-'*len(str(seed))))
    print('The Test Average Accuracy:', accuracy_test_average / len(seeds))

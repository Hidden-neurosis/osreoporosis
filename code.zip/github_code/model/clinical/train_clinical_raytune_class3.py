import os
from ray import tune
import cv2
import copy
import torch
import torch.nn as nn
import torch.optim as optim
import torch.backends.cudnn
from torch.utils.tensorboard import SummaryWriter
from osteoV2.model.clinical.train_clinical_raytune_class3_p2 import *
from osteoV2.model.clinical.excel_name import *
from osteoV2.model.clinical.mlp_V2 import Net_singlemodel_clinical
import matplotlib.pyplot as plt

global trainloader, valloader, writer_train, writer_val


def train(config, model, device, model_save_dir, checkpoint_dir=None, data_dir=None):
    global trainloader, valloader, writer_train, writer_val
    epoch_num = config["epoch_num"]
    lr = config["lr"]
    step_size = config["step_size"]
    label = {#存放真实标签和预测标签
        'train': {'real': [], 'predict': []},
        'val': {'real': [], 'predict': []}
    }
    result = {  # 用于存放最后的各种指标结果
        'train': {'accuracy': 0.0, 'auc': 0.0},
        'val': {'accuracy': 0.0},
        'test': {'accuracy': 0.0, 'auc': 0.0},
    }
    plot = {
        'train': {'loss': [], 'acc': []},
        'val': {'loss': [], 'acc': []}
    }
    criterion = nn.CrossEntropyLoss()
    # criterion = nn.BCELoss()
    # criterion = Weighted_Cross_Entropy_Loss()
    optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    # optimizer = optim.Adam(model.parameters(), lr=lr)
    #step_size为几个epoch进行衰减，gamma为衰减系数
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size, gamma=0.1, last_epoch=-1)

    '''checkpoint可以进行断点继续训练，保存模型时要将很多必要的状态都保存，此处是进行断点数据的读取'''
    if checkpoint_dir:
        model_state, optimizer_state = torch.load(
            os.path.join(checkpoint_dir, "checkpoint"))
        # model_state, optimizer_state = torch.load(checkpoint_dir)
        model.load_state_dict(model_state)
        optimizer.load_state_dict(optimizer_state)

    flag_imageval_print = False#是否显示验证集图像
    best_acc = 0.0#保存当前最好的准确率
    best_model = model
    best_model_wts = copy.deepcopy(model.state_dict())
    mini_batches_num = 5#训练时每过mini_batches_num个batchsize打印loss
    for epoch in range(epoch_num):  # loop over the dataset multiple times
        running_loss = 0.0# 保存每个mini_batches的loss之和，用于打印，打印后清空
        train_total = 0# 保存每个epoch的总的个数
        train_correct = 0# 保存每个epoch的正确的个数
        train_loss = 0.0
        train_i = 0
        for i, data in enumerate(trainloader, 0):
            # get the inputs; data is a list of [inputs, labels]
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()

            outputs = model(inputs)#[N, C, H, W]
            # imshow_tensor(labels[0, 0, :, :])
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            train_loss += loss.item()
            train_i += 1
            _, predicted = torch.max(outputs.data, 1)#将多分类的onehot编码转换成单个类别数字编码
            # _, labels = torch.max(labels, 1)
            # 每个epoch准确率
            train_total += labels.size(0)
            train_correct += ((predicted == labels).sum().item())

            # 结果保存，用于计算各种指标
            labels = labels.cpu()
            outputs = F.softmax(outputs, dim=1)
            outputs = outputs.cpu()
            labels = labels.detach().numpy()
            outputs = outputs.detach().numpy()
            label['train']['real'].extend(labels)
            label['train']['predict'].extend(outputs)

            if i % mini_batches_num == (mini_batches_num - 1):  # print every mini-batches-num
                # print("Train mini-batches [%d, %5d] loss: %.3f" % (epoch + 1, i + 1,
                #                                 running_loss / mini_batches_num))
                running_loss = 0.0
        train_loss = train_loss / train_i
        train_acc = train_correct / train_total

        plot['train']['loss'].append(train_loss)
        plot['train']['acc'].append(train_acc)

        if flag_print:
            print("Epoch [%d / %d] Train     | loss: %.3f | accuracy: %.3f |" % (epoch + 1, epoch_num, train_loss, train_acc))
        scheduler.step()

        # Validation loss
        val_loss = 0.0
        val_steps = 0
        val_total = 0
        val_correct = 0
        val_i = 0
        for i, data in enumerate(valloader, 0):
            with torch.no_grad():
                inputs, labels = data
                inputs, labels = inputs.to(device), labels.to(
                    device)
                # print('inputs_image.dtype, labels.dtype:', inputs_image.dtype, labels.dtype)
                outputs = model(inputs)
                #loss
                # print('val outputs:\n', outputs)
                # print('val labels:\n', labels)
                loss = criterion(outputs, labels)
                val_loss += loss.cpu().numpy()
                val_steps += 1
                val_i += 1
                running_loss += loss.item()

                # 输出最大概率的类，predicted为max对应的index
                _, predicted = torch.max(outputs.data, 1)
                # print('val predicted:\n', predicted)
                # 准确率打印
                val_total += labels.size(0)
                val_correct += ((predicted == labels).sum().item())

                # 结果保存，用于计算各种指标
                labels = labels.cpu()
                outputs = F.softmax(outputs, dim=1)
                outputs = outputs.cpu()
                labels = labels.detach().numpy()
                outputs = outputs.detach().numpy()
                label['val']['real'].extend(labels)
                label['val']['predict'].extend(outputs)

        val_loss = val_loss / val_i
        val_acc = val_correct / val_total
        plot['val']['loss'].append(val_loss)
        plot['val']['acc'].append(val_acc)
        if flag_print:
            print('Epoch [%d / %d] Valdition | loss: %.3f | accuracy: %.3f |' % (epoch + 1, epoch_num, val_loss, val_acc))

        # 利用验证集找出最好模型
        if val_acc > best_acc:
            best_acc = val_acc
            best_model_wts = copy.deepcopy(model.state_dict())
            best_model = copy.deepcopy(model)
            # print('better model getted')
            result['train']['accuracy'] = train_acc
            result['val']['accuracy'] = val_acc

            # 将数据传入tensorboard
        if flag_tensorboard:
            writer_train.add_scalar('loss', train_loss, epoch)
            writer_train.add_scalar('accuracy', train_acc, epoch)
            writer_val.add_scalar('loss', val_loss, epoch)
            writer_val.add_scalar('accuracy', val_acc, epoch)

    if flag_tensorboard:
        writer_train.flush()
        writer_val.flush()
    model.load_state_dict(best_model_wts)
    if flag_model_save:
        torch.save(best_model.state_dict(), model_save_dir)  # 只保存模型参数
    if flag_print:
        print('The Best Valdition |  accuracy: %.3f |' % best_acc)

    return model, result, label, plot

def test(model, device, testloader):
    global trainloader, valloader, writer_train, writer_val
    correct = 0
    total = 0
    label = {'real': [], 'predict': []}
    with torch.no_grad():
        for i, data in enumerate(testloader, 0):
            inputs, labels = data
            inputs, labels = inputs.to(device), labels.to(
                device)
            outputs = model(inputs)
            # print('testloader outputs.size():', outputs.size())
            _, predicted = torch.max(outputs.data, 1)
            # print('testloader predicted.size():', predicted.size())
            # print('testloader label.size():', labels.size())
            total += labels.size(0)
            # print(labels.size(0))
            # imshow_tensor(predicted)
            correct += ((predicted == labels).sum().item())
            # print('test image total num:', total)

            # 保存结果，计算指标
            outputs = F.softmax(outputs, dim=1)
            labels = labels.cpu()
            outputs = outputs.cpu()
            labels = labels.detach().numpy()
            outputs = outputs.detach().numpy()
            label['real'].extend(labels)
            label['predict'].extend(outputs)
    if flag_print:
        print('The Test Accuracy:', correct / total)
    return correct / total, label

def main(config):
    global config_i
    config_i = config_i + 1
    config["epoch_num"] = 3 * config["step_size"]

    '''==================参数设置======================='''
    global trainloader, valloader, writer_train, writer_val, seeds

    excel_name = get_excel_name(config)

    '''================================================'''

    '''==================device======================='''
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        # device = "cuda:0"
        device = torch.device('cuda')
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    print('device:', device)

    '''================================================'''

    '''==================读取数据======================='''
    data = pd.read_excel(r'/home/user/suteng/osteo_data/EXCEL/class3/class3_clinical.xlsx', index_col=0,
                         header=0,
                         sheet_name='Qilu')  # 直接读取预处理后的数据
    features = data.iloc[:, 4:]
    labels = data.iloc[:, 0]
    # print('labels\n', labels, '\nfeatures:\n', features)
    accuracy_test_average = 0  #

    result = pd.DataFrame(index=range(len(seeds)),
                          columns=['seed', 'accuracy_train', 'accuracy_val', 'accuracy_test', 'auc_train', 'auc_test'])
    for i, seed in zip(range(len(seeds)), seeds):
        setup_seed(seed)
        if flag_print:
            print('-----seed=%d-----' % seed)
        trainloader, valloader, testloader = get_loader(config, features, labels, seed=seed)
        '''================================================'''

        '''==================训练======================='''
        if flag_tensorboard:
            writer_train = SummaryWriter('/home/user/suteng/osteo/runs/image/train/')
            writer_val = SummaryWriter('/home/user/suteng/osteo/runs/image/val/')


        model = Net_singlemodel_clinical(layer=config["layer"], n_classes=3)
        # if flag_model_load:
        #     model.load_state_dict(torch.load(model_load))
        model.to(device)
        model, result_metric, label_train, plot = train(config, model, device, model_save_dir=model_save)
        result_metric['test']['accuracy'], label_test = test(model, device, testloader)

        path_plot = '/home/user/suteng/osteo_results/class3/plot/clinical/9.27/' + str(config_i)
        if not os.path.exists(path_plot):
            os.mkdir(path_plot)
        x = range(config["epoch_num"])
        plt.plot(x, plot['train']['loss'], x, plot['val']['loss'])
        plt.savefig(os.path.join(path_plot, str(seed) + 'loss.png'))
        plt.close()
        plt.plot(x, plot['train']['acc'], x, plot['val']['acc'])
        # plt.show()
        plt.savefig(os.path.join(path_plot, str(seed) + 'loss.png'))
        accuracy_test_average += result_metric['test']['accuracy']
        if flag_tensorboard:
            writer_train.close()
            writer_val.close()

        # AUC指标计算
        result = auc_compute(result, result_metric, label_train, label_test, seed, i, n_class=3)
        if flag_print:
            print('---------------' + ('-' * len(str(seed))))
    result.loc['mean'] = result.mean()
    print(result)

    path = r'/home/user/suteng/osteo_results/class3/image/9.24'
    if not os.path.exists(path):
        os.mkdir(path)
    result.to_excel(os.path.join(path, excel_name + '.xlsx'))
    if flag_print:
        print('The Test Average Accuracy:', accuracy_test_average / len(seeds))
    if flag_tune:
        tune.report(
            acc_train=result.loc['mean', 'accuracy_train'],
            acc_val=result.loc['mean', 'accuracy_val'],
            acc_test=result.loc['mean', 'accuracy_test'],
            auc_train=result.loc['mean', 'auc_train'],
            auc_test=result.loc['mean', 'auc_test'],
                    )
    return

if __name__ == '__main__':
    global trainloader, valloader, writer_train, writer_val, seeds, config_i
    config_i = 0
    torch.backends.cudnn.enabled = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    os.environ["CUDA_VISIBLE_DEVICES"] = '1'

    #设定默认数据类型为float16，以减小显存的使用
    # torch.set_default_tensor_type(torch.cuda.HalfTensor)
    flag_tune = True
    flag_print = False
    flag_tensorboard = False
    flag_model_load = False
    model_load = '/home/user/suteng/osteo/osteoV2/model_save/multimodal/'
    flag_model_save = True
    model_save = '/home/user/suteng/osteo/osteoV2/model_save/multimodal/'
    seeds = [6, 66, 666, 324, 1000, 2000, 3045, 2434, 35466, 34546]
    # seeds = seeds[:1]
    config = {
        "epoch_num": 280,
        "step_size": 70, #tune.grid_search([70]),
        "lr": 0.001,
        "batch_size": tune.grid_search([16, 32]),
        "layer": tune.grid_search([
            {'b1': [16, 16], 'b2': [16, 16], 'b3': [32]},
            {'b1': [8, 8], 'b2': [8, 8], 'b3': [16]},
                                  ]),
    }
    # config = {
    #     "epoch_num": 280,
    #     "step_size": 1,
    #     "lr": 0.001,
    #     "batch_size": 128,
    #     "layer":  {'b1': [16, 16], 'b2': [16, 16], 'b3': [32]},
    # }


    # main(config)
    absolute_path = '/home/user/suteng/osteo'
    result = tune.run(
        main,
        resources_per_trial={"cpu": 28, "gpu": 1},  # 运行时的资源限制
        config=config,
        local_dir=absolute_path + '/ray_results',  # 运行以及保存结果的位置
        # num_samples=3,  # random search时的采样次数
    )






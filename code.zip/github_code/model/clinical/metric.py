'''
下载训练好的模型，用于计算指标,不需要各种训练参数
'''
import os
import torch
import numpy as np
import pandas as pd
import random
import torch.backends.cudnn
import torch.nn as nn
from sklearn.model_selection import train_test_split
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score, precision_score, recall_score
from osteoV2.model.clinical.clinical_dataset import Dataset_clinical
from osteoV2.model.clinical.mlp import Net_singlemodel_clinical
from others.ICU.net import Model
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def metric_caculate(path):
    '''==================参数设置======================='''
    seeds = [6, 66, 666]#, 324, 1000, 2000, 3045, 2434, 35466, 34546]
    os.environ[
        "CUDA_VISIBLE_DEVICES"] = '2'
    '''================================================'''

    '''==============设置device并下载模型================='''
    device = "cpu"
    if torch.cuda.is_available():
        # print('gpu is not full')
        device = "cuda:0"
        # if torch.cuda.device_count() > 1:
        #     model = nn.DataParallel(model)
    print('device:', device)

    model = torch.load(path)
    model.to(device)
    model.eval()
    '''================================================'''


    '''==================读取数据======================='''
    data = pd.read_excel(r'//home/user/suteng/data/clinical/2_onehot.xlsx', index_col=0, header=0,
                         sheet_name='二分类')  # 直接读取预处理后的数据
    features = data.iloc[:, 4:]
    labels = data.iloc[:, 3]
    # print('features:\n', features)
    # print('labels:\n', labels)

    accuracy_test_average = 0  #
    result = pd.DataFrame(index=range(len(seeds)),
                          columns=['seed', 'accuracy_train', 'accuracy_test', 'f1_train', 'f1_test', 'precision_train',
                                   'precision_test', 'recall_train', 'recall_test', 'auc_train', 'auc_test'])
    train = []#用于存放所有随机种子的真实标签与预测标签
    test = []
    for i, seed in zip(range(len(seeds)), seeds):
        setup_seed(seed)
        print('-----seed=%d-----' % seed)
        x_train, x_test, y_train, y_test = \
            train_test_split(features, labels, test_size=0.2, stratify=labels)
        x_train, x_val, y_train, y_val = \
            train_test_split(x_train, y_train, test_size=0.2, stratify=y_train)
        max = x_train.max()
        min = x_train.min()
        '''归一化'''
        x_train = (x_train - min) / (max - min)
        x_test = (x_test - min) / (max - min)

        train_dataset = Dataset_clinical(x_train, y_train)
        test_dataset = Dataset_clinical(x_test, y_test)
        trainloader = torch.utils.data.DataLoader(dataset=train_dataset,
                                                  batch_size=len(train_dataset),
                                                  shuffle=True)
        testloader = torch.utils.data.DataLoader(dataset=test_dataset,
                                                 batch_size=len(test_dataset),
                                                 shuffle=True)

        with torch.no_grad():
            for j, data in enumerate(trainloader, 0):
                    inputs_train, labels_train = data
                    inputs_train, labels_train = inputs_train.to(device), labels_train.to(device)
                    outputs_train = model(inputs_train)
                    _, train_predicted = torch.max(outputs_train.data, 1)

                    train_predicted = train_predicted.cpu()
                    labels_train = labels_train.cpu()
                    outputs_train = F.softmax(outputs_train, dim=1)
                    outputs_train = outputs_train.cpu()
                    labels_train = labels_train.detach().numpy()
                    outputs_train = outputs_train.detach().numpy()

            for j, data in enumerate(testloader, 0):
                    inputs_test, labels_test = data
                    inputs_test, labels_test = inputs_test.to(device), labels_test.to(device)
                    outputs_test = model(inputs_test)
                    _, test_predicted = torch.max(outputs_test.data, 1)

                    test_predicted = test_predicted.cpu()
                    labels_test = labels_test.cpu()
                    outputs_test = F.softmax(outputs_test, dim=1)
                    outputs_test = outputs_test.cpu()
                    labels_test = labels_test.detach().numpy()
                    outputs_test = outputs_test.detach().numpy()
        con = np.vstack((labels_train, outputs_train[:, 1])).T
        train.extend(con)
        con_test = np.vstack((labels_test, outputs_test[:, 1])).T
        test.extend(con_test)
        multi_class = 'raise'
        if multi_class == 'raise':
            print('二分类AUC')
            outputs_train = outputs_train[:, 1]
            outputs_test = outputs_test[:, 1]
        elif multi_class == 'ovo' or multi_class == 'ovr':
            print('多分类AUC')
        accuracy_train = accuracy_score(labels_train, train_predicted)
        accuracy_test = accuracy_score(labels_test, test_predicted)
        f1_train = f1_score(labels_train, train_predicted)
        f1_test = f1_score(labels_test, test_predicted)
        precision_train = precision_score(labels_train, train_predicted)
        precision_test = precision_score(labels_test, test_predicted)
        recall_train = recall_score(labels_train, train_predicted)
        recall_test = recall_score(labels_test, test_predicted)
        auc_train = roc_auc_score(labels_train, outputs_train, multi_class=multi_class)
        auc_test = roc_auc_score(labels_test, outputs_test, multi_class=multi_class)
        # 'accuracy_train', 'accuracy_val', 'accuracy_test'
        result.loc[i]['seed'] = seed
        result.loc[i]['accuracy_train'] = accuracy_train
        result.loc[i]['accuracy_test'] = accuracy_test
        result.loc[i]['f1_train'] = f1_train
        result.loc[i]['f1_test'] = f1_test
        result.loc[i]['precision_train'] = precision_train
        result.loc[i]['precision_test'] = precision_test
        result.loc[i]['recall_train'] = recall_train
        result.loc[i]['recall_test'] = recall_test
        result.loc[i]['auc_train'] = auc_train
        result.loc[i]['auc_test'] = auc_test
        print('---------------' + ('-' * len(str(seed))))
    print(result)
    # result.to_excel(r'/home/user/suteng/osteo_results/metric_clinical.xlsx')

    train = pd.DataFrame(train, columns=['label', 'predicted'])
    test = pd.DataFrame(test, columns=['label', 'predicted'])
    train.to_excel(r'/home/user/suteng/osteo_results/label_train_clinical.xlsx')
    test.to_excel(r'/home/user/suteng/osteo_results/label_test_clinical.xlsx')
    print(train)
    print(test)



if __name__ == '__main__':
    # model = Net_singlemodel_clinical(n_classes=2)
    # torch.save(model, '/home/user/suteng/osteo/osteoV2/model_save/clinical/8.13_model_test.pth')
    # model = torch.load('/home/user/suteng/osteo/others/model_save/8.13_model_test.pth')

    path = '/home/user/suteng/osteo/osteoV2/model_save/clinical/8.13_model_test.pth'
    metric_caculate(path)
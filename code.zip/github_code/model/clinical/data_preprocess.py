'''
数据的OneHot转换
'''
import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder

if __name__ == '__main__':
    root_dir = '/home/user/suteng/data/clinical'
    columns=['label0', 'label1', 'label2', 'onehot1', 'onehot2', 'onehot3', 'onehot4', 'onehot5', 'onehot6', 'onehot7', 'onehot8']
    data = pd.read_excel(root_dir + '/1_去除极端值_省立齐鲁.xlsx', header=0, index_col=0, sheet_name='Sheet1')
    data_discrete = data.iloc[:, 1:4]
    index = data_discrete.index
    print(index)
    print(data_discrete)
    enc_onehot = OneHotEncoder()
    enc_onehot.fit(data_discrete)
    print('one hot后:\n', data_discrete)

    data_discrete = enc_onehot.transform(data_discrete).toarray()
    print('to array:\n', data_discrete)
    data_discrete = pd.DataFrame(data_discrete, columns=columns[0:len(data_discrete[0])], index=index)
    print(data_discrete)
    data_discrete.to_excel(root_dir + '/2_onehot.xlsx')
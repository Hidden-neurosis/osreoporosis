import torch
import torch.nn as nn
from osteoV2.model.image.resnet18 import ResidualBlock, ResNet

class ImgToCli(ResNet):
    def __init__(self):
        num_features = 40
        super(ImgToCli, self).__init__(ResidualBlock, image_size=(384, 384), channels=[16, 32, 64, 128],  num_classes=3)
        self.fc = nn.Linear(self.get_length(), num_features)

    def forward(self, x):

if __name__ == '__main__':
    model = ImgToCli()
    img = torch.randn((4, 1, 384, 384))
    print(model(img).size())

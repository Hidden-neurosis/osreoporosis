import os
import cv2
from skimage import io
import json
import torch, torchvision
import numpy as np
import pandas as pd
import torchvision.transforms as transforms
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
from torch.utils.data import random_split
# from image_label_process import mask_to_onehot

'''原分割时的数据类'''

def imshow(img, color):
    # img = img / 2 + 0.5  # unnormalize
    # npimg = img.numpy()
    # print("img_shape:", np.shape(img))
    if color == 0:
        plt.imshow(img, cmap='gray')
    else:
        plt.imshow(img)
    plt.show()

def mask_to_onehot(mask, palette):
    """
    Converts a segmentation mask (H, W, C) to (H, W, K) where the last dim is a one
    hot encoding vector, C is usually 1 or 3, and K is the number of class.
    """
    semantic_map = []
    for colour in palette:
        equality = np.equal(mask, colour)
        class_map = np.all(equality, axis=-1)
        semantic_map.append(class_map)
    semantic_map = np.stack(semantic_map, axis=-1).astype(np.float32)
    return semantic_map

def getStat(train_data, dim):
    '''
    计算训练集的均值与标准差
    :param train_data: 自定义类Dataset(或ImageFolder即可)
    :return: (mean, std)
    '''
    print('Compute mean and variance for training data.')
    print(len(train_data))
    train_loader = torch.utils.data.DataLoader(
        train_data, batch_size=1, shuffle=False, num_workers=0,
        pin_memory=True)
    mean = torch.zeros(dim)
    std = torch.zeros(dim)
    for X, _ in train_loader:
        print(X.size())
        for d in range(dim):
            mean[d] += X[d, :, :].mean()
            std[d] += X[d, :, :].std()

    mean.div_(len(train_data))
    std.div_(len(train_data))
    return list(mean.numpy()), list(std.numpy())

def load_data(trainlabel_dir, testlabel_dir, root_dir_train, root_dir_test):
    '''通过dataset类获取数据并进行预处理'''

    transform = {'image': transforms.Compose([
        # transforms.ToPILImage(),
        transforms.ToTensor(),
        transforms.Normalize(0.32544968, 0.14627582), # 此处标准化的数字个数要根据输入图片的数目做修改
        # transforms.CenterCrop((384, 250)),
        transforms.Resize((384, 384)),
        # transforms.Resize((572, 572)),
        # transforms.Normalize(0.5, 0.5)
    ]),
    'labels':transforms.Compose([
        # transforms.ToPILImage(),
        transforms.ToTensor(),
        # transforms.CenterCrop((384, 250)),
        transforms.Resize((384, 384)),
        # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
    ])}
    trainset_load = OsteosegmentDataset(
        trainlabel_dir, root_dir_train, transform=transform)
    testset_load = OsteosegmentDataset(
        testlabel_dir, root_dir_test, transform=transform)
    return trainset_load, testset_load

def get_loader(batch_size, trainlabel_dir, testlabel_dir, root_dir_train, root_dir_test):
    '''生成train loader,validation loader和test loader'''

    trainset, testset = load_data(trainlabel_dir, testlabel_dir, root_dir_train, root_dir_test)
    '''划分训练集与验证集'''
    test_abs = int(len(trainset) * 0.8)
    train_subset, val_subset = random_split(
        trainset, [test_abs, len(trainset) - test_abs])

    # 此时batchsize也从config字典中获取
    # 在预测时间序列的背景下，不管训练集的shuffle还是测试集的shuffle都不能设置为true。因为会打乱时序的前后关系。
    trainloader = torch.utils.data.DataLoader(
        train_subset,
        batch_size=int(batch_size),
        shuffle=True,
        num_workers=8)
    valloader = torch.utils.data.DataLoader(
        val_subset,
        batch_size=int(batch_size),
        shuffle=False,
        num_workers=8)
    testloader = torch.utils.data.DataLoader(
        testset,
        batch_size=int(batch_size),
        shuffle=False,
        num_workers=8)
    return trainloader, valloader, testloader

class OsteosegmentDataset(Dataset):
    def __init__(self, label_file, root_dir, transform=None):
        self.labels_frame = os.listdir(label_file)
        self.root_dir = root_dir
        self.transform = transform
        # print(self.landmarks_frame)

    def __len__(self):
        return len(self.labels_frame)

    def __getitem__(self, idx):
        idx_name, idx_expand = os.path.splitext(self.labels_frame[idx])
        image_name = os.path.join(self.root_dir, 'image',
                                  idx_name + '.bmp', )
        # image = io.imread(image_name)
        image = cv2.imdecode(np.fromfile(image_name, dtype=np.uint8), 2)
        label_name = os.path.join(self.root_dir, 'json_to_dataset',
                                  idx_name, 'label.png')
        # labels = io.imread(label_name)
        labels = cv2.imdecode(np.fromfile(label_name, dtype=np.uint8), 1)
        labels = cv2.cvtColor(labels, cv2.COLOR_BGR2RGB)
        sample = {'image': image, 'labels': labels}
        # print('idx_name', idx_name)
        # # print('image_name', image_name)
        # print(type(image), np.shape(image))
        # print('dataset labels_get:', type(labels), np.shape(labels))
        # plt.title('image')
        # imshow(image, color=0)

        palette = [[0, 0, 0], [128, 0, 0], [0, 128, 0], [128, 128, 0], [0, 0, 128]]
        if self.transform:
            image = self.transform['image'](image)
            labels = mask_to_onehot(labels, palette)#[384,384,5]
            labels_2class = np.zeros((384, 384, 2))
            labels_2class[:, :, 0] = labels[:, :, 0]
            labels_2class[:, :, 1] = (1 - labels[:, :, 0])

            # plt.title('labels_2class 0 ')
            # imshow(labels_2class[:, :, 0], color=1)
            # plt.title('labels_2class 1 ')
            # imshow(labels_2class[:, :, 1], color=1)
            # print('dataset self.transform  labels size onehot:', np.shape(labels))
            labels = self.transform['labels'](labels)
            labels_2class = self.transform['labels'](labels_2class)
            # print('dataset self.transform labels size transform:', labels.size())
            # print('dataset labels size:', labels_2class[0, :, :].sum())
        return image, labels_2class

if __name__ == '__main__':
    # print(os.listdir('../data'))
    # path = '../data/train/labelme/json/17034294.json'
    # with open(path) as f:
    #     dict = json.load(f)
    # print(dict)

    label_train = '../data/train/labelme/json_to_dataset'
    label_test = '../data/test/labelme/json_to_dataset'
    root_dir_train = '../data/train/labelme'
    root_dir_test = '../data/test/labelme'
    transform = {'image': transforms.Compose([
        # transforms.ToPILImage(),
        transforms.ToTensor(),
        # transforms.Resize((572, 572)),
    ]),
        'labels': transforms.Compose([
            # transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Resize((388, 388)),
            # transforms.Normalize((0.5, 0.5, 0.5, 0.5), (0.5, 0.5, 0.5, 0.5))
        ])}
    dataset = OsteosegmentDataset(label_train, root_dir_train, transform=transform)
    print(np.shape(dataset[0][0]))
    mean, std = getStat(dataset, 1)
    print('mean:{}, std:{}'.format(mean, std))
    # print(dataset[0])

    # trainloader, valloader, testloader = get_loader(4, label_train, label_test, root_dir)
    # for i, data in enumerate(trainloader):
    #     inputs, labels = data
    #     print(type(inputs), inputs.size())
    #     print(type(labels), labels.size())
    # print(len(trainloader))
    # print(len(valloader))
    # print(len(testloader))




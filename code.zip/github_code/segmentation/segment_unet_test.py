
from segment_unet_model import unet
import cv2
import numpy as np
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "2"


path_test_image, path_test_label, path_test_save =\
	r'./data/label0.5', './data/valid/label', \
	r'./data/label0.5_seg'
# /home/user/PycharmProjects/osteo/osteoV2/segmentation
path_test_image, path_test_label, path_test_save =\
	r'./data/img_num=5/label1', './data/valid/label', \
	r'./data/img_num=5/label1_seg'
images = os.listdir(path_test_image)
# labels = os.listdir(path_test_label)

model = unet()
model.load_weights('./unet_membrane.hdf5')

if not os.path.exists(path_test_save):
	os.makedirs(path_test_save)
acc = np.zeros(len(images))
for i, id in zip(range(len(images)), images):
	print(id)
	print(os.path.join(path_test_image, id))
	imgs = os.listdir(os.path.join(path_test_image, id))
	print(imgs)
	path_save = os.path.join(path_test_save, id)
	if not os.path.exists(path_save):
		os.makedirs(path_save)
	for img in imgs:
		image = cv2.imread(os.path.join(path_test_image, id, img), cv2.IMREAD_GRAYSCALE)
		image = image / 255
		image = np.reshape(image, (1,) + image.shape + (1,))
		img_pred = model.predict(image)
		img_pred = img_pred[0, :, :, 0]
		assert img_pred.shape == (384, 384)
		img_pred[img_pred > 0.5] = 1
		img_pred[img_pred <= 0.5] = 0
		cv2.imwrite(os.path.join(path_test_save, id, img), img_pred * 255)
		print(imgs, os.path.join(path_test_save, id, img))

# 	label = cv2.imread(os.path.join(path_test_label, labels[i]), cv2.IMREAD_GRAYSCALE)
# 	label[label > 0] = 1
# 	assert img_pred.shape == label.shape
# 	acc[i] = np.sum(img_pred == label) / (label.shape[0] * label.shape[1])
# 	print('finished saved %s, accuracy=%.2f%%' % (images[i], acc[i] * 100))
#
# print('测试集的平均预测准确率为：%.2f%%' % (np.mean(acc) * 100))

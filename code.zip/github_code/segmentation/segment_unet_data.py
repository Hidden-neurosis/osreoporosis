from keras.preprocessing.image import ImageDataGenerator
import os
os.environ["CUDA_VISIBLE_DEVICES"] = '2'


def train_generator(batch_size, aug_dict, train_path, image_folder, label_folder, image_save_prefix="image",
                    label_save_prefix="label", save_to_dir=None, target_size=(384, 384), seed=42):
    image_datagen = ImageDataGenerator(**aug_dict)
    label_datagen = ImageDataGenerator(**aug_dict)

    image_generator = image_datagen.flow_from_directory(
        train_path, target_size=target_size, color_mode='grayscale', classes=[image_folder], class_mode=None,
        batch_size=batch_size, save_to_dir=save_to_dir, save_prefix=image_save_prefix, seed=seed)
    label_generator = label_datagen.flow_from_directory(
        train_path, target_size=target_size, color_mode='grayscale', classes=[label_folder], class_mode=None,
        batch_size=batch_size, save_to_dir=save_to_dir, save_prefix=label_save_prefix, seed=seed)

    for img, label in zip(image_generator, label_generator):
        img = img / 255
        label[label > 0] = 1
        yield img, label


def valid_generator(batch_size, aug_dict, valid_path, image_folder, label_folder, image_save_prefix="image",
                    label_save_prefix="label", save_to_dir=None, target_size=(384, 384), seed=42):
    image_datagen = ImageDataGenerator(**aug_dict)
    label_datagen = ImageDataGenerator(**aug_dict)

    image_generator = image_datagen.flow_from_directory(
        valid_path, target_size=target_size, color_mode='grayscale', classes=[image_folder], class_mode=None,
        batch_size=batch_size, save_to_dir=save_to_dir, save_prefix=image_save_prefix, seed=seed)
    label_generator = label_datagen.flow_from_directory(
        valid_path, target_size=target_size, color_mode='grayscale', classes=[label_folder], class_mode=None,
        batch_size=batch_size, save_to_dir=save_to_dir, save_prefix=label_save_prefix, seed=seed)

    for img, label in zip(image_generator, label_generator):
        img = img / 255
        label[label > 0] = 1
        yield img, label

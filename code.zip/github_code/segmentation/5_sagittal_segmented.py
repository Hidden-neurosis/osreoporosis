import os
import cv2
import numpy as np
import shutil
def extract_texture(path_read_image, path_read_label, path_save):
    """
    读取原图像与label，叠加运算生成分割后的图像
    :param path_read_image:
    :param path_read_label:
    :param path_save:
    :return:
    """
    folders = os.listdir(path_read_image)
    for folder in folders:
        print(folder)
        imgs = os.listdir(os.path.join(path_read_image, folder))
        print(imgs)
        # 读取图像和掩膜标签
        for img_name in imgs:
            img = cv2.imread(os.path.join(path_read_image, folder, img_name), cv2.IMREAD_GRAYSCALE)
            label = cv2.imread(os.path.join(path_read_label, folder, img_name), cv2.IMREAD_GRAYSCALE)

            label[label != 0] = 1
            img_filter = img * label
            # path_save2 = os.path.join(path_save, folder[:8])
            # if not os.path.exists(path_save2):
            #     os.makedirs(path_save2)
            # cv2.imwrite(os.path.join(path_save2, folder[:8] + '.png'), img_filter)
            p = os.path.join(path_save, folder[:8])
            if not os.path.exists(p):
                os.makedirs(p)
            cv2.imwrite(os.path.join(path_save, folder[:8], img_name[0] + '.png'), img_filter)
            print("已保存"+os.path.join(path_save, folder[:8], img_name[0] + '.png'))

def main_segmented():
    path_image = r'./data/img_num=5/label1'
    path_label = r'./data/img_num=5/label1_seg'
    path_save = r'../data/img_num=5/label1'
    extract_texture(path_image, path_label, path_save)

if __name__ == "__main__":
    main_segmented()